% ===================================================================== %
% FILE		: load_more_lists.ml				        %
% DESCRIPTION   : creates a function that loads the contents of the	%
%		  library "more_lists" into hol.			%
%									%
% AUTHOR	: P. Curzon						%
% DATE		: 8.4.91						%
% ===================================================================== %

% --------------------------------------------------------------------- %
% define the function load_more_lists.				        %
% --------------------------------------------------------------------- %

let load_more_lists =
  let autoload_defs_and_thms thy =
   map (\name. autoload_theory(`definition`,thy,name))
     (map fst (definitions thy));
   map (\name. autoload_theory(`theorem`,thy,name))
     (map fst (theorems thy));
 ()
  in
  let lib_path = library_pathname() in
  \(v:void).
    if (mem `more_lists` (ancestry())) then
       (print_string `Loading contents of more_lists...`;
        print_newline();
        load_auxiliary();
       let path st = lib_path ^ `/more_lists/` ^ st in
        load(path `list_tactics`, get_flag_value `print_lib`);
        load(path `list_convs`, get_flag_value `print_lib`);
         autoload_defs_and_thms `append`;
         autoload_defs_and_thms `map`;
         autoload_defs_and_thms `el`;
         autoload_defs_and_thms `ell`;
         autoload_defs_and_thms `general_lists`;
         autoload_defs_and_thms `zip`;
         autoload_defs_and_thms `tail`;
         autoload_defs_and_thms `subseq`;
         autoload_defs_and_thms `last_subseq`;
         autoload_defs_and_thms `shift`;
         autoload_defs_and_thms `snoc`;
         autoload_defs_and_thms `member`;
         autoload_defs_and_thms `num_lists`;
         delete_cache `append`;
         delete_cache `map`;
         delete_cache `el`;
         delete_cache `ell`;
         delete_cache `general_lists`;
         delete_cache `zip`;
         delete_cache `tail`;
         delete_cache `unappend`;
         delete_cache `subseq`;
         delete_cache `last_subseq`;
         delete_cache `shift`;
         delete_cache `snoc`;
         delete_cache `member`;
         delete_cache `num_lists`; ()) else
      failwith `theory more_lists not an ancestor of the current theory`;;


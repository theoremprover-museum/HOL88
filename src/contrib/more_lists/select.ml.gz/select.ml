
%****************************************************************************%
%									     %
% File:         select.ml						     %
%									     %
% Author:       Wim Ploegaerts  (ploegaer@imec.be)			     %
%									     %
% Date:         Mon Feb 11 1991						     %
%									     %
% Organization: Imec vzw.						     %
%               Kapeldreef 75						     %
%               3001 Leuven - Belgium					     %
%									     %
% Description:  A collection of tactics and conversions dealing with select  %
%									     %
%****************************************************************************%


%*********************************  HISTORY  ********************************%
%									     %
%*****************************  END OF HISTORY  *****************************%


letrec DEPTH_FORALL_CONV conv tm = 
   if (is_forall tm) then
     BINDER_CONV (DEPTH_FORALL_CONV conv) tm else conv tm;;

%============================================================================%
%									     %
% 		      From Brian Grahams famous report			     %
%									     %
%============================================================================%

let in1_conv_rule = CONV_RULE o ONCE_DEPTH_CONV o CHANGED_CONV;;

%									     %
% 	SELECT_UNIQUE_RULE:						     %
% 	===================						     %
%									     %
% 	("x","y")   A1 |- Q[y]  A2 |- !x y.(Q[x]/\Q[y]) ==> (x=y)	     %
% 	=========================================================	     %
% 		A1 U A2 |- (@x.Q[x]) = y				     %
%									     %
% Permits substitution for values specified by the Hilbert Choice	     %
% operator with a specific value, if and only if unique existance	     %
% of the specific value is proven.					     %
%									     %

let SELECT_UNIQUE_RULE (x,y) th1 th2 =
  let Q = mk_abs (x, subst [x,y] (concl th1))
  in
  let th1' = SUBST [SYM (BETA_CONV "^Q ^y"), "b:bool"] "b:bool" th1
  in
  (MP (SPECL ["$@ ^Q"; y] th2)
      (CONJ (in1_conv_rule BETA_CONV (SELECT_INTRO th1')) th1));;


%									     %
% 	SELECT_UNIQUE_TAC:						     %
% 	==================						     %
%									     %
% 	        [ A ] "(@x. Q[x]) = y"					     %
% 	===================================================		     %
%         [ A ] "Q[y]"   [ A ] "!x y.(Q[x]/\Q[y]) ==> (x=y)"		     %
%									     %
% Given a goal that requires proof of the value specified by the	     %
% Hilbert choice operator, it returns 2 subgoals:			     %
%   1. "y" satisfies the predicate, and					     %
%   2. unique existance of the value that satisfies the predicate.	     %
%									     %
	
let SELECT_UNIQUE_TAC:tactic (gl,g) =
  let Q,y = dest_eq g
  in
  let x,Qx = dest_select Q
  in
  let x' = variant (x.freesl(g.gl))x
  in
  let Qx' = subst [x', x] Qx
  in
  ([gl,subst [y,x]Qx;
    gl, "!^x ^x'. (^Qx /\ ^Qx') ==> (^x = ^x')"],
   (\thl. SELECT_UNIQUE_RULE (x,y) (hd thl) (hd (tl thl))));;


%============================================================================%
%									     %
% 		     From Elsa Gunters' start_groups.ml			     %
%									     %
%============================================================================%

% SELECT_TAC : term -> tactic   ( term = @x.P(x) )

    [A] P[@x.P(x)]
======================
     [A] ?x.P(x)
%

let SELECT_TAC (thisterm:term) (thisgoal:goal) =
(let t1,t2=dest_select thisterm in
 if (snd thisgoal)= subst[(thisterm,t1)]t2
 then [((fst thisgoal),(mk_exists (t1,t2)))], (\[thm].(SELECT_RULE thm))
 else fail
)?failwith `SELECT_TAC`;;




%============================================================================%
%									     %
% 		 Home brewed but not as good as belgian beer		     %
%									     %
%============================================================================%



%									     %
%      @x.Px = @x.Qx    Should be made more robust by using match or alpha   %
%      -------------    conversion on the terms				     %
%        Px = Qx							     %
%									     %

%< WAS CALLED SELECT_TAC !! >%

let SELECT_EQ_TAC  (asl,w) =
    let trm1,trm2 = dest_eq w in
        let trm,trm1' =  dest_abs (rand trm1) and
            trm2' =  snd (dest_abs (rand trm2)) in
    let eq = mk_eq (trm1',trm2') in
    [(asl,eq)],\[thm].(SELECT_EQ trm thm)
? failwith `SELECT_EQ_TAC`;;


%									     %
% 				   EXAMPLE				     %
%									     %
%									     %
% g "(@x . ((x + 0) = 1)) = (@ x . (x = 1))";;				     %
%									     %
% "(@x. x + 0 = 1) = (@x. x = 1)"					     %
%									     %
% () : void								     %
%									     %
% e(SELECT_TAC								     %
% );;									     %
% OK..									     %
% "(x + 0 = 1) = (x = 1)"						     %
%									     %
% () : void								     %
%									     %
% e(REWRITE_TAC [ADD_CLAUSES]						     %
% );;OK..								     %
% goal proved								     %
% |- (x + 0 = 1) = (x = 1)						     %
% |- (@x. x + 0 = 1) = (@x. x = 1)					     %
%									     %
% Previous subproof:							     %
% goal proved								     %
% () : void								     %
%									     %



%============================================================================%
%									     %
% 				   Exists				     %
%									     %
%============================================================================%



%									     %
%  A conversion that introduces an internal variable, according to the	     %
%  following theorem							     %
%									     %

let eq_to_exist = prove (
  "!t1 t2:* . (t1 = t2) = (?t3 . (t3 = t1) /\ (t3 = t2))",
 REPEAT GEN_TAC THEN EQ_TAC THENL
  [
   DISCH_THEN SUBST1_TAC THEN EXISTS_TAC "t2:*" THEN
   REWRITE_TAC []
  ;
   STRIP_TAC THEN
   EVERY_ASSUM (SUBST1_TAC o SYM) THEN
   REFL_TAC
  ]
);;


%									     %
% EQ_INT_VAR_CONV "t1:*" "t2:* = t3";;					     %
% |- (t2 = t3) = (?t1. (t1 = t2) /\ (t1 = t3))				     %
%									     %
%									     %
% EQ_INT_VAR_CONV "l:num" "t = n + m";;					     %
% |- (t = n + m) = (?l. (l = t) /\ (l = n + m))				     %
%									     %
% EQ_INT_VAR_CONV "l:*" "t = n + m";;					     %
%									     %



let EQ_INT_VAR_CONV t term = 
     let (tv,tty) = dest_var t ? failwith `not a variable` in
     let theorem  = INST_TYPE [tty,":*"] eq_to_exist in
     let t1,t2 = dest_eq term ? failwith `not an equality` in
   CONV_RULE (DEPTH_FORALL_CONV (RAND_CONV (GEN_ALPHA_CONV t)))
            ( SPECL [t1;t2] theorem );;

%<-------------------------------------------------------------------------->%


let EXISTS_OR = prove (
  "!(Q:(*)->bool) (R:**->bool) . 
         ((?k . Q k) \/ (?l . R l)) = ?k l . (Q k \/ R l) ",
  REPEAT GEN_TAC THEN EQ_TAC THENL
  [
   DISCH_THEN \thm . 
    DISJ_CASES_THEN STRIP_ASSUME_TAC thm THEN
    EXISTS_TAC "k:*" THEN EXISTS_TAC "l:**" THEN
    ASM_REWRITE_TAC []
  ;
  DISCH_THEN \thm .
  let mk_term  t = 
       let term = (concl t) in
        let arg = rand term in
       let exist = "?^arg.^term" in
      (exist,arg) in
  let f = \t . DISJ_CASES_THEN (\th . REWRITE_TAC [EXISTS (mk_term th) th]) t
  in
    X_CHOOSE_THEN "k:*" (X_CHOOSE_THEN "l:**" f) thm
  ]
);;


%									     %
% EXISTS_OR_CONV  "(?a:*1. A a ) \/ (?a:*2 . C a)";;			     %
% |- (?a. A a) \/ (?a. C a) = (?a a'. A a \/ C a')			     %
%									     %
% EXISTS_OR_CONV  "(?a:*1. A a ) /\ (?a:*2 . C a)";;			     %
% evaluation failed     no disjunction					     %
%									     %


let EXISTS_OR_CONV term = 
      let (or,[x1;x2]) = strip_comb term in
      let (k,Qk) = dest_exists x1 and
          (l,Rl) = dest_exists x2 in
      let absQ = mk_abs (k,Qk) and
          absR = mk_abs (l,Rl) in
      let (_,ty1) = dest_var k and
          (ls,ty2) = dest_var l in
      let theo = INST_TYPE [(ty1,":*");(ty2,":**")] EXISTS_OR in
      let theo' = BETA_RULE (SPECL [absQ;absR] theo) in
      let newl = 
            (k=l) => mk_primed_var (ls,ty2) | l in
      let convk = GEN_ALPHA_CONV k and
          convl = GEN_ALPHA_CONV newl in
   if (or = "$\/")
   then 
     CONV_RULE (LHS_CONV (LHS_CONV convk THENC RAND_CONV convl) THENC
          (RAND_CONV (convk THENC BINDER_CONV convl))) theo' 
   else failwith `no disjunction`
;;










%									     %
% let lemma_1 = prove (							     %
%   "!g. ? f1 . !(x:**) (X:(**)list) .  (g (CONS x X):***) = f1 (g X) x X",  %
%   GEN_TAC THEN							     %
%   EXISTS_TAC "\(h:***) (x:**) X . (g (CONS x X)):***" THEN		     %
%   BETA_TAC THEN REWRITE_TAC []					     %
% );;									     %
%									     %
%									     %
%									     %
%									     %
% let lemma_2 = prove (							     %
%   "!g:(**)list->***. ? a f1 . g = \(Y:(**)list) . (Y = []) => (a:***) | f1 %
%  (g (TL Y)) (HD Y) (TL Y)",						     %
%   GEN_TAC THEN CONV_TAC ((DEPTH_CONV FUN_EQ_CONV) THENC (DEPTH_CONV	     %
%  BETA_CONV)) THEN							     %
%   STRIP_ASSUME_TAC (SPEC "g:(**)list->***" lemma_1) THEN		     %
%   EXISTS_TAC "g ([]:(**)list) :***" THEN EXISTS_TAC			     %
%  "f1:***->**->(**)list->***" THEN					     %
%   GEN_TAC THEN STRIP_ASSUME_TAC (SPEC "l:(**)list" (INST_TYPE [":**",":*"] %
%  list_CASES)) THEN							     %
%   ASM_REWRITE_TAC [NOT_CONS_NIL;HD;TL]				     %
% );;									     %
%									     %
%									     %
%									     %

%============================================================================%
%									     %
% 			    Select for functions			     %
%									     %
%============================================================================%


%									     %
% MAKE CONVERSION FROM THIS						     %
%									     %
%									     %
% let SELECT_FUN = prove (						     %
%   "!G (y:*) . (@fun . !x . fun x = G x:**) y = G y ",			     %
%  GEN_TAC THEN								     %
%  SUBST1_TAC								     %
%  (SYM (CONV_RULE (DEPTH_CONV BETA_CONV)				     %
%    (X_FUN_EQ_CONV "y:*" "(@fun. !x . fun x = G (x:*):**) = \y. G y")))     %
%  THEN REWRITE_TAC [ETA_AX] THEN					     %
%  REWRITE_TAC [GEN_ALL (SYM						     %
%    (X_FUN_EQ_CONV "x:*" "(fun = G:*->**)"))] THEN			     %
%  SELECT_TAC "(@fun. fun = G:*->**)" THEN EXISTS_TAC "G:*->**"		     %
%  THEN REFL_TAC							     %
% );;									     %
%									     %

%									     %
% 		 The same for a binary function (same proof)		     %
%                                                                            %

%									     %
% let SELECT_BIN_FUN = prove (						     %
%   "! G (x:*) (y:**) .							     %
%      (@fun. !(x:*) (y:**) . fun x y = G x y) x y = G x y:***",	     %
%   GEN_TAC THEN							     %
%   SUBST1_TAC								     %
%   (SYM (CONV_RULE							     %
%        ((RAND_CONV (BINDER_CONV (X_FUN_EQ_CONV "y:**")))		     %
% 	 THENC (DEPTH_CONV BETA_CONV))					     %
%    (X_FUN_EQ_CONV "x:*"						     %
%     "(@fun. !x y . fun x y = G (x:*) (y:**):***) = \x y. G x y"))) THEN    %
%  REWRITE_TAC [ETA_AX] THEN						     %
%  REWRITE_TAC [GEN_ALL (SYM						     %
%    (CONV_RULE (RAND_CONV (BINDER_CONV (X_FUN_EQ_CONV "y:**")))	     %
%     (X_FUN_EQ_CONV "x:*" "(fun = G:*->**->***)")))] THEN		     %
%  SELECT_TAC "(@fun. fun = G:*->**->***)" THEN EXISTS_TAC "G:*->**->***"    %
%  THEN REFL_TAC							     %
% );;									     %
%									     %
%									     %
%									     %
%============================================================================%
%									     %
% 			   select and if-then-else			     %
%									     %
%============================================================================%
%									     %
% g "!Q (a:*) (G:*->**).						     %
%     (Q a) ==> ((@fun . (!x . (Q x) ==> (fun x = G x))) a = G a)";;	     %
%									     %
%									     %
% ------								     %
%									     %
% let SELECT_IF_FUN = prove (						     %
%   "!Q (a:*) (G:*->**) H.						     %
%     (Q a) ==> ((@fun . (!x . fun x = (Q x) => G x | H x)) a = G a)",	     %
%   REPEAT STRIP_TAC THEN						     %
%   ASM_REWRITE_TAC							     %
%     [CONV_RULE (DEPTH_CONV BETA_CONV)					     %
%       (SPEC "\x:* . Q x => G x:** | H x" SELECT_FUN)]			     %
% );;									     %
%									     %
% let SELECT_IF_BIN_FUN = prove (					     %
%  "!Q (a:*) (G:*->**->***) H y.					     %
%     (Q a) ==>								     %
%       ((@fun . (!x y . fun x y = (Q x) => G x y | H x y)) a y = G a y)",   %
%   REPEAT STRIP_TAC THEN						     %
%   ASM_REWRITE_TAC							     %
%     [CONV_RULE (DEPTH_CONV BETA_CONV)					     %
%       (SPEC "\(x:*) (y:**) . Q x => G x y | H x y:***" SELECT_BIN_FUN)]    %
% );;									     %
%									     %
%									     %
% AND WHAT ABOUT RECURSIVE RHS						     %
%									     %


%									     %
% let L_NIL_IMP = prove_thm (						     %
%   `L_NIL_IMP`,							     %
%    " !l :(*)list . ((l = []) ==> (NULL l)) /\ (([] = l) ==> (NULL l))",    %
%      GEN_TAC THEN							     %
%      CONV_TAC (RAND_CONV (ONCE_DEPTH_CONV SYM_CONV)) THEN		     %
%      CONJ_TAC THEN							     %
%   DISCH_THEN \thm . REWRITE_TAC [thm;NULL]				     %
%   );;									     %
%									     %
% let L_EQ_NIL = prove_thm (						     %
%   `L_EQ_NIL`,								     %
%     " !l :(*)list . ((l = []) = (NULL l))",				     %
%      GEN_TAC THEN							     %
%      EQ_TAC THENL							     %
%     [									     %
%     DISCH_THEN \thm . (REWRITE_TAC [thm;NULL])			     %
%    ;									     %
%     SPEC_TAC ("l:(*)list","l:(*)list") THEN				     %
%     LIST_INDUCT_TAC THEN						     %
%     REWRITE_TAC [NULL]						     %
%   ]									     %
%   );;									     %
%									     %






%									     %
%  let theorem =							     %
%    " ! a f1 f2 f3 .							     %
%        ?! fn:(*)list -> (**)list -> *** .				     %
%          (fn  []  []  =  a) /\					     %
%          (!x X . fn  (CONS x X)  [] =  f1 (fn X []) x X) /\		     %
%          (!y Y . fn  []  (CONS y Y) =  f2 (fn [] Y) y Y) /\		     %
%          (!x X y Y .fn  (CONS x X) (CONS y Y) =  f3 (fn X Y) x X y Y)";;   %
%									     %
%									     %
									    

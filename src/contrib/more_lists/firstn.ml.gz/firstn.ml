%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   FILE:         firstn.ml                                                  %
%   EDITOR:       Paul Curzon                                                %
%   ORGANIZATION: U Cambridge CL                                             %
%   DATE:         June 1991                                                  %
%   DESCRIPTION:  Subsequences of lists counting from the front              %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%*********************************  HISTORY  ********************************%
%									     %
%   This file contains list theorems and definitions from several            %
%   sources:  								     %
%      Mike Benjamin(British Aerospace Sowerby Research Centre,Bristol)      %
%      Rachel Cardell-Oliver						     %
%      Wim Ploegaerts   (Imec vzw Leuven, Belgium)			     %
%                                                                            %
%  The names of some theorems have been changed from the original sources    %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%****************************************************************************%
%                                                                            %
%  DEPENDANCIES :                                                            %
%                                                                            %
%         library more_arithmetic  for arithmetic theorems                   %
%         prim_rec                 for arithmetic theorems                   %
%         general_lists            for general list theorems                 %
%         tail                     for TAIL                                  %
%         map                      for MAP theorems                          %
%                                                                            %
%****************************************************************************%
system `rm -f subseq.th`;;

new_theory `subseq`;;

%< WW Use load_library instead of loadf
set_search_path (search_path()  @ 
		 [`../more_arithmetic/`]);;

loadf `more_arithmetic`;;
>%
load_library `more_arithmetic`;;
load_library `auxiliary`;;

new_parent `ell`;;


let autoload_defs_and_thms thy =
   map (\name. autoload_theory(`definition`,thy,name))
     (map fst (definitions thy));
   map (\name. autoload_theory(`theorem`,thy,name))
     (map fst (theorems thy))in

autoload_defs_and_thms `general_lists`; 
autoload_defs_and_thms `tail`; 
autoload_defs_and_thms `prim_rec`;; 
autoload_defs_and_thms `map`;; 





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   AUTHOR:       Wim Ploegaerts                                             %
%   ORGANIZATION: Imec vzw.                                                  %
%                 Kapeldreef 75                                              %
%                 3030 Leuven, Belgium                                       %
%   DATE:         31-5-1990                                                  %
%                                                                            %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%----------------------------------------------------------------------------%
%									     %
% 			     Apply n times "TL"				     %
%									     %
%----------------------------------------------------------------------------%



let NTL = new_prim_rec_definition (`NTL`,
    "(NTL 0 X = (X:(*)list)) /\
     (NTL (SUC n) X = NTL n (TL X))");;
%----------------------------------------------------------------------------%

let NTL_TL_SYM = prove_thm (`NTL_TL_SYM`,
  "!n (X:(*)list). NTL n (TL X) = TL (NTL n X)",
 INDUCT_THEN INDUCTION MP_TAC THEN
 REWRITE_TAC [NTL] THEN
 DISCH_THEN \t. GEN_TAC THEN REWRITE_TAC [t] 
);;
%----------------------------------------------------------------------------%

let NTL_SIMP_REC = prove_thm (`NTL_SIMP_REC`,
  "!n (X:(*)list).  NTL n X= SIMP_REC X TL n",
  INDUCT_THEN INDUCTION MP_TAC THEN
  REWRITE_TAC [NTL;SIMP_REC_THM;NTL_TL_SYM] THEN
  DISCH_THEN \t. REWRITE_TAC [t]
);;
%----------------------------------------------------------------------------%
let NTL_LENGTH = prove_thm (`NTL_LENGTH`,
  "!n (X:(*)list) .
     (n <= LENGTH X) ==> (LENGTH (NTL n X) = LENGTH X - n)",
 INDUCT_TAC THEN LIST_INDUCT_TAC THENL
 [
  REWRITE_TAC [NTL;LENGTH;SUB]
 ;
  GEN_TAC THEN REWRITE_TAC [NTL;LENGTH;SUB_0]
 ;
  REWRITE_TAC [LENGTH;NOT_SUC_LESS_EQ_0]
 ;
  REWRITE_TAC [LENGTH;LESS_EQ_MONO;NTL;TL;SUB_MONO_EQ] THEN
  STRIP_TAC THEN RES_TAC 
 ]
);;
%----------------------------------------------------------------------------%


let NTL_LENGTH_NIL = prove_thm (
  `NTL_LENGTH_NIL`,
  "!X:* list. NTL (LENGTH X) X = []",
  INDUCT_THEN list_INDUCT MP_TAC THEN
  REWRITE_TAC [LENGTH;NTL;TL]
);;

%----------------------------------------------------------------------------%
%PC%
let NTL_LENGTH_NULL = save_thm(`NTL_LENGTH_NULL`,
    REWRITE_RULE[L_EQ_NIL] NTL_LENGTH_NIL);;

%----------------------------------------------------------------------------%



let NTL_APPEND = prove_thm (`NTL_APPEND`,
   "!X Y:* list. !n. 
   (n <= LENGTH X) ==> (NTL n (APPEND X Y) = APPEND (NTL n X) Y)",
  INDUCT_THEN list_INDUCT ASSUME_TAC THEN
  REWRITE_TAC [LENGTH;APPEND] THENL
 [
  REPEAT GEN_TAC THEN
  DISCH_THEN \t. SUBST1_TAC (MATCH_MP LESS_EQ_0_EQ t) THEN
  REWRITE_TAC [NTL;APPEND]  
 ;
  GEN_TAC THEN GEN_TAC THEN INDUCT_TAC THEN
  REWRITE_TAC [NTL;APPEND;TL;LESS_OR_EQ;INV_SUC_EQ;LESS_MONO_EQ] THEN
  REWRITE_TAC [GSYM LESS_OR_EQ] THEN 
  FIRST_ASSUM MATCH_ACCEPT_TAC
 ]
);;

% ----------------------------------------------------------------------- %

let NTL_NTL = prove_thm (
  `NTL_NTL`,
  "!X:* list . !n m.
     ((n + m) <= LENGTH X) ==> (NTL n (NTL m X) = NTL (n + m) X)",
 INDUCT_THEN list_INDUCT ASSUME_TAC THENL
 [
  REPEAT GEN_TAC THEN 
  REWRITE_TAC [LENGTH] THEN
  DISCH_THEN \t. 
    let thm = MATCH_MP LESS_EQ_0_EQ t in
    REWRITE_TAC [REWRITE_RULE [ADD_EQ_0] thm;thm;NTL]
 ;
  GEN_TAC THEN
  INDUCT_TAC THEN
  GEN_TAC THEN
  REWRITE_TAC [ADD_CLAUSES;LENGTH;NTL;TL;GSYM NTL_TL_SYM] THEN
  REWRITE_TAC [LESS_OR_EQ;INV_SUC_EQ;LESS_MONO_EQ] THEN
  REWRITE_TAC [GSYM LESS_OR_EQ] THEN
  FIRST_ASSUM MATCH_ACCEPT_TAC
 ]
);;
%----------------------------------------------------------------------------%
%									     %
% 		      The first "n" elements of a list			     %
%									     %
%----------------------------------------------------------------------------%

let FIRSTN = new_prim_rec_definition (`FIRSTN`,
    "(FIRSTN 0 (X:(*)list) = []) /\
     (FIRSTN (SUC n) X = CONS (HD X) (FIRSTN n (TL X)))");;

%----------------------------------------------------------------------------%

let LENGTH_FIRSTN = prove_thm (`LENGTH_FIRSTN`,
  "!n (X:(*)list). (n <= LENGTH X) ==> (LENGTH (FIRSTN n X) = n)",
  INDUCT_THEN INDUCTION MP_TAC THEN
  REWRITE_TAC [FIRSTN;LENGTH;INV_SUC_EQ] THEN
  DISCH_THEN \t . GEN_TAC THEN 
                  DISCH_THEN 
                      \t'.MATCH_MP_TAC  (SPEC "TL X:(*)list" t) THEN
                          MP_TAC t'  THEN
  ASM_CASES_TAC "X=[]:(*)list" THEN 
  ASM_REWRITE_TAC [NOT_SUC_LESS_EQ_0;LENGTH] THEN
  IMP_RES_TAC (REWRITE_RULE [GSYM L_EQ_NIL] CONS) THEN
  FIRST_ASSUM (\t. SUBST1_TAC (SYM t) ? NO_TAC) THEN 
  REWRITE_TAC [LENGTH;TL;LESS_EQ_MONO]
);;

%<-------------------------------------------------------------------------->%
let FIRSTN_NIL = prove_thm (
  `FIRSTN_NIL`,
  "!n X. (FIRSTN n X = []:* list) ==> (n = 0)",
  INDUCT_TAC THEN 
  REWRITE_TAC [FIRSTN;CONV_RULE (ONCE_DEPTH_CONV SYM_CONV) NOT_NIL_CONS]
);;
%----------------------------------------------------------------------------%
%PC%
let FIRSTN_NULL = save_thm(`FIRSTN_NULL`,
    REWRITE_RULE[L_EQ_NIL] FIRSTN_NIL);;


%<-------------------------------------------------------------------------->%
let FIRSTN_APPEND1 = prove_thm (`FIRSTN_APPEND1`,
  "!(x:*) X n. (n <= LENGTH X) ==> (FIRSTN n (APPEND X [x]) = FIRSTN n X)",
 GEN_TAC THEN INDUCT_THEN list_INDUCT MP_TAC THENL
 [
  REWRITE_TAC [LENGTH;LESS_OR_EQ;NOT_LESS_0] THEN
  GEN_TAC THEN DISCH_THEN SUBST1_TAC THEN 
  REWRITE_TAC [FIRSTN]
  ;
  STRIP_TAC THEN GEN_TAC THEN INDUCT_TAC THENL
 [
  REWRITE_TAC [FIRSTN]
 ;
  REWRITE_TAC [LENGTH;LESS_EQ_MONO] THEN
  STRIP_TAC THEN RES_TAC THEN
  ASM_REWRITE_TAC [APPEND;FIRSTN;HD;TL]
 ]
 ]
);;
%----------------------------------------------------------------------------%

let FIRSTN_LENGTH_ID = prove_thm (
  `FIRSTN_LENGTH_ID`,
  "!X:* list. FIRSTN (LENGTH X) X = X",
  INDUCT_THEN list_INDUCT MP_TAC THEN
  REWRITE_TAC [LENGTH;ADD_CLAUSES;FIRSTN;TL;HD] THEN
  DISCH_THEN \t. REWRITE_TAC [t]
);;
%----------------------------------------------------------------------------%





let FIRSTN_FIRSTN = prove_thm (
  `FIRSTN_FIRSTN`,
  "!X:* list.!n m. (m <= LENGTH X) ==>
    (n <= m) ==> (FIRSTN n (FIRSTN m X) = FIRSTN n X)",
  INDUCT_THEN list_INDUCT ASSUME_TAC THENL
 [
  REPEAT GEN_TAC THEN 
  REWRITE_TAC [LENGTH] THEN
  DISCH_THEN \t. SUBST1_TAC (MATCH_MP LESS_EQ_0_EQ t)THEN
  REWRITE_TAC [FIRSTN]
 ;
  GEN_TAC THEN GEN_TAC THEN
  INDUCT_TAC THEN
  REWRITE_TAC [LENGTH;ADD_CLAUSES;FIRSTN;LESS_EQ_MONO;HD;TL] THENL
  [
  DISCH_TAC THEN 
  DISCH_THEN \t. SUBST1_TAC (MATCH_MP LESS_EQ_0_EQ t) THEN
  REWRITE_TAC [FIRSTN] 
  ;
  SPEC_TAC ("n:num","n:num") THEN
  INDUCT_TAC THEN
  REWRITE_TAC [FIRSTN;HD;TL;CONS_11;LESS_EQ_MONO] THEN
  REPEAT STRIP_TAC THEN RES_TAC
  ]
 ]
);;



%----------------------------------------------------------------------------%
%									     %
% 				FIRSTN - NTL				     %
%									     %
%----------------------------------------------------------------------------%

let APPEND_FIRSTN_NTL = prove_thm (
  `APPEND_FIRSTN_NTL`,
  "!X:* list. !n. 
   (n <= LENGTH X) ==> (APPEND (FIRSTN n X) (NTL n X) = X)",
  INDUCT_THEN list_INDUCT MP_TAC THEN
  REWRITE_TAC [LENGTH] THENL
 [
  GEN_TAC THEN DISCH_THEN \t. SUBST1_TAC (MATCH_MP LESS_EQ_0_EQ t) THEN
  REWRITE_TAC [FIRSTN;NTL;APPEND]
 ;
  DISCH_TAC THEN GEN_TAC THEN INDUCT_TAC THEN
  REWRITE_TAC [FIRSTN;NTL;APPEND;LESS_EQ_MONO;HD;TL;CONS_11] THEN
  FIRST_ASSUM MATCH_ACCEPT_TAC
 ]
);;



%   ***************************************************************************
    *                                                                         *
    *    Define the subsequence of a list as the first n elements.            *
    *                                                                         *
    *    SUBSEQ =                                                             *
    *    |- (!x. SUBSEQ 0 x = []) /\                                          *
    *    (!n x. SUBSEQ (SUC n) [] = []) /\                                    *
    *    (!n x. SUBSEQ (SUC n ) CONS(HD x)(TAIL x) =                          *
    *                      CONS(HD x)(SUBSEQ n(TAIL x)))                      *
    *                                                                         *
    ***********************************************************************   %

let SUBSEQ = new_prim_rec_definition (`SUBSEQ`,
"(SUBSEQ 0 (x:* list) = ([]:* list)) /\
 (SUBSEQ (SUC (n:num)) (x:* list) =
          NULL x => [] | CONS (HD x) (SUBSEQ n (TAIL x)))");;


%   **************************************************************************%

let SUBSEQ_EMPTY_LIST = prove_thm(`SUBSEQ_EMPTY_LIST`,
     "! (n:num). SUBSEQ n ([]:* list) = []",
  (INDUCT_TAC) THEN
  (REWRITE_TAC [SUBSEQ;NULL_EQ_EMPTY]));;
%   **************************************************************************%

let NULL_SUBSEQ = save_thm(`NULL_SUBSEQ`,
  REWRITE_RULE[L_EQ_NIL] SUBSEQ_EMPTY_LIST);;

%   ***************************************************************************
    *                                                                         *
    *    SUBSEQ_APPEND =                                                      *
    *    |- !x y n. SUBSEQ((LENGTH x) + n)(APPEND x y) = APPEND x(SUBSEQ n y) *
    *                                                                         *
    ***********************************************************************   %


let SUBSEQ_APPEND = prove_thm (`SUBSEQ_APPEND`,
"! (x:* list) (y:* list) (n:num).
        SUBSEQ ((LENGTH x) + n) (APPEND x y) = APPEND x (SUBSEQ n y)",
LIST_INDUCT_TAC
THENL [
REPEAT GEN_TAC THEN REWRITE_TAC [LENGTH; APPEND; ADD_CLAUSES];
REPEAT GEN_TAC THEN ASM_REWRITE_TAC [LENGTH;ADD_CLAUSES;APPEND;SUBSEQ;HD;CONS_11;CONJUNCT2 TAIL;NULL_EQ_EMPTY;NOT_CONS_NIL]]);;

%   ***************************************************************************
    *                                                                         *
    *    SUBSEQ_APPEND2 = |- !x y. SUBSEQ(LENGTH x)(APPEND x y) = x           *
    *                                                                         *
    ***********************************************************************   %

let SUBSEQ_APPEND2 = prove_thm (`SUBSEQ_APPEND2`,
"! (x:* list) (y:* list). SUBSEQ (LENGTH x) (APPEND x y) = x",
LIST_INDUCT_TAC
THENL [
REWRITE_TAC [LENGTH;SUBSEQ];
REPEAT GEN_TAC
THEN ASM_REWRITE_TAC [LENGTH;APPEND;SUBSEQ;HD;CONJUNCT2 TAIL;CONS_11;
                      NULL_EQ_EMPTY;NOT_CONS_NIL]]);;

%   ***************************************************************************
    *                                                                         *
    *    If two lists are equal then equal length subsequences will           *
    *    also be equal.                                                       *
    *                                                                         *
    *    SUBSEQ_EQ = |- !x y n. (x = y) ==> (SUBSEQ n x = SUBSEQ n y)         *
    *                                                                         *
    ***********************************************************************   %


let SUBSEQ_EQ = prove_thm (`SUBSEQ_EQ`,
"! (x:* list) (y:* list) (n:num). (x = y) ==> ((SUBSEQ n x) = (SUBSEQ n y))",
REPEAT GEN_TAC THEN DISCH_TAC THEN ASM_REWRITE_TAC []);;


%   ***************************************************************************
    *                                                                         *
    *   APPEND_SUBSEQ =                                                       *
    *   |- !r x y. (?n. r = APPEND x(SUBSEQ n y)) ==> (?a. r = APPEND x a)    *
    *                                                                         *
    ***********************************************************************   %

let APPEND_SUBSEQ = prove_thm (`APPEND_SUBSEQ`,
"! (r:* list) (x:* list) (y:* list). 
(? (n:num). (r = APPEND x (SUBSEQ n y))) ==>
(? (a:* list). (r = APPEND x a))",
REPEAT GEN_TAC
THEN DISCH_TAC
THEN POP_ASSUM (CHOOSE_THEN ASSUME_TAC)
THEN EXISTS_TAC "(SUBSEQ (n:num) (y:* list))"
THEN (ASM_REWRITE_TAC[]));;





%   ***************************************************************************
    *                                                                         *
    *   APPEND_SUBSEQ2 =                                                      *
    *   |- !r s x y.                                                          *
    *       (APPEND r s = APPEND x y) /\ (LENGTH x) <= (LENGTH r) ==>         *
    *       (?a. r = APPEND x a)                                              *
    *                                                                         *
    ***********************************************************************   %

% New proof by PC April 1993 %
let APPEND_SUBSEQ2 = prove_thm(`APPEND_SUBSEQ2`,
"! (r:* list) s x y.
     (((APPEND r s) = (APPEND x y)) /\ ((LENGTH x) <= (LENGTH r))) ==>
                  ? a. (r = (APPEND x a))",

 (LIST_INDUCT_TAC) THENL [

 (REWRITE_TAC[LENGTH]) THEN
 (REPEAT STRIP_TAC) THEN
 (IMP_RES_TAC LESS_EQ_0_EQ) THEN
 (IMP_RES_TAC LENGTH_NIL) THEN
 (EXISTS_TAC "[]:* list") THEN
 (ASM_REWRITE_TAC[APPEND]);

 (GEN_TAC THEN GEN_TAC) THEN
 (LIST_INDUCT_TAC) THENL [

 (REWRITE_TAC[APPEND]) THEN
 (REPEAT STRIP_TAC) THEN
 (EXISTS_TAC "CONS h r:* list") THEN
 (REWRITE_TAC[]);

 (REWRITE_TAC[LENGTH;APPEND]) THEN
 (REPEAT STRIP_TAC) THEN
 (IMP_RES_TAC CONS_11) THEN
 (IMP_RES_TAC (GSYM LESS_EQ_MONO)) THEN
 RES_TAC THEN
 (EXISTS_TAC "a':* list") THEN
 (ASM_REWRITE_TAC[])
]]);;

%   ***************************************************************************
    *                                                                         *
    *    SUBSEQUENCES =                                                       *
    *    |- !r s x y.                                                         *
    *    (APPEND r s = APPEND x y) ==>                                        *
    *    (?a. r = APPEND x a) \/ (?a. x = APPEND r a)                         *
    *                                                                         *
    ***********************************************************************   %
% New proof by PC April 1993 %

let SUBSEQUENCES = prove_thm (`SUBSEQUENCES`,
"! r (s:* list) x y.
      (APPEND r s = APPEND x y) ==> 
                              ((? (a:* list). r = APPEND x a) \/ 
                              ((? (a:* list). x = (APPEND r a))))",

  (LIST_INDUCT_TAC) THENL [

 (REWRITE_TAC[APPEND]) THEN
 (REPEAT STRIP_TAC) THEN
 DISJ2_TAC THEN
 (EXISTS_TAC "x:* list") THEN
 (ASM_REWRITE_TAC[]);

 (GEN_TAC THEN GEN_TAC) THEN
 (LIST_INDUCT_TAC) THENL [

 (REWRITE_TAC[APPEND]) THEN
 (REPEAT STRIP_TAC) THEN
 DISJ1_TAC THEN
 (EXISTS_TAC "CONS h r:* list") THEN
 (REWRITE_TAC[]);

 (REWRITE_TAC[APPEND]) THEN
 (REPEAT STRIP_TAC) THEN
 (IMP_RES_TAC CONS_11) THEN
 RES_TAC THENL [

 DISJ1_TAC THEN
 (EXISTS_TAC "a:* list") THEN
 (ASM_REWRITE_TAC[]);

 DISJ2_TAC THEN
 (EXISTS_TAC "a:* list") THEN
 (ASM_REWRITE_TAC[])

]]]);;





%   ***************************************************************************
    *                                                                         *
    *    SUBSEQ2 = |- !n x y. CONS x(SUBSEQ n y) = SUBSEQ(SUC n)(CONS x y)    *
    *                                                                         *
    ***********************************************************************   %

let SUBSEQ2 = prove_thm (`SUBSEQ2`,
"! (n:num) (x:*) (y:* list).CONS x (SUBSEQ n y) = SUBSEQ (SUC n) (CONS x y)",
INDUCT_TAC
THEN REWRITE_TAC [SUBSEQ; HD; CONJUNCT2 TAIL;NULL_EQ_EMPTY;NOT_CONS_NIL]);;

%   ***************************************************************************
    *                                                                         *
    *    SUBSEQ_SUBSEQ = |- !n x. SUBSEQ n(SUBSEQ n x) = SUBSEQ n x           *
    *                                                                         *
    ***********************************************************************   %

% New proof by PC April 1993 %
let SUBSEQ_SUBSEQ = prove_thm (`SUBSEQ_SUBSEQ`,
    "! (n:num) (x:* list). SUBSEQ n (SUBSEQ n x) = SUBSEQ n x",

INDUCT_TAC THENL
[
 (REWRITE_TAC [SUBSEQ]);

 (REPEAT GEN_TAC) THEN
 (REWRITE_TAC [SUBSEQ]) THEN
 (ASM_CASES_TAC "NULL (x:* list)") THEN
 (ASM_REWRITE_TAC[NULL;HD;TAIL])
]);;





%   ***************************************************************************
    *                                                                         *
    *    SUBSEQ_EXISTS =                                                      *
    *    |- !s n. ?a. s = APPEND(SUBSEQ n s)a                                 *
    *                                                                         *
    ***********************************************************************   %

% New proof by PC April 1993 %
let SUBSEQ_EXISTS = prove_thm (`SUBSEQ_EXISTS`,
    "! (s:* list) (n:num). ? (a:* list). s = APPEND (SUBSEQ n s) a",

 (LIST_INDUCT_TAC) THENL
 [
 (GEN_TAC) THEN
 (EXISTS_TAC "[]:* list") THEN
 (REWRITE_TAC [SUBSEQ_EMPTY_LIST;APPEND]);

 GEN_TAC THEN 
 INDUCT_TAC THENL [
 (EXISTS_TAC "CONS h s:* list") THEN
 (REWRITE_TAC [SUBSEQ;APPEND]);

 (REWRITE_TAC [SUBSEQ;APPEND;NULL;HD;TAIL;CONS_11])THEN
 (CHOOSE_THEN ASSUME_TAC
          (SPEC_ALL (ASSUME "!n. ?(a:* list). s = APPEND(SUBSEQ n s)a"))) THEN
 (EXISTS_TAC "a:* list") THEN
 (ACCEPT_TAC (ASSUME "s = APPEND(SUBSEQ n s)(a:* list)"))
]]);;


%   ***************************************************************************
    *                                                                         *
    *    SUBSEQ_MAP =                                                         *
    *    |- !n s f. (SUBSEQ n(MAP f s) = MAP f(SUBSEQ n s))                   *
    *                                                                         *
    ***********************************************************************   %


% New proof by PC April 1993 %
let SUBSEQ_MAP = prove_thm(`SUBSEQ_MAP`,
    "! (n:num) (s:* list) (f:*->*) .
         (SUBSEQ n (MAP f s) = MAP f (SUBSEQ n s))",
 INDUCT_TAC THENL 
 [
 (REWRITE_TAC [SUBSEQ;MAP]);

 (REPEAT GEN_TAC) THEN
 (REWRITE_TAC [SUBSEQ;NULL_MAP]) THEN
 COND_CASES_TAC THENL[
  (ASM_REWRITE_TAC[MAP]);
  (IMP_RES_TAC (INST_TYPE [(":*",":**")] HD_MAP)) THEN
  (ASM_REWRITE_TAC[MAP;TAIL_MAP]) 
]]);;


%****************************************************************************%
%                                                                            %
% AUTHOR        : Rachel Cardell-Oliver                      		     %
% DATE		: 1 August 1989, 9 May 90                                    %
%                                                                            %
%****************************************************************************%



%----------------------------------------------------------------------------%
% DEFINITIONS                                                                %
%----------------------------------------------------------------------------%

let NTAIL=
new_prim_rec_definition(
  `NTAIL`,
  "(NTAIL 0 (l:* list) = l) /\
   (NTAIL (SUC n) l = TAIL (NTAIL n l) ) ");;

% ----------------------------------------------------------------------- %

let NTAIL_NIL = prove_thm( `NTAIL_NIL`,
 "!n:num. NTAIL n ([]:* list) = []",
  INDUCT_TAC THEN ASM_REWRITE_TAC [NTAIL;TAIL] );;

%PC%
let NULL_NTAIL = save_thm(`NULL_NTAIL`,
  REWRITE_RULE[L_EQ_NIL] NTAIL_NIL);;

% ----------------------------------------------------------------------- %
let TAIL_NTAIL =  prove_thm(`TAIL_NTAIL`,
"!x (l:* list). TAIL (NTAIL x l) = NTAIL x (TAIL l)",
INDUCT_TAC
THENL
[ (REWRITE_TAC [NTAIL]);
  (ASM_REWRITE_TAC [NTAIL]) ]
);;
% ----------------------------------------------------------------------- %
let NOT_NULL_NTAIL  =  prove_thm(`NOT_NULL_NTAIL`,
"!x (l:* list). ~ (NULL (NTAIL x l)) ==> ~ (NULL l)",
INDUCT_TAC
THENL
[ (REWRITE_TAC [NTAIL;NULL]);
  (REWRITE_TAC [NTAIL;TAIL_NTAIL])
  THEN GEN_TAC
  THEN DISCH_TAC
  THEN RES_TAC
  THEN (IMP_RES_TAC NOT_NULL_TAIL) ]
);;

% ----------------------------------------------------------------------- %
let NTAIL_TAIL   =  prove_thm(`NTAIL_TAIL`,
"!x (l:* list). NTAIL x (TAIL l) = NTAIL (SUC x) l",
(REWRITE_TAC[NTAIL;TAIL_NTAIL]));;

% ----------------------------------------------------------------------- %

let EL_HD_NTAIL    =  prove_thm(`EL_HD_NTAIL`,
"!x:num. !l:* list.
   ~(NULL(NTAIL x l))  ==> 
         ((EL x l) = (HD (NTAIL x l)))",

INDUCT_TAC THENL
 [
 (REWRITE_TAC[EL;NTAIL]);

 (REWRITE_TAC[EL;NTAIL;TAIL_NTAIL]) THEN
 (REPEAT STRIP_TAC) THEN
 (IMP_RES_TAC NOT_NULL_NTAIL) THEN
 (IMP_RES_TAC NOT_NULL_TAIL) THEN
 (IMP_RES_TAC  TL_TAIL) THEN
 RES_TAC THEN
 (ASM_REWRITE_TAC[]) ]);;

% ----------------------------------------------------------------------- %
let NOT_NULL_NTAIL_TL =   prove_thm(`NOT_NULL_NTAIL_TL`,
"!x:num. !l:* list.
   ~(NULL(TAIL (NTAIL x l)))  ==> ~(NULL(NTAIL x (TL l)))",

 (REWRITE_TAC[TAIL_NTAIL]) THEN
 GEN_TAC THEN
 GEN_TAC THEN
 DISCH_TAC THEN
 (IMP_RES_TAC NOT_NULL_NTAIL) THEN
 (IMP_RES_TAC NOT_NULL_TAIL) THEN
 (IMP_RES_TAC  TL_TAIL) THEN
 (ASM_REWRITE_TAC[]) );;

% ----------------------------------------------------------------------- %
let EL_NTAIL_1 = prove_thm(`EL_NTAIL_1`,
"!x:num. !l:* list.
   ~(NULL(NTAIL x l)) 
   ==> 
    ((APPEND [EL x l] (NTAIL (x+1) l)) = (NTAIL x l))",

 INDUCT_TAC THENL
  [
   (REWRITE_TAC[SYM(SPEC_ALL ADD1);NTAIL;EL;TAIL;APPEND] THEN
   REPEAT STRIP_TAC THEN  IMP_RES_TAC CON);

   (GEN_TAC THEN
   ASM_CASES_TAC "~NULL(NTAIL x (l:* list))") THENL
    [
     (ASM_REWRITE_TAC[SYM(SPEC_ALL ADD1);NTAIL;EL;TAIL;APPEND;NULL]) THEN
     (REPEAT STRIP_TAC) THEN
     (IMP_RES_TAC NOT_NULL_NTAIL_TL) THEN
     (IMP_RES_TAC EL_HD_NTAIL) THEN
     (IMP_RES_TAC CON) THEN
     (IMP_RES_TAC NOT_NULL_NTAIL) THEN
     (IMP_RES_TAC  TL_TAIL) THEN
     (ASM_REWRITE_TAC[GSYM TAIL_NTAIL]);

     (ASM_REWRITE_TAC[SYM(SPEC_ALL ADD1);NTAIL;EL;TAIL;APPEND;NULL]) THEN
     (REPEAT STRIP_TAC) THEN
     (IMP_RES_TAC NOT_NULL_NTAIL_TL) THEN
     (IMP_RES_TAC NOT_NULL_TAIL) THEN
     RES_TAC
    ]
  ]);;

% ----------------------------------------------------------------------- %

let NTAIL_NTAIL =prove_thm(  `NTAIL_NTAIL`,
  "!x y:num. !l:* list. (NTAIL x (NTAIL y l)) = (NTAIL (x+y) l) ",
  INDUCT_TAC THEN
  ASM_REWRITE_TAC[NTAIL;ADD_CLAUSES] );;
% ----------------------------------------------------------------------- %

let LENGTH_NTAIL =prove_thm(  `LENGTH_NTAIL`,
  "!x:num. !l:* list.  LENGTH(NTAIL x l) = (LENGTH(l) - x)",
  INDUCT_TAC THENL
  [ REWRITE_TAC [NTAIL;SUB_0] ;
    GEN_TAC THEN ASM_REWRITE_TAC [NTAIL;TAIL] THEN
    ASM_CASES_TAC "NULL(NTAIL x (l:* list))" THENL
    [ IMP_RES_TAC (GSYM LENGTH_NULL) THEN
      ASM_REWRITE_TAC[LENGTH;ADD1;SUB_PLUS] THEN
      UNDISCH_TAC "!l:* list. LENGTH(NTAIL x l) = (LENGTH l) - x" THEN
      DISCH_TAC THEN POP_ASSUM (\thm. REWRITE_TAC[SYM (SPEC_ALL thm)]) THEN
      IMP_RES_TAC L_EQ_NIL THEN
      ASM_REWRITE_TAC[SUB_0;TAIL;LENGTH] ;
      IMP_RES_TAC LENGTH_TAIL THEN
      ASM_REWRITE_TAC[ADD1;SUB_PLUS] ] ] );;

% ----------------------------------------------------------------------- %

let LENGTH_NTAIL_LESS = prove_thm(`LENGTH_NTAIL_LESS`,
 "!l1 l2:* list. !x:num.
   ~(NULL l2) /\ (l1=(NTAIL x l2)) /\ 0<x ==>((LENGTH l1)<(LENGTH l2))",
  REPEAT STRIP_TAC THEN IMP_RES_TAC LENGTH_NOT_NULL THEN
  ASM_CASES_TAC "x<((LENGTH:* list -> num) l2)" THENL
  [ POP_ASSUM (ASSUME_TAC o ONCE_REWRITE_RULE[SUB_LESS_0]) THEN
    ASSUME_TAC (SPECL ["(LENGTH:* list -> num) l2";"x:num"] SUB_LESS_EQ) THEN
    POP_ASSUM (DISJ_CASES_TAC o REWRITE_RULE[LESS_OR_EQ]) THENL
    [ ASM_REWRITE_TAC[LENGTH_NTAIL] ;
      POP_ASSUM (\thm. MP_TAC thm) THEN IMP_RES_TAC (GSYM LESS_NOT_EQ) THEN
      ASM_REWRITE_TAC[SUB_EQ_EQ_0] ] ;
    POP_ASSUM (ASSUME_TAC o REWRITE_RULE[NOT_LESS;GSYM SUB_EQ_0]) THEN
    ASM_REWRITE_TAC[LENGTH_NTAIL] ] );;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   AUTHOR:       Paul Curzon                                                %
%   ORGANIZATION: University of Cambridge                                    %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%----------------------------------------------------------------------------%
% "!(l1:* list) (l2:* list). NTL(LENGTH l1)(APPEND l1 l2) = l2"              %
%----------------------------------------------------------------------------%
let NTL_LENGTH_APPEND = save_thm(`NTL_LENGTH_APPEND`,
      (GEN_ALL (REWRITE_RULE[LESS_EQ_REFL;NTL_LENGTH_NIL;APPEND]
        (SPECL ["l1:* list";"l2:* list";"LENGTH (l1:* list)"]  NTL_APPEND))));;



close_theory();;

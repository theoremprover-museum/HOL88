
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   FILE:         lastn.ml                                                   %
%   AUTHOR:       Wim Ploegaerts                                             %
%   ORGANIZATION: Imec vzw.                                                  %
%                 Kapeldreef 75                                              %
%                 3030 Leuven, Belgium                                       %
%   DATE:         31-5-1990                                                  %
%                                                                            %
%   DESCRIPTION:  LAST_N and NBUTLAST                                        %
%                                                                            %
%                                                                            %
%*********************************  HISTORY  ********************************%
%									     %
%	This file is taken from the list theories of                         %
%             Wim Ploegaerts                                                 %
%             Wai Wong                                                       %
%									     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%****************************************************************************%
%                                                                            %
%  DEPENDANCIES :                                                            %
%                                                                            %
%         library more_arithmetic  for arithmetic theorems                   %
%         general_lists            for general list theorems                 %
%         snoc2                    for SNOC theorems                         %
%         prim_rec                 for arithmetic theorems                   %
%         append                   for append theorems                       %
%         list_tactics             for list tactics                          %
%                                                                            %
%****************************************************************************%
system `rm -f last_subseq.th`;;

new_theory `last_subseq`;;

%< WW Use load_library instead of loadf
set_search_path (search_path()  @ 
		 [`../more_arithmetic/`;`../auxiliary/`]);;

loadf `more_arithmetic`;;
%PC 13/8/92 more_arithmetic is no longer dependent on auxiliary. snoc2 is %
loadf `auxiliary`;;
>%
load_library `more_arithmetic`;;
load_library `auxiliary`;;

new_parent `subseq`;;



let autoload_defs_and_thms thy =
   map (\name. autoload_theory(`definition`,thy,name))
     (map fst (definitions thy));
   map (\name. autoload_theory(`theorem`,thy,name))
     (map fst (theorems thy))in

autoload_defs_and_thms `general_lists`; 
autoload_defs_and_thms `snoc`;
autoload_defs_and_thms `subseq`;
autoload_defs_and_thms `el`;
autoload_defs_and_thms `ell`;
autoload_defs_and_thms `prim_rec`; 
autoload_defs_and_thms `append`;
autoload_defs_and_thms `map`;;

loadf `list_tactics`;;


%----------------------------------------------------------------------------%
%									     %
% 			   Apply "n" times BUTLAST			     %
%									     %
%----------------------------------------------------------------------------%


let NBUTLAST = new_prim_rec_definition (`NBUTLAST`,
    "(NBUTLAST 0 X = (X:(*)list)) /\
     (NBUTLAST (SUC n) X = NBUTLAST n (BUTLAST X))");;
%----------------------------------------------------------------------------%

let NBUTLAST_BUTLAST_SYM = prove_thm (`NBUTLAST_BUTLAST_SYM`,
  "!n (X:(*)list). NBUTLAST n (BUTLAST X) = BUTLAST (NBUTLAST n X)",
 INDUCT_THEN INDUCTION MP_TAC THEN
 REWRITE_TAC [NBUTLAST] THEN
 DISCH_THEN \t. GEN_TAC THEN REWRITE_TAC [t] 
);;
%----------------------------------------------------------------------------%

let NBUTLAST_SIMP_REC = prove_thm (`NBUTLAST_SIMP_REC`,
  "!n (X:(*)list).  NBUTLAST n X= SIMP_REC X BUTLAST n",
  INDUCT_THEN INDUCTION MP_TAC THEN
  REWRITE_TAC [NBUTLAST;SIMP_REC_THM;NBUTLAST_BUTLAST_SYM] THEN
  DISCH_THEN \t. REWRITE_TAC [t]
);;

%----------------------------------------------------------------------------%


let NBUTLAST_LENGTH = prove_thm (`NBUTLAST_LENGTH`,
  "!n (X:(*)list) .
     (n <= LENGTH X) ==> (LENGTH (NBUTLAST n X) = LENGTH X - n)",
   INDUCT_TAC THEN 
   INDUCT_THEN list_APPEND_INDUCT ASSUME_TAC THENL 
 [
   REWRITE_TAC [NBUTLAST;LENGTH;SUB]
 ;
   GEN_TAC THEN REWRITE_TAC [NBUTLAST;LENGTH;SUB_0]
 ;
   REWRITE_TAC [LENGTH;NOT_SUC_LESS_EQ_0]
 ;
   REWRITE_TAC [LENGTH_APPEND;LENGTH;ADD_CLAUSES;LESS_EQ_MONO;
		NBUTLAST;BUTLAST1;SUB_MONO_EQ] 
   THEN REPEAT STRIP_TAC THEN RES_TAC 
 ]
);;

%----------------------------------------------------------------------------%

let NBUTLAST_LENGTH_NIL = prove_thm (
  `NBUTLAST_LENGTH_NIL`,
  "!X:* list. NBUTLAST (LENGTH X) X = []",
  INDUCT_THEN list_APPEND_INDUCT MP_TAC THEN
  REWRITE_TAC [LENGTH_APPEND;LENGTH;ADD_CLAUSES;NBUTLAST;BUTLAST1]
);;

let NBUTLAST_LENGTH_NULL = save_thm(`NBUTLAST_LENGTH_NULL`,
    REWRITE_RULE[L_EQ_NIL] NBUTLAST_LENGTH_NIL);;

%----------------------------------------------------------------------------%
let NBUTLAST_NBUTLAST = prove_thm (
  `NBUTLAST_NBUTLAST`,
  "!X:* list . !n m.
     ((n + m) <= LENGTH X) ==> (NBUTLAST n (NBUTLAST m X) = NBUTLAST (n + m) X)",
  INDUCT_THEN list_APPEND_INDUCT ASSUME_TAC THENL
 [
  REPEAT GEN_TAC THEN 
  REWRITE_TAC [LENGTH] THEN
  DISCH_THEN \t. 
    let thm = MATCH_MP LESS_EQ_0_EQ t in
    REWRITE_TAC [REWRITE_RULE [ADD_EQ_0] thm;thm;NBUTLAST]
 ;
  GEN_TAC THEN
  INDUCT_TAC THEN
  GEN_TAC THEN
  REWRITE_TAC [ADD_CLAUSES;LENGTH;LENGTH_APPEND;
	       NBUTLAST;BUTLAST1;GSYM NBUTLAST_BUTLAST_SYM] THEN
  REWRITE_TAC [LESS_OR_EQ;INV_SUC_EQ;LESS_MONO_EQ] THEN
  REWRITE_TAC [GSYM LESS_OR_EQ] THEN
  FIRST_ASSUM MATCH_ACCEPT_TAC
 ]
);;
%----------------------------------------------------------------------------%
%									     %
% 		       The last "n" elements of a list			     %
%									     %
%----------------------------------------------------------------------------%


let LASTN = new_prim_rec_definition (`LASTN`,
    "(LASTN 0 (X:(*)list) = []) /\
     (LASTN (SUC n) X = APPEND (LASTN n (BUTLAST X)) [LAST X])");;

%----------------------------------------------------------------------------%

let LASTN_NIL = prove_thm (
  `LASTN_NIL`,
  "!n X. (LASTN n X = []:* list) ==> (n = 0)",
  INDUCT_TAC THEN 
  REWRITE_TAC [LASTN;CONV_RULE (ONCE_DEPTH_CONV SYM_CONV) NOT_NIL_APPEND_EL]
);;
%----------------------------------------------------------------------------%
%PC%
let LASTN_NULL = save_thm(`LASTN_NULL`,
    REWRITE_RULE[L_EQ_NIL] LASTN_NIL);;


%----------------------------------------------------------------------------%
let LASTN_CONS = prove_thm (`LASTN_CONS`,
  "!(x:*) X n. (n <= LENGTH X) ==> (LASTN n (CONS x X) = LASTN n X)",
  GEN_TAC THEN INDUCT_THEN list_APPEND_INDUCT MP_TAC THENL
 [
  REWRITE_TAC [LENGTH;LESS_OR_EQ;NOT_LESS_0] THEN
  GEN_TAC THEN DISCH_THEN SUBST1_TAC THEN 
  REWRITE_TAC [LASTN]
  ;
  STRIP_TAC THEN GEN_TAC THEN INDUCT_TAC THENL
 [
  REWRITE_TAC [LASTN]
 ;
  REWRITE_TAC [LENGTH;LENGTH_APPEND;ADD_CLAUSES;LESS_EQ_MONO] THEN
  STRIP_TAC THEN RES_TAC THEN
 ASM_REWRITE_TAC [GSYM (CONJUNCT2 APPEND);LASTN;BUTLAST1;LAST1]
 ]
 ]
);;
%----------------------------------------------------------------------------%

let LENGTH_LASTN = prove_thm (
  `LENGTH_LASTN`,
  "!n (X:(*)list). (n <= LENGTH X) ==> (LENGTH (LASTN n X) = n)",
  INDUCT_THEN INDUCTION MP_TAC THEN
  REWRITE_TAC [LASTN;LENGTH;INV_SUC_EQ;LENGTH_APPEND;ADD_CLAUSES] THEN
  DISCH_THEN \t . GEN_TAC THEN 
                  DISCH_THEN 
                      \t'.MATCH_MP_TAC  (SPEC "BUTLAST X:(*)list" t) THEN
                          MP_TAC t'  THEN
  ASM_CASES_TAC "X=[]:(*)list" THENL
 [ 
  ASM_REWRITE_TAC [NOT_SUC_LESS_EQ_0;LENGTH];
  SUBST1_TAC (SYM
      (MATCH_MP APPEND_BUTLAST_LAST
          (REWRITE_RULE[L_EQ_NIL] (ASSUME "~(X = ([]:* list))")) )) THEN
  REWRITE_TAC [BUTLAST1;LENGTH_APPEND;LENGTH;ADD_CLAUSES;LESS_EQ_MONO]
 ]);;

%----------------------------------------------------------------------------%
let APPEND_NBUTLAST_LASTN = prove_thm (`APPEND_NBUTLAST_LASTN`,
   "!n (X:(*)list) . (n <= LENGTH X) ==> (APPEND (NBUTLAST n X) (LASTN n X) = X)",
  INDUCT_THEN INDUCTION MP_TAC THEN
  REWRITE_TAC [LASTN;NBUTLAST;APPEND_NIL] THEN
  DISCH_THEN \t . GEN_TAC THEN 
                  MP_TAC (SPEC "BUTLAST X:(*)list" t) THEN
  ASM_CASES_TAC "X = []:(*)list" THEN
  ASM_REWRITE_TAC [NOT_SUC_LESS_EQ_0;LENGTH] THEN
  IMP_RES_TAC (REWRITE_RULE [GSYM L_EQ_NIL] APPEND_BUTLAST_LAST) THEN 
  POP_ASSUM (\t. SUBST1_TAC (SYM t) ? NO_TAC) THEN
  REWRITE_TAC [LAST1;BUTLAST1;LENGTH;LENGTH_APPEND;ADD_CLAUSES;LESS_EQ_MONO] THEN
  REPEAT STRIP_TAC THEN RES_TAC THEN
  ASM_REWRITE_TAC [APPEND_ASSOC]
);;
%----------------------------------------------------------------------------%
let LASTN_LENGTH_ID = prove_thm (
  `LASTN_LENGTH_ID`,
  "!X:* list. LASTN (LENGTH X) X = X",
  INDUCT_THEN list_APPEND_INDUCT MP_TAC THEN
  REWRITE_TAC [LENGTH_APPEND;LENGTH;ADD_CLAUSES;LASTN;BUTLAST1;LAST1] THEN
  DISCH_THEN \t. REWRITE_TAC [t;APPEND]
);;
%----------------------------------------------------------------------------%

let APPEND_FIRSTN_LASTN = prove_thm (
  `APPEND_FIRSTN_LASTN`,
  "!X:* list. !m n.
     (LENGTH X = m + n) ==> 
         (APPEND (FIRSTN n X) (LASTN m X) = X)",
  INDUCT_THEN list_INDUCT MP_TAC THEN
  REWRITE_TAC [LENGTH] THEN
  REPEAT GEN_TAC THENL
 [
 DISCH_THEN \t. 
  REWRITE_TAC [REWRITE_RULE [ADD_EQ_0]  (CONV_RULE SYM_CONV t);
		FIRSTN;LASTN;APPEND] 
 ;
 DISCH_TAC THEN GEN_TAC THEN GEN_TAC THEN INDUCT_TAC THEN
 REWRITE_TAC [ADD_CLAUSES;INV_SUC_EQ;FIRSTN;APPEND] THENL
  [
  DISCH_THEN (SUBST1_TAC  o SYM) THEN 
  ACCEPT_TAC (REWRITE_RULE [LENGTH] (SPEC "CONS h X:* list" LASTN_LENGTH_ID))
  ;
  REWRITE_TAC [TL;HD;CONS_11] THEN
  DISCH_THEN \t. 
     ASSUME_TAC t THEN RES_TAC THEN
     REWRITE_TAC [MATCH_MP LASTN_CONS 
		  (SUBS [SYM t] (SPECL ["m:num";"n:num"] LESS_EQ_ADD))] THEN
  FIRST_ASSUM ACCEPT_TAC
  ]
 ]
);;
%----------------------------------------------------------------------------%
let APPEND_NBUTLAST_NTL = prove_thm (
  `APPEND_NBUTLAST_NTL`,
  "!X:* list. !m n.
    (LENGTH X = m + n) ==> 
         (APPEND (NBUTLAST n X) (NTL m X) = X)",
  INDUCT_THEN list_APPEND_INDUCT MP_TAC THEN
  REWRITE_TAC [LENGTH;LENGTH_APPEND;ADD_CLAUSES] THEN
  REPEAT GEN_TAC THENL
 [
  DISCH_THEN \t. 
  REWRITE_TAC [REWRITE_RULE [ADD_EQ_0]  (CONV_RULE SYM_CONV t);
		NBUTLAST;NTL;APPEND] 
 ;
 DISCH_TAC THEN GEN_TAC THEN GEN_TAC THEN INDUCT_TAC THEN
 REWRITE_TAC [INV_SUC_EQ;NBUTLAST;ADD_CLAUSES] THENL
  [
   DISCH_THEN (SUBST1_TAC  o SYM) THEN
   REWRITE_TAC [APPEND_NIL;  
     (REWRITE_RULE [LENGTH_APPEND;LENGTH;ADD_CLAUSES]
       (SPEC "APPEND X [h]:* list" NTL_LENGTH_NIL))]
  ;
   REWRITE_TAC [BUTLAST1;LAST1;APPEND_EL_11] THEN
   DISCH_THEN \t. 
     ASSUME_TAC t THEN RES_TAC THEN
    REWRITE_TAC [MATCH_MP NTL_APPEND 
		   (SUBS [SYM t] (SPECL ["m:num";"n:num"] LESS_EQ_ADD));
		 APPEND_ASSOC;APPEND_EL_11] THEN
  FIRST_ASSUM ACCEPT_TAC
  ]
 ]
);;
%----------------------------------------------------------------------------%
let LASTN_LASTN = prove_thm (
  `LASTN_LASTN`,
  "!X:* list.!n m. (m <= LENGTH X) ==>
    (n <= m) ==> (LASTN n (LASTN m X) = LASTN n X)",
  INDUCT_THEN list_APPEND_INDUCT ASSUME_TAC THENL
 [
  REPEAT GEN_TAC THEN 
  REWRITE_TAC [LENGTH] THEN
  DISCH_THEN \t. SUBST1_TAC (MATCH_MP LESS_EQ_0_EQ t)THEN
  REWRITE_TAC [LASTN]
 ;
  GEN_TAC THEN GEN_TAC THEN
  INDUCT_TAC THEN
  REWRITE_TAC [LENGTH;LENGTH_APPEND;ADD_CLAUSES;
               LASTN;LESS_EQ_MONO;LAST1;BUTLAST1] THENL
  [
  DISCH_TAC THEN 
  DISCH_THEN \t. SUBST1_TAC (MATCH_MP LESS_EQ_0_EQ t) THEN
  REWRITE_TAC [LASTN] 
  ;
  SPEC_TAC ("n:num","n:num") THEN
  INDUCT_TAC THEN
  REWRITE_TAC [LASTN;LAST1;BUTLAST1;APPEND_EL_11;LESS_EQ_MONO] THEN
  REPEAT STRIP_TAC THEN RES_TAC
  ]
 ]
);;




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   AUTHOR:       Paul Curzon                                                %
%   ORGANIZATION: University of Cambridge                                    %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


let NBUTLAST_APPEND = prove_thm (`NBUTLAST_APPEND`,
   "!l1 l2:* list. !n. 
 (n <= LENGTH l2) ==> (NBUTLAST n (APPEND l1 l2) = APPEND l1 (NBUTLAST n l2))",
  GEN_TAC THEN INDUCT_THEN SNOC_INDUCT ASSUME_TAC THENL
 [
  REWRITE_TAC [LENGTH;APPEND_NIL] THEN
  REPEAT GEN_TAC THEN
  DISCH_THEN \t. SUBST1_TAC (MATCH_MP LESS_EQ_0_EQ t) THEN
  REWRITE_TAC [NBUTLAST;APPEND_NIL]
;
  GEN_TAC THEN INDUCT_TAC THEN
  REWRITE_TAC [NBUTLAST;APPEND_CLAUSES;BUTLAST;LESS_OR_EQ;LENGTH_CLAUSES;INV_SUC_EQ;LESS_MONO_EQ] THEN
  REWRITE_TAC [GSYM LESS_OR_EQ] THEN 
  FIRST_ASSUM MATCH_ACCEPT_TAC
]
 );;

%----------------------------------------------------------------------------%
% "!(l1:* list) (l2:* list). NBUTLAST(LENGTH l2)(APPEND l1 l2) = l1"         %
%----------------------------------------------------------------------------%
let NBUTLAST_LENGTH_APPEND = save_thm(`NBUTLAST_LENGTH_APPEND`,
      (GEN_ALL (REWRITE_RULE[LESS_EQ_REFL;NBUTLAST_LENGTH_NIL;APPEND]
        (SPECL ["l1:* list";"l2:* list";"LENGTH (l2:* list)"]  NBUTLAST_APPEND))));;


%----------------------------------------------------------------------------%
% Following theorems are added by Wai Wong on 2/4/1993			     %
%----------------------------------------------------------------------------%

let LASTN_LENGTH_APPEND = prove_thm(`LASTN_LENGTH_APPEND`,
    "!l1 (l2:* list). LASTN (LENGTH l2) (APPEND l1 l2) = l2",
    GEN_TAC THEN SNOC_INDUCT_TAC
    THEN REWRITE_TAC[LENGTH_CLAUSES;APPEND_CLAUSES;LASTN]
    THEN ASM_REWRITE_TAC[BUTLAST;LAST;SNOC_APPEND_CONS]);;

% |- !h l2 n.
    n <= (LENGTH l2) ==> (NBUTLAST n(CONS h l2) = CONS h(NBUTLAST n l2)) %

let NBUTLAST_CONS = save_thm(`NBUTLAST_CONS`,
   let athm = GEN_ALL(SPECL["[]:* list";"l2:* list";"h:*"](CONJUNCT2 APPEND))in
   GEN_ALL (PURE_REWRITE_RULE[athm;APPEND](SPEC "[h:*]" NBUTLAST_APPEND)));;

%  |- !l h. NBUTLAST(LENGTH l)(CONS h l) = [h] %

let NBUTLAST_LENGTH_CONS = save_thm(`NBUTLAST_LENGTH_CONS`,
    let thm1 = SPECL ["h:*"; "l:* list"; "LENGTH (l:* list)"] NBUTLAST_CONS in
    GEN_ALL(REWRITE_RULE[LESS_EQ_REFL;NBUTLAST_LENGTH_NIL] thm1));;

let NOT_NULL_NBUTLAST = prove_thm(`NOT_NULL_NBUTLAST`,
    "!k (l:* list). k < (LENGTH l) ==> ~NULL(NBUTLAST k l)",
    % LESS_SUC_LESS_OR_EQ = |- !m n. m < (SUC n) = m <= n %
    let LESS_SUC_LESS_OR_EQ = 
    	PURE_ONCE_REWRITE_RULE[GSYM LESS_OR_EQ]
        (PURE_ONCE_REWRITE_RULE[DISJ_SYM] LESS_THM) in
     INDUCT_TAC THEN LIST_INDUCT_TAC THENL[
      REWRITE_TAC[LENGTH;NOT_LESS_0];
      GEN_TAC THEN REWRITE_TAC[NBUTLAST;NULL];
      REWRITE_TAC[LENGTH;NOT_LESS_0];
      GEN_TAC THEN REWRITE_TAC[NBUTLAST;LESS_MONO_EQ;LENGTH]
      THEN ASM_CASES_TAC "NULL (l:* list)" THENL[
    	IMP_RES_THEN SUBST1_TAC NULL_EQ_EMPTY
    	THEN REWRITE_TAC[LENGTH;NOT_LESS_0];
    	IMP_RES_THEN (\t. PURE_ONCE_REWRITE_TAC[t]) BUTLAST_CONS_NOT_NULL
    	THEN IMP_RES_THEN MP_TAC LENGTH_BUTLAST
    	THEN IMP_RES_TAC LENGTH_NOT_NULL
    	THEN IMP_RES_THEN (\t. PURE_ONCE_REWRITE_TAC[t]) PRE_SUC_EQ
    	THEN DISCH_THEN (\t. SUBST1_TAC (SYM t))
    	THEN PURE_ONCE_REWRITE_TAC[LESS_SUC_LESS_OR_EQ] THEN DISCH_TAC
    	THEN IMP_RES_THEN (\t. PURE_ONCE_REWRITE_TAC[t]) NBUTLAST_CONS
    	THEN REWRITE_TAC[NULL]]]);;

let LAST_NBUTLAST_EL = prove_thm(`LAST_NBUTLAST_EL`,
    "!k (l:* list). k < (LENGTH l) ==> 
    (LAST(NBUTLAST k l) = EL(PRE((LENGTH l) - k))l)",
    let EL_CONS = PROVE(
       "! k l (y:*) . (0 < k) ==> (EL k (CONS y l) = EL (PRE k) l)",
       INDUCT_TAC THEN REWRITE_TAC[NOT_LESS_0;EL;TL;PRE]) in
    GEN_TAC THEN LIST_INDUCT_TAC THENL[
    	REWRITE_TAC[LENGTH;NOT_LESS_0];
      GEN_TAC THEN PURE_REWRITE_TAC[LENGTH;LESS_THM]
      THEN DISCH_THEN (DISJ_CASES_THEN2 SUBST1_TAC ASSUME_TAC) THENL[
        PURE_REWRITE_TAC[NBUTLAST_LENGTH_CONS;PRE_SUB;PRE]
        THEN PURE_REWRITE_TAC[LAST_EL;SUB_EQUAL_0;EL;HD] THEN REFL_TAC;
    	IMP_RES_TAC LESS_IMP_LESS_OR_EQ THEN RES_TAC
    	THEN IMP_RES_THEN (\t. SUBST1_TAC (SPEC_ALL t)) NBUTLAST_CONS
    	THEN PURE_REWRITE_TAC[PRE_SUB;PRE]
    	THEN PURE_ASM_REWRITE_TAC[LAST_CONS]
        THEN IMP_RES_THEN (\t. REWRITE_TAC[t])NOT_NULL_NBUTLAST
    	THEN MAP_EVERY IMP_RES_TAC [SUB_LESS_0;EL_CONS]
        THEN ASM_REWRITE_TAC[]]]);;

let EL_APPEND_1 = PROVE(
    "!(l1:* list) l2 k.
      (k < (LENGTH l1)) ==> ((EL k (APPEND l1 l2)) = (EL k l1))",
    LIST_INDUCT_TAC THENL[
     REWRITE_TAC[LENGTH;APPEND;EL] THEN REPEAT STRIP_TAC
     THEN IMP_RES_TAC NOT_LESS_0;
     REWRITE_TAC[LENGTH;APPEND;EL] THEN GEN_TAC THEN GEN_TAC
     THEN INDUCT_TAC THEN STRIP_TAC THEN REWRITE_TAC[EL;HD;TL]
     THEN (POP_ASSUM (\th. (ASSUME_TAC (REWRITE_RULE[LESS_MONO_EQ] th))))
     THEN RES_TAC THEN ASM_REWRITE_TAC[]]);;

let EL_NBUTLAST = prove_thm(`EL_NBUTLAST`,
    "!l:* list. !x k. (k < (LENGTH l)) /\ (x < ((LENGTH l) - k)) ==>
     (EL x (NBUTLAST k l) = EL x l)",
    REPEAT STRIP_TAC THEN IMP_RES_TAC LESS_IMP_LESS_OR_EQ
    THEN IMP_RES_THEN (\t.SUBST_OCCS_TAC [[2],(SYM t)]) APPEND_NBUTLAST_LASTN
    THEN UNDISCH_TAC "x < ((LENGTH (l:* list)) - k)"
    THEN IMP_RES_THEN (\t.SUBST1_TAC (SYM t)) NBUTLAST_LENGTH
    THEN DISCH_TAC THEN IMP_RES_TAC EL_APPEND_1
    THEN ASM_REWRITE_TAC[]);;

let NBUTLAST_SUC_SNOC = prove_thm(`NBUTLAST_SUC_SNOC`,
    "!l:* list. !x i. NBUTLAST (SUC i) (SNOC x l) = NBUTLAST i l",
    REWRITE_TAC[NBUTLAST;BUTLAST]);;

let LASTN_SUC_SNOC = prove_thm(`LASTN_SUC_SNOC`,
    "!l:* list. !x i. LASTN (SUC i) (SNOC x l) = SNOC x (LASTN i l)",
    REWRITE_TAC[LASTN;BUTLAST;LAST;SNOC_APPEND_CONS]);;

let LAST_LASTN = prove_thm(`LAST_LASTN`,
    "!(l:(*)list) m. (m <= LENGTH l) ==> (0 < m) ==>
     (LAST(LASTN m l) = LAST l)",
    SNOC_INDUCT_TAC THEN PURE_ONCE_REWRITE_TAC[LENGTH_CLAUSES] THENL[
     REPEAT GEN_TAC THEN DISCH_THEN (SUBST1_TAC o (MATCH_MP LESS_EQ_0_EQ))
     THEN REWRITE_TAC[NOT_LESS_0];
     GEN_TAC THEN INDUCT_TAC THENL[
      REWRITE_TAC[NOT_LESS_0];
      REPEAT STRIP_TAC THEN REWRITE_TAC[LASTN_SUC_SNOC;LAST]]]);;

let NBUTLAST_LASTN_NIL = prove_thm(`NBUTLAST_LASTN_NIL`,
    "!l:* list. !i. i <= (LENGTH l) ==> (NBUTLAST i(LASTN i l) = [])",
    REPEAT STRIP_TAC
    THEN IMP_RES_THEN (\t. SUBST_OCCS_TAC [[1],(SYM t)]) LENGTH_LASTN
    THEN MATCH_ACCEPT_TAC NBUTLAST_LENGTH_NIL);;

let LASTN_NBUTLAST = prove_thm(`LASTN_NBUTLAST`,
    "!l:* list. !i k. ((i + k) < LENGTH l) ==>
     (LASTN k (NBUTLAST i l) = NBUTLAST i (LASTN (i + k) l))",
    SNOC_INDUCT_TAC THENL[
      REWRITE_TAC[LENGTH;NOT_LESS_0];
      GEN_TAC THEN REPEAT INDUCT_TAC THENL[
        REWRITE_TAC[ADD_0;LASTN;NBUTLAST];
        REWRITE_TAC[ADD;NBUTLAST];
        PURE_REWRITE_TAC[ADD_0;LASTN_SUC_SNOC;NBUTLAST_SUC_SNOC;LASTN;
    	  LESS_MONO_EQ;LENGTH_CLAUSES] THEN DISCH_TAC
        THEN IMP_RES_TAC LESS_IMP_LESS_OR_EQ
    	THEN IMP_RES_THEN (\t.REWRITE_TAC[t]) NBUTLAST_LASTN_NIL;
        PURE_REWRITE_TAC[ADD;LENGTH_CLAUSES;LASTN_SUC_SNOC;NBUTLAST_SUC_SNOC;
    	  LESS_MONO_EQ] THEN FIRST_ASSUM MATCH_ACCEPT_TAC]]);;

let NBUTLAST_LASTN = prove_thm(`NBUTLAST_LASTN`,
    "!l:* list. !i k. ((i <= k) /\ (k <= LENGTH l)) ==>
     (NBUTLAST i (LASTN k l) = LASTN (k - i) (NBUTLAST i l))",
    PURE_ONCE_REWRITE_TAC[LESS_OR_EQ] THEN SNOC_INDUCT_TAC THENL[
      REWRITE_TAC[LENGTH;NOT_LESS_0] THEN REPEAT GEN_TAC
      THEN DISCH_THEN (CONJUNCTS_THEN2 MP_TAC SUBST1_TAC)
      THEN REWRITE_TAC[NOT_LESS_0] THEN DISCH_THEN SUBST1_TAC
      THEN REWRITE_TAC[LASTN;NBUTLAST;SUB];
      GEN_TAC THEN REPEAT INDUCT_TAC THENL[
        REWRITE_TAC[SUB_0;LASTN;NBUTLAST];
        REWRITE_TAC[SUB_0;NBUTLAST];
        REWRITE_TAC[NOT_LESS_0] THEN STRIP_TAC
    	THEN SUBST1_TAC(ASSUME"SUC i = 0")
    	THEN REWRITE_TAC[SUB_0;LASTN;NBUTLAST];
        REWRITE_TAC[LENGTH_CLAUSES;LASTN_SUC_SNOC;NBUTLAST_SUC_SNOC;
    	  INV_SUC_EQ;LESS_MONO_EQ;SUB_MONO_EQ]
    	  THEN FIRST_ASSUM MATCH_ACCEPT_TAC]]);;

let APPEND_LASTN_LASTN = prove_thm(`APPEND_LASTN_LASTN`,
    "!l:* list. !m1 m2. ((m1 + m2) <= (LENGTH l)) ==>
     (APPEND (LASTN m2 (NBUTLAST m1 l)) (LASTN m1 l) = LASTN (m1 + m2) l)",
    SNOC_INDUCT_TAC THENL[
      PURE_ONCE_REWRITE_TAC[LENGTH] THEN REPEAT STRIP_TAC
      THEN IMP_RES_THEN MP_TAC LESS_EQ_0_EQ
      THEN PURE_ONCE_REWRITE_TAC[ADD_EQ_0]
      THEN DISCH_THEN (CONJUNCTS_THEN SUBST1_TAC)
      THEN REWRITE_TAC[LASTN;ADD_0;APPEND_NIL];
      GEN_TAC THEN REPEAT INDUCT_TAC THENL[
        REWRITE_TAC[LASTN;APPEND_NIL;ADD_0];
        REWRITE_TAC[NBUTLAST;APPEND_NIL;ADD;(CONJUNCT1 LASTN)];
        REWRITE_TAC[APPEND_NIL;ADD_0;(CONJUNCT1 LASTN)];
        PURE_REWRITE_TAC[NBUTLAST_SUC_SNOC;LASTN_SUC_SNOC]
        THEN PURE_ONCE_REWRITE_TAC[APPEND_CLAUSES;ADD]
        THEN PURE_ONCE_REWRITE_TAC[LENGTH_CLAUSES]
        THEN PURE_ONCE_REWRITE_TAC[LESS_EQ_MONO]
    	THEN DISCH_TAC THEN RES_TAC
    	THEN ASM_REWRITE_TAC[LASTN_SUC_SNOC]]]);;

let LAST_TO_LASTN = prove_thm(`LAST_TO_LASTN`,
    "!l:* list. ~(NULL l) ==> ([LAST l] = LASTN 1 l)",
    SNOC_INDUCT_TAC THENL[
      REWRITE_TAC[NULL];
      REPEAT STRIP_TAC THEN CONV_TAC (ONCE_DEPTH_CONV num_CONV)
      THEN REWRITE_TAC[LASTN;APPEND_NIL]]);;

let BUTLAST_TO_NBUTLAST = prove_thm(`BUTLAST_TO_NBUTLAST`,
    "!l:* list. ~(NULL l) ==> (BUTLAST l = NBUTLAST 1 l)",
    SNOC_INDUCT_TAC THENL[
      REWRITE_TAC[NULL];
      REPEAT STRIP_TAC THEN CONV_TAC (ONCE_DEPTH_CONV num_CONV)
      THEN REWRITE_TAC[NBUTLAST]]);;

let LASTN_NBUTLAST_TL_SPLIT = prove_thm(`LASTN_NBUTLAST_TL_SPLIT`,
    "!l:* list. !m k. (0 < m) /\ ((k + m) < (LENGTH l)) ==>
     ((LASTN m (NBUTLAST k l)) =
       APPEND (LASTN (m -1)(NBUTLAST (k + 1) l)) (LASTN 1 (NBUTLAST k l)))",
    SNOC_INDUCT_TAC THENL[
      REWRITE_TAC[LENGTH;NOT_LESS_0];
      GEN_TAC THEN INDUCT_TAC THENL[
        REWRITE_TAC[NOT_LESS_0];
        REPEAT STRIP_TAC THEN PURE_ONCE_REWRITE_TAC[LASTN]
    	THEN IMP_RES_TAC SUM_LESS
    	THEN SUBGOAL_THEN "~NULL(NBUTLAST k (SNOC (h:*) l))" ASSUME_TAC THENL[
         PURE_ONCE_REWRITE_TAC[GSYM LENGTH_NOT_NULL]
    	 THEN SUBST1_TAC (MATCH_MP NBUTLAST_LENGTH
    	    (MATCH_MP LESS_IMP_LESS_OR_EQ(ASSUME "k<(LENGTH(SNOC(h:*)l))")))
    	 THEN PURE_ONCE_REWRITE_TAC[GSYM SUB_LESS_0]
    	 THEN FIRST_ASSUM ACCEPT_TAC;
    	 IMP_RES_THEN (\t. SUBST1_TAC (SYM t)) LAST_TO_LASTN
    	 THEN REWRITE_TAC[APPEND_EL_11]
    	 THEN SUBST_OCCS_TAC [[1],SUC_0]
    	 THEN PURE_REWRITE_TAC[SUB_MONO_EQ;SUB_0] THEN AP_TERM_TAC
    	 THEN IMP_RES_THEN SUBST1_TAC BUTLAST_TO_NBUTLAST
    	 THEN PURE_ONCE_REWRITE_TAC[ADD_SYM]
    	 THEN MATCH_MP_TAC NBUTLAST_NBUTLAST
    	 THEN PURE_ONCE_REWRITE_TAC[ADD_SYM]
    	 THEN PURE_REWRITE_TAC[(GSYM ADD1);LESS_EQ_LESS_SUC;LESS_MONO_EQ]
    	 THEN FIRST_ASSUM ACCEPT_TAC]]]);;

let NBUTLAST_APPEND1 = prove_thm(`NBUTLAST_APPEND1`,
    "!(l1:* list) l2 k. (LENGTH l2 <= k) ==>
     (NBUTLAST k (APPEND l1 l2) = NBUTLAST (k - (LENGTH l2)) l1)",
    GEN_TAC THEN SNOC_INDUCT_TAC
    THEN REWRITE_TAC[LENGTH_CLAUSES;APPEND_CLAUSES;SUB_0]
    THEN GEN_TAC THEN INDUCT_TAC THENL[
      REWRITE_TAC[NOT_SUC_LESS_EQ_0];
      PURE_ONCE_REWRITE_TAC[LESS_EQ_MONO;NBUTLAST_SUC_SNOC;SUB_MONO_EQ]
      THEN FIRST_ASSUM MATCH_ACCEPT_TAC]);;

let LASTN_APPEND = prove_thm(`LASTN_APPEND`,
    "!l1 (l2:* list) n. n <= (LENGTH l2) ==>
     (LASTN n (APPEND l1 l2) = LASTN n l2)",
    GEN_TAC THEN SNOC_INDUCT_TAC THENL[
      REWRITE_TAC[LENGTH_CLAUSES;APPEND_CLAUSES;LASTN]
      THEN GEN_TAC THEN DISCH_THEN (SUBST1_TAC o (MATCH_MP LESS_EQ_0_EQ))
      THEN REWRITE_TAC[LASTN];
      GEN_TAC THEN INDUCT_TAC THENL[
    	REWRITE_TAC[LASTN];
    	REWRITE_TAC[LENGTH_CLAUSES;APPEND_CLAUSES;LASTN_SUC_SNOC;LESS_EQ_MONO]
    	THEN DISCH_TAC THEN RES_THEN SUBST1_TAC THEN REFL_TAC]]);;

let LASTN_APPEND2 = prove_thm(`LASTN_APPEND2`,
    "!l1 (l2:* list) n. (LENGTH l2) <= n ==>
     (LASTN n (APPEND l1 l2) = APPEND (LASTN (n - (LENGTH l2)) l1) l2)",
    GEN_TAC THEN SNOC_INDUCT_TAC THENL[
      REWRITE_TAC[LENGTH_CLAUSES;APPEND_CLAUSES;LASTN;SUB_0];
      GEN_TAC THEN INDUCT_TAC THENL[
    	REWRITE_TAC[LENGTH_CLAUSES;NOT_SUC_LESS_EQ_0];
    	REWRITE_TAC[LENGTH_CLAUSES;APPEND_CLAUSES;LASTN_SUC_SNOC;
    	    LESS_EQ_MONO;SUB_MONO_EQ]
    	THEN DISCH_TAC THEN RES_THEN SUBST1_TAC THEN REFL_TAC]]);;

let LASTN_MAP = prove_thm(`LASTN_MAP`,
    "!(f:*->**) l n. (n <= LENGTH l) ==>
     (LASTN n (MAP f l) = MAP f (LASTN n l))",
    GEN_TAC THEN SNOC_INDUCT_TAC THEN GEN_TAC THENL[
      PURE_ONCE_REWRITE_TAC[LENGTH]
      THEN DISCH_THEN (SUBST1_TAC o (MATCH_MP LESS_EQ_0_EQ))
      THEN REWRITE_TAC[LASTN;MAP];
      INDUCT_TAC THENL[
        REWRITE_TAC[LASTN;MAP];
    	PURE_REWRITE_TAC[LENGTH_CLAUSES;LESS_EQ_MONO;MAP_SNOC;LASTN_SUC_SNOC]
    	THEN DISCH_TAC THEN RES_TAC THEN ASM_REWRITE_TAC[]]]);;

let NBUTLAST_MAP = prove_thm(`NBUTLAST_MAP`,
    "!(f:*->**) l n. (n <= LENGTH l) ==>
     (NBUTLAST n (MAP f l) = MAP f (NBUTLAST n l))",
    GEN_TAC THEN SNOC_INDUCT_TAC THEN GEN_TAC THENL[
     PURE_ONCE_REWRITE_TAC[LENGTH]
     THEN DISCH_THEN (SUBST1_TAC o (MATCH_MP LESS_EQ_0_EQ))
     THEN REWRITE_TAC[NBUTLAST;MAP];
     INDUCT_TAC THENL[
      REWRITE_TAC[NBUTLAST;MAP];
      PURE_REWRITE_TAC[LENGTH_CLAUSES;LESS_EQ_MONO;MAP_SNOC;NBUTLAST_SUC_SNOC]
      THEN DISCH_TAC THEN RES_TAC THEN FIRST_ASSUM ACCEPT_TAC]]);;

% LESS_EQ_SUC_LESS_EQ_EQ = |- !m n. m <= (SUC n) = m <= n \/ (m = SUC n) %
let LESS_EQ_SUC_LESS_EQ_EQ =
     let lethm = SYM (SPEC_ALL LESS_OR_EQ) in
     let lsthm = PURE_ONCE_REWRITE_RULE[DISJ_SYM](SPEC_ALL LESS_THM) in
    GEN_ALL (SUBS[(TRANS lsthm lethm)] (SPECL["m:num";"SUC n"] LESS_OR_EQ));;
  
let LENGTH_MAP2_LEMMA = PROVE(
    "!(f:*->**->***) l1 l2. (LENGTH l1 = LENGTH l2) ==>
     ((LENGTH(MAP2 f l1 l2) = LENGTH l1) /\
      (LENGTH(MAP2 f l1 l2) = LENGTH l2))",
    GEN_TAC THEN LIST_INDUCT_TAC THENL[
      LIST_INDUCT_TAC THENL[
    	DISCH_TAC THEN PURE_ONCE_REWRITE_TAC[MAP2]
    	THEN PURE_ONCE_REWRITE_TAC[LENGTH] THEN CONJ_TAC THEN REFL_TAC;
    	GEN_TAC THEN PURE_ONCE_REWRITE_TAC[LENGTH]
    	THEN REWRITE_TAC[SUC_NOT]];
      GEN_TAC THEN LIST_INDUCT_TAC THENL[
    	PURE_ONCE_REWRITE_TAC[LENGTH] THEN REWRITE_TAC[NOT_SUC];
    	GEN_TAC THEN PURE_ONCE_REWRITE_TAC[MAP2]
    	THEN PURE_ONCE_REWRITE_TAC[LENGTH]
    	THEN PURE_ONCE_REWRITE_TAC[INV_SUC_EQ]
    	THEN DISCH_TAC THEN RES_TAC
    	THEN CONJ_TAC THEN FIRST_ASSUM ACCEPT_TAC]]);;

let LASTN_MAP2 = prove_thm(`LASTN_MAP2`,
    "!(f:*->**->***) l1 l2 n. (LENGTH l1 = LENGTH l2) ==>
     (n <= LENGTH l1) ==>
     (LASTN n (MAP2 f l1 l2) = MAP2 f (LASTN n l1) (LASTN n l2))",
    let LENGTH_MAP21 = GEN_ALL (DISCH_ALL (CONJUNCT1
     (UNDISCH_ALL (SPEC_ALL LENGTH_MAP2_LEMMA)))) in
    GEN_TAC THEN EQ_LENGTH_INDUCT_TAC THENL[
      PURE_ONCE_REWRITE_TAC[LENGTH] THEN GEN_TAC 
      THEN DISCH_THEN (SUBST1_TAC o (MATCH_MP LESS_EQ_0_EQ))
      THEN REWRITE_TAC[LASTN;MAP2];
      PURE_ONCE_REWRITE_TAC[LESS_EQ_SUC_LESS_EQ_EQ]
      THEN GEN_TAC THEN DISCH_THEN (DISJ_CASES_THEN2 ASSUME_TAC SUBST1_TAC)
      THENL[
       PURE_ONCE_REWRITE_TAC[MAP2]
       THEN FIRST_ASSUM (ASSUME_TAC o
    	 (SUBS[ASSUME"LENGTH (l1:* list) = LENGTH (l2:** list)"]))
       THEN FIRST_ASSUM (ASSUME_TAC o CONJUNCT2 o
    	 (SPEC "f:*->**->***") o (MATCH_MP LENGTH_MAP2_LEMMA))
       THEN POP_ASSUM (\t. FIRST_ASSUM (\t2. ASSUME_TAC(SUBS[SYM t]t2)))
       THEN IMP_RES_TAC LASTN_CONS
       THEN ASM_REWRITE_TAC[] THEN RES_TAC;
       let lem1 = GEN_ALL (PURE_ONCE_REWRITE_RULE[LENGTH]
    	(SPEC "CONS (h:*) l" LASTN_LENGTH_ID)) in
       IMP_RES_THEN (\t. SUBST_OCCS_TAC[[1], (SYM(ISPEC "f:*->**->***" t))])
    	 LENGTH_MAP21
       THEN SUBST_OCCS_TAC[[2],
    	 (ASSUME "LENGTH (l1:* list) = LENGTH (l2:** list)")]
       THEN REWRITE_TAC[lem1;MAP2]]]);;

let NBUTLAST_MAP2 = prove_thm(`NBUTLAST_MAP2`,
    "!(f:*->**->***) l1 l2 n. (LENGTH l1 = LENGTH l2) ==>
     (n <= LENGTH l1) ==>
     (NBUTLAST n (MAP2 f l1 l2) = MAP2 f (NBUTLAST n l1) (NBUTLAST n l2))",
    GEN_TAC THEN EQ_LENGTH_SNOC_INDUCT_TAC THENL[
      PURE_ONCE_REWRITE_TAC[LENGTH] THEN GEN_TAC
      THEN DISCH_THEN (SUBST1_TAC o (MATCH_MP LESS_EQ_0_EQ))
      THEN REWRITE_TAC[NBUTLAST;MAP2];
      PURE_ONCE_REWRITE_TAC[LESS_EQ_SUC_LESS_EQ_EQ]
      THEN INDUCT_TAC THENL[
        REWRITE_TAC[NBUTLAST];
    	IMP_RES_THEN (\t.PURE_REWRITE_TAC[t]) MAP2_SNOC
        THEN REWRITE_TAC[NBUTLAST_SUC_SNOC;INV_SUC_EQ]
    	THEN RES_TAC THEN DISCH_TAC THEN FIRST_ASSUM MATCH_MP_TAC
    	THEN PURE_ONCE_REWRITE_TAC[LESS_OR_EQ]
    	THEN PURE_ONCE_REWRITE_TAC[LESS_EQ]
    	THEN FIRST_ASSUM ACCEPT_TAC]]);;

% |- !k l. k < (LENGTH l) ==> (LAST(NBUTLAST k l) = ELL k l) %
let LAST_NBUTLAST_ELL = save_thm(`LAST_NBUTLAST_ELL`,
    GEN_ALL(DISCH_ALL (TRANS (UNDISCH_ALL(SPEC_ALL LAST_NBUTLAST_EL))
        (SYM (UNDISCH_ALL(SPEC_ALL ELL_EL))))));;

let ELL_NBUTLAST = prove_thm(`ELL_NBUTLAST`,
    "!(l:(*)list) k j. ((j+k)<= LENGTH l) ==>
     (ELL j (NBUTLAST k l) = ELL (j+k) l)",
    SNOC_INDUCT_TAC THEN PURE_ONCE_REWRITE_TAC[LENGTH_CLAUSES] THENL[
     REPEAT GEN_TAC THEN DISCH_THEN (MP_TAC o (MATCH_MP LESS_EQ_0_EQ))
     THEN PURE_ONCE_REWRITE_TAC[ADD_EQ_0]
     THEN DISCH_THEN (SUBST_TAC o CONJUNCTS)
     THEN REWRITE_TAC[NBUTLAST;ADD_0];
     GEN_TAC THEN INDUCT_TAC THENL[
      REWRITE_TAC[NBUTLAST;ADD_0];
      PURE_REWRITE_TAC[NBUTLAST_SUC_SNOC;ELL_SUC_SNOC;ADD_CLAUSES;LESS_EQ_MONO]
      THEN FIRST_ASSUM MATCH_ACCEPT_TAC]]);;

let ELL_LASTN = prove_thm(`ELL_LASTN`,
    "!(l:(*)list) m j. (m <= LENGTH l) ==> (j < m) ==>
     (ELL j (LASTN m l) = ELL j l)",
    SNOC_INDUCT_TAC THEN PURE_ONCE_REWRITE_TAC[LENGTH_CLAUSES] THENL[
     REPEAT GEN_TAC THEN DISCH_THEN (SUBST1_TAC o (MATCH_MP LESS_EQ_0_EQ))
     THEN REWRITE_TAC[NOT_LESS_0];
     GEN_TAC THEN INDUCT_TAC THENL[
      REWRITE_TAC[NOT_LESS_0];
      INDUCT_TAC THENL[
       PURE_ONCE_REWRITE_TAC[ELL] THEN DISCH_TAC
       THEN MATCH_MP_TAC LAST_LASTN THEN PURE_REWRITE_TAC[LENGTH_CLAUSES]
       THEN FIRST_ASSUM ACCEPT_TAC;
        PURE_REWRITE_TAC[LESS_MONO_EQ;LESS_EQ_MONO;LASTN_SUC_SNOC;ELL_SUC_SNOC]
    	THEN REPEAT DISCH_TAC THEN RES_TAC]]]);;

% Proof modified by PC April 1993 %
let LASTN_NBUTLAST_APPEND = prove_thm(`LASTN_NBUTLAST_APPEND`,
    "!(l1:* list) l2 m k. (m + k) <= ((LENGTH l1) + (LENGTH l2)) /\
      k < (LENGTH l2) /\ (LENGTH l2) <= (m + k) ==>
     (LASTN m(NBUTLAST k(APPEND l1 l2)) =
      (APPEND (LASTN((m + k) - (LENGTH l2)) l1)
    	      (LASTN((LENGTH l2) - k)(NBUTLAST k l2))))",

    LIST_INDUCT_TAC THENL[
      REPEAT GEN_TAC THEN PURE_REWRITE_TAC[LENGTH;ADD;APPEND_CLAUSES]
      THEN STRIP_TAC THEN IMP_RES_TAC LESS_EQUAL_ANTISYM
      THEN POP_ASSUM SUBST1_TAC THEN POP_ASSUM (\t. SUBST_OCCS_TAC[[3],t])
      THEN REWRITE_TAC[SUB_EQUAL_0;ADD_SUB;LASTN;APPEND_CLAUSES];

      GEN_TAC THEN SNOC_INDUCT_TAC THENL[
    	REWRITE_TAC[LENGTH;NOT_LESS_0];

    	GEN_TAC THEN GEN_TAC THEN INDUCT_TAC THENL[
    	  PURE_REWRITE_TAC[SUB_0;ADD_0;NBUTLAST;LASTN_LENGTH_ID]
    	  THEN STRIP_TAC 
    	  THEN FIRST_ASSUM (\t. REWRITE_TAC[MATCH_MP LASTN_APPEND2 t]);

    	  PURE_ONCE_REWRITE_TAC[el 4(CONJ_LIST 4 APPEND_CLAUSES)]
    	  THEN PURE_ONCE_REWRITE_TAC[NBUTLAST_SUC_SNOC]
    	  THEN PURE_ONCE_REWRITE_TAC[LENGTH_CLAUSES]
    	  THEN PURE_REWRITE_TAC[ADD_CLAUSES;SUB_MONO_EQ;
    	    LESS_MONO_EQ;LESS_EQ_MONO]
    	  THEN STRIP_TAC THEN
          let th1 = MATCH_MP LESS_IMP_LESS_OR_EQ
                               (ASSUME "k < (LENGTH (l2:* list))") in
          let th2 = MATCH_MP (GSYM NBUTLAST_LENGTH) th1 in
          let th3 = MATCH_MP NBUTLAST_LENGTH th1 in
          let th4 = SPECL ["CONS h (l1:* list)";"NBUTLAST k (l2:* list)";
                           "m:num"] LASTN_APPEND2 in
          let th5 = REWRITE_RULE[th3]th4 in
          let th6 = ONCE_REWRITE_RULE[ADD_SYM]
                               (MATCH_MP SUB_LESS_EQ_ADD th1) in
          let th7 = REWRITE_RULE[th6]th5 in
          let th8 = MATCH_MP th7 (ASSUME "(LENGTH (l2:* list)) <= (m + k)") in
          let th9 = MATCH_MP SUB_SUB th1 in

          REWRITE_TAC[th2] THEN
          PURE_ONCE_REWRITE_TAC[LASTN_LENGTH_ID] THEN
          REWRITE_TAC[MATCH_MP NBUTLAST_APPEND  th1;th8;th9] ]]]);;

% Added by WW on 13 May 1993 %
let EVERY_LASTN = prove_thm(`EVERY_LASTN`,
    "!P (l:* list). EVERY P l ==>
     (!m. m <= (LENGTH l) ==> EVERY P (LASTN m l))",
    GEN_TAC THEN LIST_INDUCT_TAC THENL[
     REWRITE_TAC[EVERY_DEF;LENGTH] THEN REPEAT STRIP_TAC
     THEN IMP_RES_THEN SUBST1_TAC LESS_EQ_0_EQ
     THEN REWRITE_TAC[EVERY_DEF;LASTN];
     REWRITE_TAC[EVERY_DEF;LENGTH;LESS_OR_EQ;LESS_THM]
     THEN REPEAT STRIP_TAC THENL[
      IMP_RES_THEN (\t.REWRITE_TAC[t]) (REWRITE_RULE[LESS_OR_EQ]LASTN_CONS)
      THEN RES_THEN MATCH_MP_TAC THEN ASM_REWRITE_TAC[LESS_OR_EQ];
      IMP_RES_THEN (\t.REWRITE_TAC[t]) (REWRITE_RULE[LESS_OR_EQ]LASTN_CONS)
      THEN RES_THEN MATCH_MP_TAC THEN ASM_REWRITE_TAC[LESS_OR_EQ];
      FIRST_ASSUM SUBST1_TAC
      THEN SUBST1_TAC (REWRITE_RULE[LENGTH](SPEC"CONS(h:*)l"LASTN_LENGTH_ID))
      THEN ASM_REWRITE_TAC[EVERY_DEF]]]);;

close_theory();;

%----------------------------------------------------------------------------%


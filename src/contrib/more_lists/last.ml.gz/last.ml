%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   FILE:         last.ml                                                    %
%   EDITOR:       Paul Curzon                                                %
%   ORGANIZATION: U Cambridge CL                                             %
%   DATE:         5-4-1991                                                   %
%   DESCRIPTION:  Additional theorems about SNOC, REVERSE and APPEND t [h]   %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%*********************************  HISTORY  ********************************%
%									     %
%   This file is based on the theories by				     %
%      Paul Loewenstein, and 						     %
%      Wim Ploegaerts   (Imec vzw Leuven, Belgium),and			     %
%      Rachel Cardell-Oliver 						     %
%   Additional theorems from 						     %
%      Paul Curzon 							     %
%  have been added and the proofs of some altered to make use of earlier     %
%  (SNOC) theorems                                                           %
%                                                                            %
%  The names of some theorems have been changed from the original sources    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%****************************************************************************%
%                                                                            %
%  DEPENDANCIES :                                                            %
%                                                                            %
%         library more_arithmetic  for arithmetic theorems                   %
%         general_lists            for general list theorems                 %
%         snoc                     for SNOC theorems                         %
%         clauses                  for CLAUSE theorems                       %
%         snoc2                    for SNOC theorems                         %
%                                                                            %
%****************************************************************************%


%****************************************************************************%
% AUTHOR        : Paul Loewenstein                      		     %
% DATE		: 2 June 1989	                                             %
%                                                                            %
%****************************************************************************%

let LAST_DEF = new_definition (`LAST_DEF`,
 "LAST (l:(*)list) = @h. ?t. SNOC h t = l");;


% see also BUTLAST%
let BUTLAST_DEF = new_definition (`BUTLAST_DEF`,
 "BUTLAST (l:(*)list) = @t. SNOC (LAST l) t = l");;

%<-------------------------------------------------------------------------->%


let LAST_BUTLAST_exist = prove_thm(`LAST_BUTLAST_exist`,
 "! (l:(*)list). ~NULL l ==> ?h t. SNOC h t = l",
 LIST_INDUCT_TAC THEN
 REWRITE_TAC[NULL] THEN
 GEN_TAC THEN
 ASM_CASES_TAC "NULL (l:(*)list)" THENL
 [
  EXISTS_TAC "(h:*)" THEN
  EXISTS_TAC "([]:(*)list)" THEN
  POP_ASSUM (ASSUME_TAC o (PURE_REWRITE_RULE[NULL_EQ_EMPTY]))
 ;
  RES_THEN ASSUME_TAC THEN
  POP_ASSUM (ASSUME_TAC o SELECT_RULE) THEN
  POP_ASSUM (ASSUME_TAC o SELECT_RULE) THEN
  EXISTS_TAC "@h':*. ?t':(*)list. SNOC h' t' = l" THEN
  EXISTS_TAC
   "CONS (h:*) (@t:(*)list. SNOC(@h':*. ?t':(*)list. SNOC h' t' = l)t = l)"
 ] THEN
 ASM_REWRITE_TAC[SNOC_DEF]);;
%<-------------------------------------------------------------------------->%

% |- !l. ~NULL l ==> (SNOC(LAST l)(BUTLAST l) = l) %


let SNOC = save_thm(`SNOC`,
GEN_ALL (DISCH_ALL
 (REWRITE_RULE[SYM (SPEC_ALL BUTLAST_DEF);SYM (SPEC_ALL LAST_DEF)]
  (SELECT_RULE (SELECT_RULE (UNDISCH (SPEC_ALL LAST_BUTLAST_exist)))))));;
%<-------------------------------------------------------------------------->%

let LAST_BUTLAST_lemma =
 MP (SPECL ["LAST(SNOC h t):*";"BUTLAST(SNOC (h:*) t)";"h:*";"t:(*)list"]SNOC_ONE_ONE)
  (REWRITE_RULE[SYM (SPEC_ALL BUTLAST_DEF);SYM (SPEC_ALL LAST_DEF);SNOC_NOT_NULL]
   (SPEC "SNOC (h:*) t" SNOC));;

% |- !h t. LAST(SNOC h t) = d %

let LAST = save_thm (`LAST`,GEN_ALL (CONJUNCT1 LAST_BUTLAST_lemma));;

let BUTLAST = save_thm (`BUTLAST`,GEN_ALL (CONJUNCT2 LAST_BUTLAST_lemma));;
%<-------------------------------------------------------------------------->%

let LAST_CONS = prove_thm(`LAST_CONS`,
 "!(h:*) t. LAST (CONS h t) = NULL t => h | LAST t",
 REPEAT GEN_TAC THEN
 STRUCT_CASES_TAC (SPEC "t:(*)list" SNOC_CASES) THENL
 [
  REWRITE_TAC[NULL;LAST;CONV_RULE (ONCE_DEPTH_CONV SYM_CONV) (CONJUNCT1 SNOC_DEF)]
 ;
  REWRITE_TAC[SNOC_NOT_NULL;LAST;
   CONV_RULE (ONCE_DEPTH_CONV SYM_CONV) (CONJUNCT2 SNOC_DEF)]
 ]);;

let BUTLAST_CONS = prove_thm (`BUTLAST_CONS`,
 "!(h:*) t. BUTLAST (CONS h t) = NULL t => [] | CONS h (BUTLAST t)",
 REPEAT GEN_TAC THEN
 STRUCT_CASES_TAC (SPEC "t:(*)list" SNOC_CASES) THENL
 [
  REWRITE_TAC[NULL;BUTLAST;CONV_RULE (ONCE_DEPTH_CONV SYM_CONV) (CONJUNCT1 SNOC_DEF)]
 ;
  REWRITE_TAC[SNOC_NOT_NULL;BUTLAST;
   CONV_RULE (ONCE_DEPTH_CONV SYM_CONV) (CONJUNCT2 SNOC_DEF)]
 ]);;

%<-------------------------------------------------------------------------->%

let LENGTH_SNOC = prove_thm (`LENGTH_SNOC`,
  "!(l:(*)list) n.
       (LENGTH l = SUC n) = (?h l'. (LENGTH l' = n) /\ (l = SNOC h l'))",
 REPEAT GEN_TAC THEN
 EQ_TAC THEN
 STRIP_TAC THENL
 [
  EXISTS_TAC "LAST l:*" THEN
  EXISTS_TAC "BUTLAST l:(*)list" THEN
  DISJ_CASES_TAC (SPEC "l:(*)list" SNOC_CASES) THENL
  [
   POP_ASSUM (\x.POP_ASSUM (\y.
    CONTR_TAC (REWRITE_RULE [x;LENGTH;CONV_RULE(ONCE_DEPTH_CONV SYM_CONV) NOT_SUC] y)))
  ;
   POP_ASSUM STRIP_ASSUME_TAC THEN
   ASM_REWRITE_TAC[BUTLAST;LAST] THEN
   POP_ASSUM (\x.POP_ASSUM (\y.
    ACCEPT_TAC (REWRITE_RULE[LENGTH;SNOC_LENGTH;INV_SUC_EQ;x] y)))
  ]
 ;
  ASM_REWRITE_TAC[LENGTH;SNOC_LENGTH]
 ]);; 







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   AUTHOR:       Wim Ploegaerts                                             %
%   ORGANIZATION: Imec vzw.                                                  %
%                 Kapeldreef 75                                              %
%                 3030 Leuven, Belgium                                       %
%   DATE:         31-5-1990                                                  %
%                                                                            %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%<-------------------------------------------------------------------------->%


let LAST_REVERSE_EQ_HD = prove_thm (
  `LAST_REVERSE_EQ_HD`,
  "! l:(*)list . ~(NULL l) ==> ( LAST (REVERSE l) = HD l)",
  LIST_INDUCT_TAC THEN
  REWRITE_TAC [REVERSE_DEF;HD;LAST;NULL]
);;

%<-------------------------------------------------------------------------->%


let BUTLAST_REVERSE_EQ_REVERSE_TL = prove_thm (
  `BUTLAST_REVERSE_EQ_REVERSE_TL`,
  "! l:(*)list . ~(NULL l) ==> ( BUTLAST (REVERSE l) = REVERSE (TL l))",
  LIST_INDUCT_TAC THEN
  REWRITE_TAC [REVERSE_DEF;TL;BUTLAST;NULL]
);;
%<-------------------------------------------------------------------------->%
let SNOC_INDUCT_TAC = INDUCT_THEN SNOC_INDUCT ASSUME_TAC;;


let LAST_CONS_NOT_NULL = prove_thm (
  `LAST_CONS_NOT_NULL`,
  " ! (h:*) l . ~(NULL l) ==> (  LAST (CONS h l) = LAST l )",
  GEN_TAC THEN
  SNOC_INDUCT_TAC THEN
  REWRITE_TAC [GSYM (CONJUNCT2 SNOC_DEF);LAST;NULL]
);;
%<-------------------------------------------------------------------------->%

let BUTLAST_CONS_NOT_NULL = prove_thm (
  `BUTLAST_CONS_NOT_NULL`,
  " ! (h:*) l . ~(NULL l) ==> (  BUTLAST (CONS h l) = CONS h (BUTLAST l) )",
  GEN_TAC THEN
  SNOC_INDUCT_TAC THEN
  REWRITE_TAC [GSYM (CONJUNCT2 SNOC_DEF);BUTLAST;NULL]
);;




%<-------------------------------------------------------------------------->%


let BUTLAST_TL = prove_thm (
  `BUTLAST_TL`,
  "!(l:(*)list) . (1 < LENGTH l) ==> (BUTLAST (TL l) = TL (BUTLAST l))",
  CONV_TAC (DEPTH_CONV num_CONV) THEN
  GEN_TAC THEN
  STRIP_ASSUME_TAC (SPEC_ALL list_CASES) THEN
  EVERY_ASSUM \thm . REWRITE_TAC [thm;LENGTH;NOT_LESS_0;LESS_MONO_EQ;TL] THEN
  (REWRITE_TAC[LENGTH_NOT_NULL]) THEN
  DISCH_THEN \thm . REWRITE_TAC
                      [MATCH_MP BUTLAST_CONS_NOT_NULL thm;TL]
);;

%<-------------------------------------------------------------------------->%


let HD_BUTLAST = prove_thm (
  `HD_BUTLAST`,
  " ! l:(*)list . (1 < LENGTH l) ==> (HD (BUTLAST l) = HD l)",
  CONV_TAC (DEPTH_CONV num_CONV) THEN
  GEN_TAC THEN
  STRIP_ASSUME_TAC (SPEC_ALL list_CASES) THEN
  EVERY_ASSUM \thm . REWRITE_TAC [thm;LENGTH;NOT_LESS_0;LESS_MONO_EQ] THEN
  (REWRITE_TAC[LENGTH_NOT_NULL]) THEN
  DISCH_THEN \thm . REWRITE_TAC
                      [MATCH_MP BUTLAST_CONS_NOT_NULL thm;HD]
);;

%<-------------------------------------------------------------------------->%

let LAST_TL = prove_thm (
  `LAST_TL`,
 "!l:(*)list . (1 < LENGTH l) ==> (LAST (TL l) = LAST l)",
  CONV_TAC (DEPTH_CONV num_CONV) THEN
  GEN_TAC THEN
  STRIP_ASSUME_TAC (SPEC_ALL list_CASES) THEN
  EVERY_ASSUM \thm . REWRITE_TAC [thm;LENGTH;NOT_LESS_0;LESS_MONO_EQ] THEN
  (REWRITE_TAC[LENGTH_NOT_NULL]) THEN
  DISCH_THEN \thm . REWRITE_TAC
                    [MATCH_MP LAST_CONS_NOT_NULL thm;TL]
);;

%<-------------------------------------------------------------------------->%

let LENGTH_BUTLAST = prove_thm (
  `LENGTH_BUTLAST`,
  "! l :(*)list . ~(NULL l) ==> (LENGTH (BUTLAST l) = PRE (LENGTH l))",
  REPEAT STRIP_TAC THEN
  STRIP_ASSUME_TAC (SPEC "l:(*)list" SNOC_NULL_CASES) THEN
  RES_TAC THEN
  FIRST_ASSUM \thm . REWRITE_TAC [thm;NULL;BUTLAST;LENGTH;SNOC_LENGTH;ADD_CLAUSES;PRE]
);;

%<-------------------------------------------------------------------------->%

let SUBST_REVERSE_CONV  = BASE_CHANGE_CONV ISO_REVERSE;;


let LENGTH_REVERSE = TAC_PROOF(
 ([],"! l:(*)list. LENGTH (REVERSE l) = LENGTH l"),
 LIST_INDUCT_TAC THEN
 ASM_REWRITE_TAC[LENGTH;REVERSE_DEF;SNOC_LENGTH]);;

let LENGTH_TL = prove_thm (
  `LENGTH_TL`,
  "! l :(*)list . ~(NULL l) ==> (LENGTH (TL l) = PRE (LENGTH l))",
  GEN_TAC  THEN
  DISCH_THEN \thm . 
    ACCEPT_TAC (REWRITE_RULE [MATCH_MP BUTLAST_REVERSE_EQ_REVERSE_TL thm;LENGTH_REVERSE]
                 (MATCH_MP (REWRITE_RULE [REVERSE_NULL; REVERSE_CLAUSES]
                     (CONV_RULE SUBST_REVERSE_CONV LENGTH_BUTLAST)) thm))
);;


let LAST_EL = prove_thm (
  `LAST_EL`,
 "!a:* . LAST [a] = a",
  ONCE_REWRITE_TAC [(SYM  o SPEC_ALL o CONJUNCT1) SNOC_DEF] THEN
  REWRITE_TAC [LAST]
);;


let BUTLAST_EL = prove_thm (
  `BUTLAST_EL`,
 "!a:* . BUTLAST [a] = []",
  REWRITE_TAC [BUTLAST_CONS;NULL]
);;


%**********************************************************%
%  BUTLAST_NIL  |- !l. (LENGTH l = 1) ==> (BUTLAST l = []) %
%**********************************************************%

let BUTLAST_NIL = prove_thm(
   `BUTLAST_NIL`,
   "!l:(*)list. (LENGTH l = 1) ==> (BUTLAST l = [])",
  SNOC_INDUCT_TAC THENL
 [
  (REWRITE_TAC[LENGTH]) THEN
  (CONV_TAC (DEPTH_CONV num_CONV)) THEN
  (REWRITE_TAC[GSYM SUC_ID]);

  (REWRITE_TAC[SNOC_LENGTH;BUTLAST]) THEN
  (CONV_TAC (DEPTH_CONV num_CONV)) THEN
  (REWRITE_TAC[INV_SUC_EQ;LENGTH_NIL])]);;


let BUTLAST_NULL = save_thm(`BUTLAST_NULL`,
  (REWRITE_RULE[L_EQ_NIL] BUTLAST_NIL));;


%****************************************************************************%
% Following theorem added by Wai Wong on 2 April 1993			     %
%****************************************************************************%
%WW%
let SAME_LENGTH_SNOC = prove_thm(`SAME_LENGTH_SNOC`,
    "(!l a b. (LENGTH (l:* list) = LENGTH (SNOC(a:**) b)) =
     ? (a':*) b'. (LENGTH b' = LENGTH b) /\ (l = SNOC a' b'))",
    let SNOC_LENGTH =
     TAC_PROOF (([], "! (d:*) l. LENGTH (SNOC d l) = SUC (LENGTH l)"),
     GEN_TAC THEN LIST_INDUCT_TAC THEN
     ASM_REWRITE_TAC [LENGTH;SNOC_DEF]) in
    PURE_ONCE_REWRITE_TAC [SNOC_LENGTH] THEN
    MATCH_ACCEPT_TAC (ISPECL["l:* list";"LENGTH (b:** list)"]LENGTH_SNOC));;


%<-------------------------------------------------------------------------->%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   FILE:         append.ml                                                  %
%   EDITOR:       Paul Curzon                                                %
%   ORGANIZATION: U Cambridge CL                                             %
%   DATE:         5-4-1991                                                   %
%   DESCRIPTION:  Theorems about APPEND                                      %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%*********************************  HISTORY  ********************************%
%									     %
%   This file contains list theorems and definitions from several            %
%   sources:  								     %
%      Mike Benjamin(British Aerospace Sowerby Research Centre,Bristol)      %
%      R.J.Boulton							     %
%      Albert J Camilleri (Hewlett-Packard Laboratories, Bristol)	     %
%      Rachel Cardell-Oliver						     %
%      Paul Curzon 							     %
%      Wai Wong                                                              %
%      Wim Ploegaerts   (Imec vzw Leuven, Belgium)			     %
%                                                                            %
%  The names of some theorems have been changed from the original sources    %
%  The theorems by Albert  Camilleri were taken from the csp library         %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%****************************************************************************%
%                                                                            %
%  DEPENDANCIES :                                                            %
%                                                                            %
%         library more_arithmetic  for arithmetic theorems                   %
%                                                                            %
%****************************************************************************%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   AUTHOR:       Wim Ploegaerts                                             %
%   ORGANIZATION: Imec vzw.                                                  %
%                 Kapeldreef 75                                              %
%                 3030 Leuven, Belgium                                       %
%   DATE:         31-5-1990                                                  %
%                                                                            %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                %< some  properties of append >%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

let APPEND_NIL = prove_thm (
  `APPEND_NIL`,
    "(!l:(*)list . APPEND l [] = l) /\ (!l:(*)list . APPEND [] l = l)",
       CONJ_TAC THENL
       [LIST_INDUCT_TAC;ALL_TAC] THEN ASM_REWRITE_TAC [APPEND]);;

%<-------------------------------------------------------------------------->%

let APPEND_IS_NIL = prove_thm (
  `APPEND_IS_NIL`,
   "! l1 l2 . ( APPEND l1 l2 = []:(*)list) = ((l1 = []) /\ (l2 = []))",
   REPEAT GEN_TAC THEN
   EQ_TAC THENL
  [
    SPEC_TAC ("l1:(*)list","l1:(*)list") THEN
    LIST_INDUCT_TAC THEN
    REWRITE_TAC [APPEND] THEN
    GEN_TAC THEN
   (ASM_CASES_TAC "APPEND l1 l2 = []:(*)list") THENL
       [
        ASM_REWRITE_TAC [NOT_CONS_NIL]
       ;
        REWRITE_TAC [L_EQ_NIL;NULL]
       ]
   ;
     (DISCH_THEN \thm . REWRITE_TAC ((CONJUNCTS thm)@ [APPEND]))
  ]
);;

%<-------------------------------------------------------------------------->%
%PC%
let APPEND_IS_NULL = save_thm (`APPEND_IS_NULL`,
    REWRITE_RULE[L_EQ_NIL] APPEND_IS_NIL);;

%<-------------------------------------------------------------------------->%

let IMP_APPEND_NOT_NIL = save_thm (
      `IMP_APPEND_NOT_NIL`,
         GEN_ALL 
           (REWRITE_RULE [DE_MORGAN_THM]
              (CONV_RULE CONTRAPOS_CONV
                  (fst (EQ_IMP_RULE (SPEC_ALL APPEND_IS_NIL)))))
);;
%<-------------------------------------------------------------------------->%
%PC%
let IMP_APPEND_NOT_NULL = save_thm (`IMP_APPEND_NOT_NULL`,
    REWRITE_RULE[L_EQ_NIL] IMP_APPEND_NOT_NIL);;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                        %
% THEOREM COPIED FROM:                                                   %
% FILE          : Library/csp/list_lib1.ml                               %
% AUTHOR        : Albert J Camilleri                                     %
% AFFILIATION   : Hewlett-Packard Laboratories, Bristol                  %
%                                                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



let APPEND_ID =
    prove_thm
       (`APPEND_ID`,
        "! l l':(*)list. (l = (APPEND l l')) = (l' = [])",
        LIST_INDUCT_TAC THEN
        REWRITE_TAC[APPEND] THENL
        [REWRITE_TAC[SPECL ["l:* list"; "[]:* list"]
                           (INST_TYPE [(":* list", ":*")] EQ_SYM_EQ)];
         ASM_REWRITE_TAC[CONS_11]]);;

%PC%
let APPEND_ID_NULL = save_thm(`APPEND_ID_NULL`,
  (REWRITE_RULE[L_EQ_NIL] APPEND_ID));;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                        %
% THEOREM COPIED FROM:                                                   %
% FILE          : Library/csp/list_lib1.ml                               %
% AUTHOR        : Albert J Camilleri                                     %
% AFFILIATION   : Hewlett-Packard Laboratories, Bristol                  %
%                                                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


let ONE_MEMBER_LIST =
    prove_thm
       (`ONE_MEMBER_LIST`,
        "! s t (a:*). ((APPEND s t) = [a]) ==> ((s = []) \/ (s = [a]))",
        LIST_INDUCT_TAC THEN
        REWRITE_TAC [APPEND; CONS_11; APPEND_IS_NIL] THEN
        REPEAT STRIP_TAC THEN
        ASM_REWRITE_TAC []);;

%PC%
let ONE_MEMBER_LIST_NULL = save_thm(`ONE_MEMBER_LIST_NULL`,
  (REWRITE_RULE[L_EQ_NIL] ONE_MEMBER_LIST));;
%<-------------------------------------------------------------------------->%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                        %
% THEOREM COPIED FROM:                                                   %
% FILE          : Library/csp/list_lib1.ml                               %
% AUTHOR        : Albert J Camilleri                                     %
% AFFILIATION   : Hewlett-Packard Laboratories, Bristol                  %
%                                                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


let CONS_MEMBER_LIST =
    prove_thm
       (`CONS_MEMBER_LIST`,
        "! s s' t (a:*).
          ((APPEND s t) = (CONS a s')) ==>
          ((s = []) \/ (?r. (s = (CONS a r)) /\ (s' = (APPEND r t))))",
        LIST_INDUCT_TAC THEN
        REWRITE_TAC [APPEND; CONS_11; NOT_CONS_NIL] THEN
        REPEAT STRIP_TAC THEN
        EXISTS_TAC "s:* list" THEN
        ASM_REWRITE_TAC []);;

%PC%
let CONS_MEMBER_LIST_NULL = save_thm(`CONS_MEMBER_LIST_NULL`,
  (REWRITE_RULE[L_EQ_NIL] CONS_MEMBER_LIST));;
%<-------------------------------------------------------------------------->%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                        %
% THEOREM COPIED FROM:                                                   %
% FILE          : Library/csp/list_lib1.ml                               %
% AUTHOR        : Albert J Camilleri                                     %
% AFFILIATION   : Hewlett-Packard Laboratories, Bristol                  %
%                                                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

let CONS_APPEND_CONS =
    prove_thm
       (`CONS_APPEND_CONS`,
        "! (a:*) l. CONS a l = (APPEND [a] l)",
        REWRITE_TAC [APPEND]);;

%<-------------------------------------------------------------------------->%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                        %
% THEOREM COPIED FROM:                                                   %
% FILE          : Library/csp/list_lib1.ml                               %
% AUTHOR        : Albert J Camilleri                                     %
% AFFILIATION   : Hewlett-Packard Laboratories, Bristol                  %
%                                                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

let HD_APPEND =
    prove_thm
       (`HD_APPEND`,
        "! l1:(*)list. (~(l1 = [])) ==> (! l2. (HD (APPEND l1 l2)) = (HD l1))",
        REWRITE_TAC [L_EQ_NIL] THEN
        REPEAT STRIP_TAC THEN
        IMP_RES_THEN (ASSUME_TAC o SYM) CONS THEN
        ONCE_ASM_REWRITE_TAC [] THEN
        REWRITE_TAC [APPEND; HD]);;
%<-------------------------------------------------------------------------->%
%PC%
let HD_APPEND_NULL = save_thm (`HD_APPEND_NULL`,
    REWRITE_RULE[L_EQ_NIL] HD_APPEND);;

%<-------------------------------------------------------------------------->%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                        %
% THEOREM COPIED FROM:                                                   %
% FILE          : Library/csp/list_lib1.ml                               %
% AUTHOR        : Albert J Camilleri                                     %
% AFFILIATION   : Hewlett-Packard Laboratories, Bristol                  %
%                                                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

let TL_APPEND =
    prove_thm
       (`TL_APPEND`,
        "! l1:(*)list.
           (~(l1 = [])) ==> (! l2. (TL (APPEND l1 l2)) = (APPEND (TL l1) l2))",
        REWRITE_TAC [L_EQ_NIL] THEN
        REPEAT STRIP_TAC THEN
        IMP_RES_THEN (ASSUME_TAC o SYM) CONS THEN
        ONCE_ASM_REWRITE_TAC [] THEN
        REWRITE_TAC [APPEND; TL]);;
%<-------------------------------------------------------------------------->%
%PC%
let TL_APPEND_NULL = save_thm (`TL_APPEND_NULL`,
    REWRITE_RULE[L_EQ_NIL] TL_APPEND);;

%<-------------------------------------------------------------------------->%

%*******************************************************%
% NIL_NOT_APPEND_CONS2                                  %
%   |- !l1 l2. (l2 = CONS h t) ==> ~([] = APPEND l1 l2) %
%*******************************************************%

let NIL_NOT_APPEND_CONS = prove_thm(
   `NIL_NOT_APPEND_CONS2`,
   "!(l1:(*)list) l2. (l2 = CONS h t) ==> ~([] = APPEND l1 l2)",
 LIST_INDUCT_TAC THENL
 [
 (REWRITE_TAC[APPEND]) THEN
 (REPEAT STRIP_TAC) THEN
 CONTR_TAC (REWRITE_RULE[ASSUME "(l2:* list) = CONS h t";NOT_NIL_CONS]
                        (ASSUME "[] = (l2:* list)"));

 (REWRITE_TAC[APPEND;NOT_NIL_CONS])]);;

%PC%
let NULL_NOT_APPEND_CONS = save_thm(`NULL_NOT_APPEND_CONS`,
  (REWRITE_RULE[L_EQ_NIL] NIL_NOT_APPEND_CONS));;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   AUTHOR:       Mike Benjamin                                              %
%   ORGANIZATION: FPC 267                                                    %
%                 British Aerospace Sowerby Research Centre                  %
%                 PO BOX 5                                                   %
%                 Filton                                                     %
%                 Bristol  BS12 7QW                                          %
%                 Tel: (0272) 366198                                         %
%   EMAIL: benjamin@src.bae.co.uk                                            %
%   DATE:         31-5-1990                                                  %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   *************************************************************************
    *                                                                       *
    *    Appending to a given list generates a unique result.               *
    *                                                                       *
    *    APPEND_11 = |- !x y z. (APPEND x y = APPEND x z) = (y = z)         *
    *                                                                       *
    ************************************************************************ %
%Proof modified by PC April 1993 %

let APPEND_11 = prove_thm(`APPEND_11`,
"! (x:* list) (y:* list) (z:* list).((APPEND x y) = (APPEND x z)) = (y = z)",
LIST_INDUCT_TAC
THEN ASM_REWRITE_TAC [APPEND;CONS_11]);;

%   **************************************************************************
    *                                                                        *
    *    Finding the head of a list created by append.                       *
    *                                                                        *
    *    HEAD_APPEND = |- !x y. HD(APPEND x y) = ((x = []) => HD y | HD x)   *
    *                                                                        *
    **********************************************************************   %
%see also HD_APPEND %

let HEAD_APPEND = prove_thm (`HEAD_APPEND`,
"! (x:* list) (y:* list).
         HD(APPEND x y) = ((x=([]:* list)) => (HD y) | (HD x))",
LIST_INDUCT_TAC
THEN REWRITE_TAC [APPEND]
THEN REWRITE_TAC [HD;NOT_CONS_NIL]);;

%PC%
let HEAD_APPEND_NULL = save_thm(`HEAD_APPEND_NULL`,
  (REWRITE_RULE[L_EQ_NIL] HEAD_APPEND));;

%   **************************************************************************
    *                                                                        *
    *    All lists can be represented as a pair of lists appended together.  *
    *                                                                        *
    *    SUBSEQUENCE_EXISTS = |- !s. ?a b. s = APPEND a b                    *
    *                                                                        *
    *************************************************************************%

let SUBSEQUENCE_EXISTS = prove_thm (`SUBSEQUENCE_EXISTS`,
"! (s:* list). (? (a:* list) (b:* list). s = APPEND a b)",
GEN_TAC
THEN EXISTS_TAC "[]:* list"
THEN EXISTS_TAC "s:* list"
THEN REWRITE_TAC [APPEND]);;



%****************************************************************************%
% AUTHOR        : Rachel Cardell-Oliver                      		     %
% DATE		: 1 August 1989, 9 May 90                                    %
%                                                                            %
%****************************************************************************%


let APPEND_CONS = prove_thm(`APPEND_CONS`,
   "!l1:* list. !l2:* list. !h:*. 
      APPEND (CONS h l1) l2 = APPEND [h] (APPEND l1 l2)",
   REWRITE_TAC[APPEND]);;

%****************************************************************************%
%                                                                            %
% AUTHOR        : R.J.Boulton                                                %
% DATE          : 1990                                                       %
%                                                                            %
%****************************************************************************%

%----------------------------------------------------------------------------%
% REPLICATE : num -> * -> (*)list                                            %
%                                                                            %
% REPLICATE n x = [x;...;x] where [x;...;x] is a list of length n.           %
%----------------------------------------------------------------------------%

let REPLICATE =
 new_prim_rec_definition
  (`REPLICATE`,
   "(REPLICATE 0 (in:*) = NIL) /\
    (REPLICATE (SUC n) in = (CONS in (REPLICATE n in)))");;

%----------------------------------------------------------------------------%
% LENGTH_REPLICATE = |- !x n. LENGTH(REPLICATE n x) = n                      %
%----------------------------------------------------------------------------%

let LENGTH_REPLICATE =
 prove_thm
  (`LENGTH_REPLICATE`,
   "!(x:*) n. LENGTH (REPLICATE n x) = n",
   GEN_TAC THEN
   INDUCT_TAC THEN
   ASM_REWRITE_TAC [REPLICATE;LENGTH]);;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   AUTHOR:       Mike Benjamin                                              %
%   ORGANIZATION: FPC 267                                                    %
%                 British Aerospace Sowerby Research Centre                  %
%                 PO BOX 5                                                   %
%                 Filton                                                     %
%                 Bristol  BS12 7QW                                          %
%                 Tel: (0272) 366198                                         %
%   EMAIL: benjamin@src.bae.co.uk                                            %
%   DATE:         31-5-1990                                                  %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%   ***************************************************************************
    *                                                                         *
    *    Itteration on lists.                                                 *
    *                                                                         *
    ***********************************************************************   %


let ITERATED = new_recursive_definition false num_Axiom `ITERATED`
"(ITERATED 0 (s:* list)               = ([]:* list)) /\  
 (ITERATED (SUC (n:num)) (s:* list)  = (APPEND s (ITERATED n s)))";;


%   ************************************************************************* %
let ITERATED_EMPTY = prove_thm (`ITERATED_EMPTY`,
"! (n:num). ITERATED n ([]:* list) = ([]:* list)",
INDUCT_TAC
THEN ASM_REWRITE_TAC [ITERATED;APPEND]);;


%   ************************************************************************* %
%PC%
let NULL_ITERATED = save_thm (`NULL_ITERATED`,
 REWRITE_RULE[L_EQ_NIL] ITERATED_EMPTY);;

%   ************************************************************************* %
%WW%
let EQ_LENGTH_INDUCT_TAC =
    LIST_INDUCT_TAC THENL[
     LIST_INDUCT_TAC THENL[ 
      REPEAT (CONV_TAC FORALL_IMP_CONV) THEN DISCH_THEN (\t.ALL_TAC);
      REWRITE_TAC[LENGTH;SUC_NOT]];
     GEN_TAC THEN LIST_INDUCT_TAC THEN REWRITE_TAC[LENGTH;NOT_SUC;INV_SUC_EQ]
     THEN GEN_TAC THEN REPEAT (CONV_TAC FORALL_IMP_CONV) THEN DISCH_TAC];;

let APPEND_LENGTH_EQ = prove_thm(`APPEND_LENGTH_EQ`,
    "!l1 l1'. (LENGTH l1 = LENGTH l1') ==>
     ! l2 l2':* list. (LENGTH l2 = LENGTH l2') ==>
     ((APPEND l1 l2 = APPEND l1' l2') = ((l1 = l1') /\ (l2 = l2')))",
    EQ_LENGTH_INDUCT_TAC THEN REWRITE_TAC[APPEND]
    THEN EQ_LENGTH_INDUCT_TAC THEN REWRITE_TAC[APPEND_11;CONS_11;APPEND_NIL]
    THEN FIRST_ASSUM (\t. ASSUME_TAC
      (MATCH_MP t (ASSUME"LENGTH (l1:* list) = LENGTH (l1':* list)")))
    THEN POP_ASSUM (ASSUME_TAC o (REWRITE_RULE[LENGTH;INV_SUC_EQ]) o
     (SPECL["CONS h'' l2:* list";"CONS h''' l2':* list"]))
    THEN POP_ASSUM (\t1. FIRST_ASSUM (\t2. SUBST1_TAC (MP t1 t2)))
    THEN REWRITE_TAC[CONS_11;CONJ_ASSOC]);;

%   ************************************************************************* %
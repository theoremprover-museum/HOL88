%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   FILE:         mk_snoc.ml                                                 %
%   EDITOR:       Paul Curzon                                                %
%   ORGANIZATION: U Cambridge CL                                             %
%   DATE:         June 1991                                                  %
%   DESCRIPTION:  Make the theory of snoc                                    %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
system `rm -f snoc.th`;;

new_theory `snoc`;;


%< WW 2/4/93 use load_library instead of loadf		     
set_search_path (search_path()  @ 
		 [`../more_arithmetic/`;`../auxiliary/`]);;

loadf `more_arithmetic`;;
%PC 13/8/92 more_arithmetic is no longer dependent on auxiliary. snoc2 is %
loadf `auxiliary`;;
>%

load_library`more_arithmetic`;;
load_library`auxiliary`;;

new_parent `general_lists`;;

autoload_defs_and_thms `general_lists`;;


load_library `taut`;;



loadt `snoc`;;
loadt `snoc2`;;
loadt `last`;;

close_theory();;

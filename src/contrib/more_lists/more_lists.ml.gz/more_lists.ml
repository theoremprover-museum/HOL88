% ===================================================================== %
% FILE		: more_lists.ml	      		                        %
% DESCRIPTION   : loads the library "more_lists" into hol.		%
%									%
% AUTHOR	: P. Curzon						%
% DATE		: 9.4.91						%
% ===================================================================== %
% PC 16/12/92  Bugfix to allow the library to be loaded in draft mode   %
%        				                                %
% ===================================================================== %



set_search_path (search_path()  @ 
		 [library_pathname() ^ `/more_arithmetic/`;
                  library_pathname() ^ `/auxiliary/`]);;

load_library `more_arithmetic`;;
%PC 13/8/92 more_arithmetic is no longer dependent on auxiliary. snoc2 is %
load_library `auxiliary`;;

% --------------------------------------------------------------------- %
% Put the pathname to the library more_lists onto the search path.      %
% --------------------------------------------------------------------- %

let path = library_pathname() ^ `/more_lists/` in
    print_string `Updating search path`; print_newline();
    set_search_path (union (search_path()) [path]);;

% --------------------------------------------------------------------- %
% Add the more_lists help files to online help.                         %
% --------------------------------------------------------------------- %

let path = library_pathname() ^ `/more_lists/help/entries/` in
    print_string `Updating help search path`; print_newline();
    set_help_search_path (union [path] (help_search_path()));;


% --------------------------------------------------------------------- %
% Load (or attempt to load) the theory more_lists			%
% --------------------------------------------------------------------- %

if draft_mode() 
   then (print_string `Declaring theory more_lists a new parent`;
         print_newline();
         new_parent `more_lists`)
   else (load_theory `more_lists` ?
         (print_string `Defining ML function load_more_lists`;
          print_newline() ;
          loadf `load_more_lists`));;

% --------------------------------------------------------------------- %
% Load compiled code if possible					%
% --------------------------------------------------------------------- %
%PC 14/12/92  The following was changed to allow the library to be loaded  %
%            when in draft mode.                                        %

if (draft_mode() or (current_theory() = `more_lists`)) then
   let path st = library_pathname() ^ `/more_lists/` ^ st in
       (if not (draft_mode()) then  loadf `call_load_auxiliary`;
        load(path `list_convs`, get_flag_value `print_lib`);
        load(path `list_tactics`, get_flag_value `print_lib`));;

% --------------------------------------------------------------------- %
% Set up autoloading of  theorems and definitions      		        %
% --------------------------------------------------------------------- %

if (draft_mode() or (current_theory() = `more_lists`)) then
  let autoload_defs_and_thms thy =
   map (\name. autoload_theory(`definition`,thy,name))
     (map fst (definitions thy));
   map (\name. autoload_theory(`theorem`,thy,name))
     (map fst (theorems thy));
 () 
  in
    (autoload_defs_and_thms `append`;
     autoload_defs_and_thms `map`;
     autoload_defs_and_thms `el`;
     autoload_defs_and_thms `ell`;
     autoload_defs_and_thms `general_lists`;
     autoload_defs_and_thms `zip`;
     autoload_defs_and_thms `tail`;
     autoload_defs_and_thms `unappend`;
     autoload_defs_and_thms `subseq`;
     autoload_defs_and_thms `last_subseq`;
     autoload_defs_and_thms `shift`;
     autoload_defs_and_thms `snoc`;
     autoload_defs_and_thms `member`;
     autoload_defs_and_thms `num_lists`;
     delete_cache `append`;
     delete_cache `map`;
     delete_cache `el`;
     delete_cache `ell`;
     delete_cache `general_lists`;
     delete_cache `zip`;
     delete_cache `tail`;
     delete_cache `unappend`;
     delete_cache `subseq`;
     delete_cache `last_subseq`;
     delete_cache `shift`;
     delete_cache `snoc`;
     delete_cache `member`;
     delete_cache `num_lists`;
     ());;




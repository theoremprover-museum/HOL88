%-----------------------------------------------------------------------%
% FILE:	    list_convs.ml	    	    				%
% AUTHOR:   Wai Wong	    	    					%
% DATE:	    11 Dec 1992	    	    					%
%-----------------------------------------------------------------------%

%-----------------------------------------------------------------------%
% EL_CONV : conv    	    	    					%
% The argument to this conversion should be in the form of		%
%   "EL k [x0; x1; ...; xk; ...; xn]" 					%
% It returns a theorem 	    	    					%
%  |- EL k [x0; x1; ...; xk; ...; xn] = xk				%
% iff 0 <= k <= n, otherwise failure occurs.				%
%-----------------------------------------------------------------------%
let EL_CONV =
    let bthm,ithm = CONJ_PAIR (definition `list` `EL`) in
    let dec n = let nn = int_of_string(fst(dest_const n)) in
        mk_const(string_of_int(nn - 1), ":num") in
    let tail lst = hd(tl(snd(strip_comb lst))) in
    let check = assert (\x. fst(dest_const x) = `EL`) in
    let iter ct N bits =
      letref n',m',lst' = ct-1, (dec N), (tail bits) in
      letref sthm = PURE_ONCE_REWRITE_RULE[TL](ISPECL [bits; m'] ithm) in
      if (n' = 0) then
        (TRANS sthm (SUBS[ISPECL(snd(strip_comb lst'))HD](ISPEC lst' bthm)))
      loop
        (n' :=  n' -1;
         sthm := TRANS (RIGHT_CONV_RULE(RATOR_CONV(RAND_CONV num_CONV)) sthm)
           (SUBS[ISPECL(snd(strip_comb lst'))TL](ISPECL[lst';(dec m')] ithm));
         lst' := tail lst';
         m' := dec m')    in
  \tm.
     let _,[N;bits] = (check # I) (strip_comb tm) in
     let n = int_of_string(fst (dest_const N)) in
     let lst = bits and m = N in
     if (n = 0) then
       (PURE_ONCE_REWRITE_RULE[HD](ISPEC bits bthm))
     else if (n < length(fst(dest_list bits))) then
       (SUBS [SYM (num_CONV N)](iter n N bits))
     else failwith `EL_CONV: index too large` ;;

%-----------------------------------------------------------------------%
% SPLIT_CONV : conv 	    	    					%
% It takes a term of the form "SPLIT k [a0; ...; ak; ...; an]"		%
% and returns the following theorem:					%
% |- SPLIT k [a0; ...; ak; ...; an] = [a0;...;a(k-1);],[ak;...;an]	%
%-----------------------------------------------------------------------%
let SPLIT_CONV =  
    let th1,th2 = CONJ_PAIR (definition `ltree` `SPLIT`) in
    let th2' = GEN_ALL (PURE_REWRITE_RULE[HD;TL]
    	    (SPECL["n:num"; "(CONS (h:*) l)"] th2)) in
    let check = assert (\tm. fst(dest_const tm) = `SPLIT`) in
    let iter n cns (l1,l2) th = 
    	letref  count,n,bs,lst,thm = n, ("0"), l1, l2, th in
    	if (count = 0) then thm 
    	loop (count := count - 1 ;
    	      thm := PURE_ONCE_REWRITE_RULE[FST;SND]
    	    	 (SUBS[thm](ISPECL[n;(hd bs);lst] th2')) ;
    	      n := mk_comb("SUC", n) ;
    	      lst := mk_comb(mk_comb(cns,(hd bs)), lst) ;
    	      bs := tl bs ) in
    \tm. (let _,[n;l] = (check # I) (strip_comb tm) in
          let els,ty = dest_list l in
    	  if (n = "0") then (ISPEC l th1) else
          let cns = rator(rator l) in
    	  let nn = int_of_string (fst (dest_const n)) in
    	  let l1,l2 = (I # (\t.mk_list(t,ty))) (chop_list nn els) in
    	  let base = ISPEC l2 th1 in
    	  let th = (iter nn cns ((rev l1),l2) base) in
    	  (SUBS[SYM((REDEPTH_CONV num_CONV) n)] th)) ?
    	  failwith `SPLIT_CONV`;;

%-----------------------------------------------------------------------%
% NBUTLAST_CONV : conv	    	    					%
% It takes a term of the form "NBUTLAST k [x0;x1;...;x(n-k);...;x(n-1)]"%
% and returns the following theorem:					%
% |- NBUTLAST k  [x0; x1; ...; x(n-k);...;x(n-1)] = [x0; ...; x(n-k-1)]	%
%-----------------------------------------------------------------------%
let NBUTLAST_CONV =
    let bthm = CONJUNCT1 (definition `last_subseq` `NBUTLAST`) in
    let lthm = let th =  (SPEC "l:* list" 
          (theorem `last_subseq` `NBUTLAST_LENGTH_NULL`)) in
          let l = snd(dest_comb (concl th)) in
        GEN_ALL(EQ_MP (SPEC l(theorem `general_lists` `NULL_EQ_EMPTY`))th) in
    let athm = GEN_ALL (TRANS (SPECL ["l2:* list"; "l1:* list"]
    	(theorem `last_subseq` `NBUTLAST_LENGTH_APPEND`))
        (SPEC "l1:* list" (CONJUNCT1 (theorem `append` `APPEND_NIL`)))) in
    let check = assert (\x. fst(dest_const x) = `NBUTLAST`) in
    let len_conv ty lst =
        LENGTH_CONV(mk_comb("LENGTH:(^ty)list -> num",lst)) in
  \tm.
    (let _,[N;lst] = (check # I) (strip_comb tm) in
     if (N = "0") then (ISPEC lst bthm)
     else 
      (let n = int_of_string(fst (dest_const N)) in
       let bits,lty = (dest_list lst) in
       let len = (length bits) in
       if (n = len) then
         let thm1 = len_conv lty lst in (SUBS[thm1](ISPEC lst lthm))
       else
        (let l1,l2 = (chop_list (len - n) bits) in
         let l1' = mk_list(l1, lty) and l2' = mk_list(l2, lty) in
         let APP = "APPEND:(^lty)list -> (^lty)list -> (^lty)list" in
         let thm2 = len_conv lty l2' in
         let thm3 = APPEND_CONV (mk_comb(mk_comb(APP, l1'),l2')) in
         (SUBS[thm2;thm3](ISPECL [l2';l1'] athm)) )))
    ? failwith `NBUTLAST_CONV`;;

%-----------------------------------------------------------------------%
% LASTN_CONV : conv 	    	    					%
% It takes a term of the form "LASTN k [x0; ...; x(n-k); ...; x(n-1)]"	%
% and returns the following theorem:					%
% |- LASTN k [x0; ...; x(n-k); ...; x(n-1)] = [x(n-k); ...; x(n-1)]	%
%-----------------------------------------------------------------------%

let LASTN_CONV =
    let LASTN_LENGTH_APPEND = theorem `last_subseq` `LASTN_LENGTH_APPEND` in
    let bthm = CONJUNCT1 (definition `last_subseq` `LASTN`) in
    let ithm = (theorem `last_subseq` `LASTN_LENGTH_ID`) in
    let check = assert (\x. fst(dest_const x) = `LASTN`) in
    let len_conv ty lst =
        LENGTH_CONV(mk_comb("LENGTH:(^ty)list -> num",lst)) in
  \tm.
    (let _,[N;lst] = (check # I) (strip_comb tm) in
     if (N = "0") then (ISPEC lst bthm)
     else 
      (let n = int_of_string(fst (dest_const N)) in
       let bits,lty = (dest_list lst) in
       let len = (length bits) in
       if (n = len) then 
         let thm1 = len_conv lty lst in (SUBS[thm1](ISPEC lst ithm))
       else
        (let l1,l2 = (chop_list (len - n) bits) in
         let l1' = mk_list(l1, lty) and l2' = mk_list(l2, lty) in
         let APP = "APPEND:(^lty)list -> (^lty)list -> (^lty)list" in
         let thm2 = len_conv lty l2' in
         let thm3 = APPEND_CONV (mk_comb(mk_comb(APP, l1'),l2')) in
         (SUBS[thm2;thm3](ISPECL [l1';l2'] LASTN_LENGTH_APPEND)) )))
    ? failwith `LASTN_CONV`;;


%-----------------------------------------------------------------------%
% SNOC_CONV : conv 	    	    					%
% It takes a term of the form "SNOC x(n+1) [x0; ...; x(n-k); ...; xn]"	%
% and returns the following theorem:					%
% |- SNOC x(n+1) [x0; ...; x(n-k); ...; xn] = [x0; ...; xn; x(n+1)]	%
%-----------------------------------------------------------------------%
let SNOC_CONV =
    let bthm,sthm = CONJ_PAIR (definition `snoc` `SNOC_DEF`) in
    let check = assert (\t. fst(dest_const t) = `SNOC`) in
  \tm. 
    (let _,[d;lst] = (check # I)(strip_comb tm) in
     let ty = type_of lst in
     let lst',ety = (dest_list lst) in
     let EMP = "[]:^ty"  and CONS = "CONS:^ety -> ^ty ->^ty" in
     let itfn x (lst,ithm) =
       mk_comb(mk_comb(CONS,x),lst), (SUBS[ithm](ISPECL[d;x;lst]sthm)) in
     snd(itlist itfn lst' (EMP,(ISPEC d bthm))))
    ?\s failwith(`SNOC_CONV: `^s);;

%-----------------------------------------------------------------------%
% LAST_CONV : conv 	    	    					%
% It takes a term of the form "LAST k [x0; ...; x(n-k); ...; xn]"	%
% and returns the following theorem:					%
% |- LAST k [x0; ...; x(n-k); ...; xn] = xn				%
%-----------------------------------------------------------------------%

let LAST_CONV = 
    let check tm = assert (\t. fst(dest_const t) = `LAST`) tm in
    let LAST1 =  (theorem `append` `LAST1`) in
  \tm. 
    (let _,lst = (check # I)(dest_comb tm) in
     let ty = type_of lst in
     let lst',ety = (dest_list lst) in
     let x = (last lst') and l = mk_list(butlast lst',ety) in
     let sthm = ISPECL [l;x] LAST1 in
     CONV_RULE ((RATOR_CONV o RAND_CONV o RAND_CONV) APPEND_CONV) sthm)
    ?\s failwith(`LAST_CONV: `^s);;

%-----------------------------------------------------------------------%
% BUTLAST_CONV : conv 	    	    					%
% It takes a term of the form "BUTLAST [x0; ...; x(n-k); ...; xn]"	%
% and returns the following theorem:					%
% |- BUTLAST [x0; ...; x(n-k); ...; xn] = [x0; ...; x(n-1)]		%
%-----------------------------------------------------------------------%
let BUTLAST_CONV = 
    let check tm = assert (\t. fst(dest_const t) = `BUTLAST`) tm in
    let BUTLAST1 =  (theorem `append` `BUTLAST1`) in
  \tm. 
    (let _,lst = (check # I)(dest_comb tm) in
     let ty = type_of lst in
     let lst',ety = (dest_list lst) in
     let x = (last lst') and l = mk_list(butlast lst',ety) in
     let sthm = ISPECL [l;x] BUTLAST1 in
     CONV_RULE ((RATOR_CONV o RAND_CONV o RAND_CONV) APPEND_CONV) sthm)
    ?\s failwith(`BUTLAST_CONV: `^s);;

%-----------------------------------------------------------------------%
% ELL_CONV : conv   	    	    					%
% It takes a term of the form "ELL k [x(n-1); ... x0]" and returns	%
% |- ELL k [x(n-1); ...; x0] = x(k) 					%
%-----------------------------------------------------------------------%
let ELL_CONV = 
    let int_of_term = int_of_string o fst o dest_const in
    let term_of_int =  let ty = ":num" in
      \n. mk_const(string_of_int n, ty) in 
    let check tm = assert (\t. fst(dest_const t) = `ELL`) tm in
    let bthm = theorem `ell` `ELL_SNOC0` in
    let ithm = theorem `ell` `ELL_SUC_SNOC` in
    let iter count (d,lst) elty = 
     letref n = count and x = d and l = lst in
     letref th = (ISPECL[(term_of_int n); x; mk_list(l,elty)]ithm) in
     if (n = 0) then
       (x := last l; l := butlast l;
       (th := TRANS th (CONV_RULE ((RATOR_CONV o RAND_CONV o RAND_CONV)
    	     SNOC_CONV) (ISPECL [mk_list(l,elty);x] bthm))))
     loop
       (n := n - 1;
        x := (last l);
        l := butlast l;
    	th := TRANS (RIGHT_CONV_RULE ((RATOR_CONV o RAND_CONV) num_CONV) th)
    	     (CONV_RULE ((RATOR_CONV o RAND_CONV o RAND_CONV)SNOC_CONV)
    	      (ISPECL[(term_of_int n); x; mk_list(l,elty)]ithm))) in
  \tm. 
    (let _,[N;lst] = (check # I)(strip_comb tm) in
     let ty = type_of lst in
     let lst',ety = (dest_list lst) in
     let n =  int_of_term N in
     if not(n < (length lst')) then failwith `index too large`
     else if (n = 0) then
       (CONV_RULE ((RATOR_CONV o RAND_CONV o RAND_CONV)SNOC_CONV)
    	(ISPECL[mk_list(butlast lst', ety);(last lst')]bthm))
     else
      SUBS_OCCS[[1],(SYM (num_CONV N))]
      (CONV_RULE ((RATOR_CONV o RAND_CONV o RAND_CONV)SNOC_CONV)
        (iter (n - 1) ((last lst'), (butlast lst')) ety)))
    ?\s failwith(`ELL_CONV: `^s);;

% --------------------------------------------------------------------- %
% MAP2_CONV conv "MAP2 f [x1;...;xn] [y1;...;yn]"			%
%									%
% Returns |- MAP2 f [x1;...;xn] [y1;...;yn] = [r1;...;rn]		%
% where conv "f xi yi" returns |- f xi yi = ri for 1 <= i <= n		%
% --------------------------------------------------------------------- %

let MAP2_CONV =
    let mn,mc = CONJ_PAIR(definition `list` `MAP2`) in
    let check c = fst(dest_const c) = `MAP2` in
    \conv tm.
     (let _,[fn;l1;l2] = (assert check # I) (strip_comb tm) in
      let el1s,ty1 = dest_list l1 and el2s,ty2 = dest_list l2 in
      let els = combine (el1s,el2s) in
      let nth = ISPEC fn mn and cth = ISPEC fn mc in
      let cns = rator(rator(rand(snd(strip_forall(concl cth))))) in
      let itfn (e1,e2) th =
          let _,[f;t1;t2] = strip_comb(lhs(concl th)) in
          let th1 = SPECL [e1; t1; e2; t2] cth in
          let r = conv (mk_comb(mk_comb(fn,e1),e2)) in
          (SUBS[r;th]th1) in
      itlist itfn els nth) ? failwith `MAP2_CONV`;;


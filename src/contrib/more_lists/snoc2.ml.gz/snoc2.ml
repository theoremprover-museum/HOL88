%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   FILE:         snoc2.ml                                                   %
%   EDITOR:       Paul Curzon                                                %
%   ORGANIZATION: U Cambridge CL                                             %
%   DATE:         5-4-1991                                                   %
%   DESCRIPTION:  Additional theorems about SNOC, REVERSE and APPEND t [h]   %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%*********************************  HISTORY  ********************************%
%									     %
%   This file is based on the theory by					     %
%      Wim Ploegaerts   (Imec vzw Leuven, Belgium)			     %
%   Additional theorems from						     %
%      Mike Benjamin 						     	     %
%      Paul Curzon, and							     %
%      John Harrison							     %
%  have been added and the proofs of some altered to make use of earlier     %
%  (SNOC) theorems                                                           %
%                                                                            %
%  The names of some theorems have been changed from the original sources    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%****************************************************************************%
%                                                                            %
%  DEPENDANCIES :                                                            %
%                                                                            %
%         library more_arithmetic  for arithmetic theorems                   %
%         general_lists            for general list theorems                 %
%         snoc                     for SNOC theorems                         %
%                                                                            %
%****************************************************************************%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   AUTHOR:       John Harrison                                              %
%   ORGANIZATION: U Cambridge CL                                             %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%******************************************%
% REVERSE_SINGLE = |- !h. REVERSE[h] = [h] %
%******************************************%

let REVERSE_SINGLE = prove_thm(`REVERSE_SINGLE`,
        "!(h:*). REVERSE [h] = [h]",
        REWRITE_TAC[REVERSE_DEF; SNOC_DEF]);;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   AUTHOR:       Mike Benjamin                                              %
%   ORGANIZATION: FPC 267                                                    %
%                 British Aerospace Sowerby Research Centre                  %
%                 PO BOX 5                                                   %
%                 Filton                                                     %
%                 Bristol  BS12 7QW                                          %
%                 Tel: (0272) 366198                                         %
%   EMAIL: benjamin@src.bae.co.uk                                            %
%   DATE:         31-5-1990                                                  %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Proof modified by PC April 1993 %
let REVERSE_EXISTS = prove_thm (`REVERSE_EXISTS`,
"! (s:* list). ? (t:* list). (t = REVERSE s)",
LIST_INDUCT_TAC
THENL [
EXISTS_TAC "[]:* list"
THEN REWRITE_TAC [REVERSE_DEF];
CHOOSE_THEN ASSUME_TAC (ASSUME "?t. t = REVERSE (s:* list)")
THEN GEN_TAC
THEN REWRITE_TAC [REVERSE_DEF]
THEN EXISTS_TAC "SNOC h (t:* list)"
THEN ASM_REWRITE_TAC []]);;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   AUTHOR:       Wim Ploegaerts                                             %
%   ORGANIZATION: Imec vzw.                                                  %
%                 Kapeldreef 75                                              %
%                 3030 Leuven, Belgium                                       %
%   DATE:         31-5-1990                                                  %
%                                                                            %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


let REVERSE_EQ_NIL = prove_thm  (
   `REVERSE_EQ_NIL`,
   "! l:(*)list . (REVERSE l = []) = (l = [])",
   REWRITE_TAC [GSYM L_EQ_NIL] THEN
   GEN_TAC THEN
   DISJ_CASES_TAC (SPEC_ALL list_CASES) 
   THENL
   [
    ASM_REWRITE_TAC [REVERSE_DEF]
   ;
    POP_ASSUM STRIP_ASSUME_TAC THEN
    ASM_REWRITE_TAC [NOT_CONS_NIL;REVERSE_DEF;NOT_SNOC_NIL;DE_MORGAN_THM]
   ]
);;

%PC%
let REVERSE_NULL = save_thm (`REVERSE_NULL`,
     REWRITE_RULE[L_EQ_NIL] REVERSE_EQ_NIL);;


%<-------------------------------------------------------------------------->%
%< ISO_REVERSE = |- ISO REVERSE >%

let ISO_REVERSE = save_thm (
          `ISO_REVERSE`,
          let id_iso = INST_TYPE [(":(*)list",":*");(":(*)list",":**")] 
	                         ID_INJ_SURJ in
          let thm = SPECL ["REVERSE:(*)list->(*)list";"REVERSE:(*)list->(*)list"] 
	                         id_iso in
          REWRITE_RULE [ONCE_REWRITE_RULE [CONJ_SYM] (GSYM ISO)]
                          (MATCH_MP thm REVERSE_REVERSE)
);;
%<-------------------------------------------------------------------------->%

%< SUBST_REVERSE_CONV "!c:(*)list . f x" 
       |- (!x. f x) = (!y. f(REVERSE y)) >%


let SUBST_REVERSE_CONV  = BASE_CHANGE_CONV ISO_REVERSE;;

%<

example:  |- !P'. (!l. P' l) = (!y. P'(REVERSE y)) 

let SUBST_REVERSE = GEN_ALL (SUBST_REVERSE_CONV "! l:(*)list . P' l");;

>%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   AUTHOR:       Paul Curzon                                                %
%   ORGANIZATION: U Cambridge CL                                             %
%   DATE:         June 1991                                                  %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%PL%
let SNOC_LENGTH = TAC_PROOF (([], "! (d:*) l. LENGTH (SNOC d l) = SUC (LENGTH l)"),
 GEN_TAC THEN
 LIST_INDUCT_TAC THEN
 ASM_REWRITE_TAC [LENGTH;SNOC_DEF]);;

let SNOC_EQ_LENGTH_EQ = prove_thm (`SNOC_EQ_LENGTH_EQ`,
" !(l1:(*)list) y1 l2 y2 .
         ((SNOC y1 l1) = (SNOC y2 l2)) ==>
                  (LENGTH l1 = LENGTH l2)",
  REPEAT STRIP_TAC THEN
  RULE_ASSUM_TAC (AP_TERM "LENGTH:(*)list -> num" ) THEN
  RULE_ASSUM_TAC(REWRITE_RULE [SNOC_LENGTH;LENGTH;EQ_MONO_ADD_EQ;ADD1]) THEN
  FIRST_ASSUM ACCEPT_TAC
);;


%----------------------------------------------------------------------------%
let SNOC_REVERSE_CONS = prove_thm (`SNOC_REVERSE_CONS`,
   "!(d:*) l .  (SNOC d l) = REVERSE (CONS d (REVERSE l))",
    ACCEPT_TAC (
   GEN_ALL (REWRITE_RULE [REVERSE_REVERSE]
      (AP_TERM "REVERSE:(*)list -> (*)list"
         (SPEC_ALL(CONJUNCT1(CONJUNCT2(CONJUNCT2 REVERSE_CLAUSES)))))))
);;

%----------------------------------------------------------------------------%

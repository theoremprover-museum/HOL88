%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   FILE:         general.ml                                                 %
%   EDITOR:       Paul Curzon                                                %
%   ORGANIZATION: U Cambridge CL                                             %
%   DATE:         5-4-1991                                                   %
%   DESCRIPTION:  Additional theorems about lists                            %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%*********************************  HISTORY  ********************************%
%									     %
%   This file contains list theorems and definitions from several            %
%   sources:  								     %
%      Mike Benjamin(British Aerospace Sowerby Research Centre,Bristol)      %
%      R.J.Boulton							     %
%      Albert J Camilleri (Hewlett-Packard Laboratories, Bristol)	     %
%      Rachel Cardell-Oliver						     %
%      Paul Curzon 							     %
%      Brian Graham 							     %
%      Paul Loewenstein							     %
%      Wim Ploegaerts   (Imec vzw Leuven, Belgium)			     %
%                                                                            %
%  The names of some theorems have been changed from the original sources    %
%  The theorems by Albert  Camilleri were taken from the csp library         %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%****************************************************************************%
%                                                                            %
%  DEPENDANCIES :                                                            %
%                                                                            %
%         library more_arithmetic  for arithmetic theorems                   %
%                                                                            %
%****************************************************************************%
system `rm -f general_lists.th`;;

new_theory `general_lists`;;

load_library `more_arithmetic`;;


%****************************************************************************%

let NULL_EQ_EMPTY = prove_thm (`NULL_EQ_EMPTY`,
 "!l:(*)list .  NULL l = (l = [])",
 GEN_TAC THEN
 STRUCT_CASES_TAC (SPEC_ALL list_CASES) THEN
 REWRITE_TAC [NULL;NOT_CONS_NIL]);;


% Name changed and SYMed -- NULL_EQ_EMPTY = GSYM L_EQ_NIL. --
  Both are used lots (PC)%

let L_EQ_NIL = save_thm(`L_EQ_NIL`,GSYM NULL_EQ_EMPTY);;

let NIL_EQ_L = prove_thm(`NIL_EQ_L`,
 "!(l:* list). ([] = l) = NULL l",
GEN_TAC THEN
(CONV_TAC (RATOR_CONV (ONCE_DEPTH_CONV SYM_CONV))) THEN
(REWRITE_TAC [L_EQ_NIL]));;

%**************************************************************************%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CONS_ONE_ONE =                                                             %
%       |- !h t h' t'. (CONS h t = CONS h' t') ==> (h = h') /\ (t = t')      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

let CONS_ONE_ONE = save_thm(`CONS_ONE_ONE`,
       GEN_ALL (fst (EQ_IMP_RULE (SPEC_ALL (CONS_11)))));;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   AUTHOR:       Wim Ploegaerts                                             %
%   ORGANIZATION: Imec vzw.                                                  %
%                 Kapeldreef 75                                              %
%                 3030 Leuven, Belgium                                       %
%   DATE:         31-5-1990                                                  %
%                                                                            %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                        %
% THEOREM COPIED FROM:                                                   %
% FILE          : Library/csp/list_lib1.ml                               %
% AUTHOR        : Albert J Camilleri                                     %
% AFFILIATION   : Hewlett-Packard Laboratories, Bristol                  %
%                                                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



let LENGTH_LESS_EQ =
    prove_thm
       (`LENGTH_LESS_EQ`,
        "! l1 l2:(*)list.
           LENGTH l1 <= LENGTH l2 ==> !a:*. LENGTH l1 < LENGTH (CONS a l2)",
        REWRITE_TAC [LENGTH;
                     (ONCE_REWRITE_RULE [DISJ_SYM] LESS_THM);
                     LESS_OR_EQ]);;


%<-------------------------------------------------------------------------->%

let LENGTH_LESS_EQ_EQ = prove_thm (
  `LENGTH_LESS_EQ_EQ`,
  " ! l1 l2 :(*)list (a:*).
        (LENGTH  l1 <= LENGTH l2) = (LENGTH l1 < LENGTH (CONS a l2))",
        REWRITE_TAC [LENGTH;ONCE_REWRITE_RULE [DISJ_SYM] LESS_THM;LESS_OR_EQ]
);;

%<-------------------------------------------------------------------------->%

let LENGTH_EQ_SUC_IMP_NOT_NIL = prove_thm (
   `LENGTH_EQ_SUC_IMP_NOT_NIL`,
   " ! (l:(*)list) k . (LENGTH l = SUC k) ==> ~(l = []) ",
   REWRITE_TAC [GSYM L_EQ_NIL;GSYM LENGTH_NIL;GSYM L_EQ_NIL]
   THEN 
%PC 13/8/92 Remove dependency on auxiliary library%
%  (3 TIMES STRIP_TAC) THEN%
  (STRIP_TAC THEN STRIP_TAC THEN STRIP_TAC) THEN
  POP_ASSUM \thm . REWRITE_TAC  [thm;NOT_SUC]
);;

%PC%
let LENGTH_EQ_SUC_IMP_NOT_NULL = save_thm(`LENGTH_EQ_SUC_IMP_NOT_NULL`,
  (REWRITE_RULE[L_EQ_NIL] LENGTH_EQ_SUC_IMP_NOT_NIL));;

%<-------------------------------------------------------------------------->%

let LENGTH_GR_0_NOT_NIL = prove_thm (
  `LENGTH_GR_0_NOT_NIL`,
  " ! (l:(*)list) . (0 < LENGTH l) ==> ~(l = []) ",
 GEN_TAC THEN
 DISCH_THEN \thm .  ACCEPT_TAC 
          (CONV_RULE (ONCE_DEPTH_CONV 
                        (SYM_CONV THENC (REWR_CONV LENGTH_NIL)))
                           (MATCH_MP LESS_NOT_EQ thm))
);;


%<------- ------------------------------------------------------------------->%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                        %
% THEOREM COPIED FROM:                                                   %
% FILE          : Library/csp/list_lib1.ml                               %
% AUTHOR        : Albert J Camilleri                                     %
% AFFILIATION   : Hewlett-Packard Laboratories, Bristol                  %
%                                                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%New proof by BTG. Added by PC May 1992%
let NOT_LENGTH_EQ = save_thm
 (`NOT_LENGTH_EQ`,
  ((GENL ["l2:* list";"l1:* list"]) 
   o CONTRAPOS o DISCH_ALL o (AP_TERM "LENGTH:* list -> num") o ASSUME)
  "(l1:* list) = l2");;


%let NOT_LENGTH_EQ =%
%    prove_thm%
%       (`NOT_LENGTH_EQ`,%
%        "! l2 l1:(*)list. ~(LENGTH l1 = LENGTH l2) ==> ~(l1 = l2)",%
%        LIST_INDUCT_TAC THEN%
%        REWRITE_TAC [LENGTH; LENGTH_NIL] THEN%
%        GEN_TAC THEN%
%        LIST_INDUCT_TAC THEN%
%        REWRITE_TAC [NOT_NIL_CONS; LENGTH; CONS_11; INV_SUC_EQ] THEN%
%        REPEAT STRIP_TAC THEN%
%        RES_TAC);;%



%<-------------------------------------------------------------------------->%
%************************************************%
%  TL_NIL  |- !l. (LENGTH l = 1) ==> (TL l = []) %
%************************************************%

let TL_NIL = prove_thm(
   `TL_NIL`,
   "!l:(*)list. (LENGTH l = 1) ==> (TL l = [])",
  LIST_INDUCT_TAC THENL
 [
  (REWRITE_TAC[LENGTH]) THEN
  (CONV_TAC (DEPTH_CONV num_CONV)) THEN
  (REWRITE_TAC[GSYM SUC_ID]);

  (REWRITE_TAC[LENGTH;TL]) THEN
  (CONV_TAC (DEPTH_CONV num_CONV)) THEN
  (REWRITE_TAC[INV_SUC_EQ;LENGTH_NIL])]);;

%PC%
let TL_NULL = save_thm(`TL_NULL`,
  (REWRITE_RULE[L_EQ_NIL] TL_NIL));;


%<-------------------------------------------------------------------------->%


%   ***************************************************************************
    *                                                                         *
    *    If two lists are equal then they are the same length.                *
    *                                                                         *
    *    LENGTH_EQ = |- !x y. (x = y) ==> (LENGTH x = LENGTH y)               *
    *                                                                         *
    ***********************************************************************   %

let LENGTH_EQ = prove_thm (`LENGTH_EQ`,
    "! (x:* list) y. (x = y) ==> (LENGTH x = LENGTH y)",
    REPEAT GEN_TAC
    THEN DISCH_TAC
    THEN ASM_REWRITE_TAC []);;


%****************************************************************************%
%                                                                            %
% AUTHOR        : R.J.Boulton                                                %
% DATE          : 1990                                                       %
%                                                                            %
%****************************************************************************%
%----------------------------------------------------------------------------%
% LENGTH_NOT_NULL = |- !l. 0 < (LENGTH l) = ~NULL l                          %
%----------------------------------------------------------------------------%
%see also LENGTH_GR_0_NOT_NIL%

let LENGTH_NOT_NULL =
 prove_thm
  (`LENGTH_NOT_NULL`,
   "!(l:(*)list). (0 < LENGTH l) = (~(NULL l))",
   LIST_INDUCT_TAC THENL
   [REWRITE_TAC [LENGTH;NULL;NOT_LESS_0];
    REWRITE_TAC [LENGTH;NULL;LESS_0]]);;

%****************************************************************************%
% AUTHOR        : Rachel Cardell-Oliver                      		     %
% DATE		: 1 August 1989, 9 May 90                                    %
%                                                                            %
%****************************************************************************%

%Rename to avoid clash with LENGTH_TL %
let LENGTH_TL_SUB =prove_thm( `LENGTH_TL_SUB`,
 "!l:* list. ~NULL l ==> (LENGTH(TL l) = ((LENGTH l) - 1))",
  LIST_INDUCT_TAC THENL
  [ ASM_REWRITE_TAC[NULL] ;
    ASM_REWRITE_TAC[TL;LENGTH;SYM(SPEC_ALL PRE_SUB1);PRE]
  ] );;

%****************************************************************************%

let LENGTH_LESS_IMP_NOT_EQ = prove_thm(`LENGTH_LESS_IMP_NOT_EQ`,
   "!l1 l2:* list. (LENGTH l1 < LENGTH l2) ==> ~(l1 = l2)",
   REPEAT STRIP_TAC THEN IMP_RES_TAC LESS_NOT_EQ THEN
   POP_ASSUM(\thm. MP_TAC thm) THEN ASM_REWRITE_TAC[]);;

%****************************************************************************%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   AUTHOR:       Paul Curzon                                                %
%   ORGANIZATION: U Cambridge CL                                             %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

let LENGTH_NULL = save_thm(`LENGTH_NULL`,
  (REWRITE_RULE[L_EQ_NIL] LENGTH_NIL));;

let list_NULL_CASES = save_thm(`list_NULL_CASES`,
  (REWRITE_RULE[L_EQ_NIL] list_CASES));;



let LENGTH1_CONS_HD = prove_thm(`LENGTH1_CONS_HD`,
 "!l:(* list) . (LENGTH l = 1) = ([HD l] = l)",

GEN_TAC THEN
EQ_TAC THENL
[
 STRIP_TAC THEN
 let asm  =  ASSUME "LENGTH (l:* list) = 1" in
 let th1 = REWRITE_RULE[SUC_0] asm in
 let th2 = MATCH_MP CONS (MATCH_MP LENGTH_EQ_SUC_IMP_NOT_NULL th1) in
  (REWRITE_TAC[GSYM (MATCH_MP TL_NIL asm);th2]);

 STRIP_TAC THEN
 let asm  =  GSYM (ASSUME "[HD l] = (l:* list)") in
 (ONCE_REWRITE_TAC[asm]) THEN
 (REWRITE_TAC[LENGTH;SUC_0])]);;


close_theory();;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   FILE:         tail.ml                                                    %
%   EDITOR:       Paul Curzon                                                %
%   ORGANIZATION: U Cambridge CL                                             %
%   DATE:         June 1991                                                  %
%   DESCRIPTION:  TAIL (as TL but with TAIL [] defined)                      %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%*********************************  HISTORY  ********************************%
%									     %
%   This file is based on the TAIL theory of				     %
%      Mike Benjamin(British Aerospace Sowerby Research Centre,Bristol)      %
%   with additional theorems by 					     %
%      Rachel Cardell-Oliver, and					     %
%      Paul Curzon 							     %
%                                                                            %
%  The names of some theorems have been changed from the original sources    %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%****************************************************************************%
%                                                                            %
%  DEPENDANCIES :                                                            %
%                                                                            %
%                                                                            %
%****************************************************************************%
system `rm -f tail.th`;;

new_theory `tail`;;

load_library `more_arithmetic`;;

new_parent `general_lists`;;



let autoload_defs_and_thms thy =
   map (\name. autoload_theory(`definition`,thy,name))
     (map fst (definitions thy));
   map (\name. autoload_theory(`theorem`,thy,name))
     (map fst (theorems thy)) in

autoload_defs_and_thms `general_lists`;;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   AUTHOR:       Mike Benjamin                                              %
%   ORGANIZATION: FPC 267                                                    %
%                 British Aerospace Sowerby Research Centre                  %
%                 PO BOX 5                                                   %
%                 Filton                                                     %
%                 Bristol  BS12 7QW                                          %
%                 Tel: (0272) 366198                                         %
%   EMAIL: benjamin@src.bae.co.uk                                            %
%   DATE:         31-5-1990                                                  %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%   **************************************************************************
    *                                                                        *
    *    Give a meaning to the tail of an empty list.                        *
    *                                                                        *
    *    TAIL = |- (TAIL[] = []) /\ (!h t. TAIL(CONS h t) = t)               * 
    *                                                                        *
    *************************************************************************%


let TAIL = new_recursive_definition false list_Axiom `TAIL` 
       "(TAIL ([]:* list) = ([]:* list)) /\ 
        (TAIL (CONS (h:*) t) = t)";;

%   **************************************************************************
    *                                                                        *
    *    Prove a basic theorem about list constructors and destructors using *
    *    the new definition of tail.                                         *
    *                                                                        *
    *    CON = |- !l. ~NULL l ==> (CONS(HD l)(TAIL l) = l)                   *
    *                                                                        *
    ************************************************************************* %

let CON = 
    prove_thm 
      (`CON`,
       "!l:(*)list. ~NULL l ==> (CONS (HD l) (TAIL l) = l)",
       STRIP_TAC THEN
       STRIP_ASSUME_TAC (SPEC "l:(*)list" list_CASES) THEN
       POP_ASSUM SUBST1_TAC THEN
       ASM_REWRITE_TAC [HD;CONJUNCT2 TAIL;NULL]);;


%   ***************************************************************************
    *                                                                         *
    *    Finding the tail of a list created by append.                        *
    *                                                                         *
    *    TAIL_APPEND =                                                        *
    *    |- !x y. TAIL(APPEND x y) = ((x = []) => TAIL y | APPEND(TAIL x)y)   *
    *                                                                         *
    ***********************************************************************   %

let TAIL_APPEND = prove_thm (`TAIL_APPEND`,
"! (x:* list)(y:* list). TAIL (APPEND x y) = ((x=([]:* list)) => (TAIL y) | (APPEND (TAIL x) y))",
LIST_INDUCT_TAC 
THEN REWRITE_TAC [APPEND]
THEN REWRITE_TAC [CONJUNCT2 TAIL;NOT_CONS_NIL]);;


%   ***************************************************************************
    *                                                                         *
    *    Prove new version of list cases for convenience.                     *
    *                                                                         *
    *    list_CASES2 = |- !l. (l = []) \/ (l = CONS(HD l)(TAIL l))            *
    *                                                                         *
    ***********************************************************************   %

let list_CASES2 = prove_thm (`list_CASES2`,
"! (l:* list). (l = []:* list) \/ (l = CONS (HD l) (TAIL l))",
GEN_TAC THEN
DISJ_CASES_TAC (SPEC_ALL list_CASES)
THENL [ 
  ASM_REWRITE_TAC [];
  CHOOSE_THEN 
      (CHOOSE_THEN  ASSUME_TAC) (ASSUME "?t h. (l:* list) = CONS h t") THEN
  ASM_REWRITE_TAC[MATCH_MP CON (SPEC_ALL (CONJUNCT2 NULL))]
]);;


%PC%
let list_NULL_CASES2 = save_thm(`list_NULL_CASES2`,
  (REWRITE_RULE[L_EQ_NIL] list_CASES2));;


%****************************************************************************%
%                                                                            %
% AUTHOR        : Rachel Cardell-Oliver                      		     %
% DATE		: 1 August 1989, 9 May 90                                    %
%                                                                            %
%****************************************************************************%



let LENGTH_TAIL =prove_thm( `LENGTH_TAIL`,
 "!l:* list. ~NULL l ==> (LENGTH(TAIL l) = ((LENGTH l) - 1))",
  LIST_INDUCT_TAC THENL
  [ ASM_REWRITE_TAC[NULL] ;
    ASM_REWRITE_TAC[TAIL;LENGTH;SYM(SPEC_ALL PRE_SUB1);PRE]
  ] );;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   AUTHOR:       Paul Curzon                                                %
%   ORGANIZATION: U Cambridge CL                                             %
%   DATE:         5-4-1991                                                   %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


let TL_TAIL = prove_thm(`TL_TAIL`,
"!l:* list. ~ (NULL l) ==> (TL l = TAIL l)",
 LIST_INDUCT_TAC
THENL
[ (REWRITE_TAC [NULL]);
  (REWRITE_TAC[TL;TAIL]) ]);;

% ----------------------------------------------------------------------- %
let NOT_NULL_TAIL  = prove_thm(`NOT_NULL_TAIL`,
"!l:* list. ~ (NULL (TAIL l)) ==> ~ (NULL l)",
LIST_INDUCT_TAC
THEN (REWRITE_TAC [NULL;TAIL])
);;
% *************************************************************************%

close_theory();;

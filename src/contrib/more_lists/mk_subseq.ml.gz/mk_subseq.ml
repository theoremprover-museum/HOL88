%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   FILE:         mk_subseq.ml                                               %
%   EDITOR:       Paul Curzon                                                %
%   ORGANIZATION: U Cambridge CL                                             %
%   DATE:         June 1991                                                  %
%   DESCRIPTION:  Make the theory of subsequences                            %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

system `rm -f subseq.th`;;

new_theory `subseq`;;



load_library `more_arithmetic`;;
load_library`auxiliary`;;

new_parent `tail`;;
new_parent `member`;;

loadf `../more_arithmetic/tools`;;

autoload_defs_and_thms `prim_rec`;; 
autoload_defs_and_thms `general_lists`;; 
autoload_defs_and_thms `tail`;; 
autoload_defs_and_thms `snoc`;;
autoload_defs_and_thms `member`;;
autoload_defs_and_thms `append`;;



loadt `firstn`;;
loadt `lastn`;;
loadt `unappend`;;


close_theory();;

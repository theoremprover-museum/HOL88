%----------------------------------------------------------------------------%
%                                                                            %
%   FILE:         range.ml                                                   %
%   EDITOR:       Paul Curzon                                                %
%   ORGANIZATION: U Cambridge CL                                             %
%   DATE:         June 1991                                                  %
%   DESCRIPTION:  Lists of consecutive numbers                               %
%                                                                            %
%----------------------------------------------------------------------------%


%*********************************  HISTORY  ********************************%
%									     %
%   This file contains list theorems and definitions from several            %
%   sources:  								     %
%      R.J.Boulton							     %
%      Andy Gordon	(Binomial Proof)				     %
%      Paul Curzon 							     %
%                                                                            %
%  The names of some theorems have been changed from the original sources    %
%  INTERVAL, which was defined in the Binomial proof has been proved in      %
%  terms of UPPTO                                                            %
%                                                                            %
%----------------------------------------------------------------------------%

%****************************************************************************%
%                                                                            %
%  DEPENDANCIES :                                                            %
%                                                                            %
%         library more_arithmetic  for arithmetic theorems                   %
%         general_lists            for general list theorems                 %
%         snoc                     for SNOC theorems                         %
%         map                      for MAP theorems                          %
%         el                       for EL1 theorems                          %
%         append                   for APPEND theorems                       %
%                                                                            %
%****************************************************************************%
system `rm -f num_lists.th`;;

new_theory `num_lists`;;

load_library `more_arithmetic`;;
%PC 13/8/92 more_arithmetic is no longer dependent on auxiliary. snoc2 is %
load_library `auxiliary`;;

new_parent `el`;;

autoload_defs_and_thms `map`;; 
autoload_defs_and_thms `general_lists`;;
autoload_defs_and_thms  `snoc`;;
autoload_defs_and_thms  `el`;;
autoload_defs_and_thms  `append`;;


%----------------------------------------------------------------------------%
%                                                                            %
%   AUTHOR:   Andy Gordon                                                    %
%           from his BINOMIAL proof                                          %
%                                                                            %
%----------------------------------------------------------------------------%

% ------------------------------------------------------------------------- %
% Definition of RANGE                                                       %
%                                                                           %
% ------------------------------------------------------------------------- %

let RANGE = 
    new_recursive_definition false num_Axiom `RANGE`
      "(RANGE m 0 = NIL) /\
       (RANGE m (SUC n) = CONS m (RANGE (SUC m) n))";;



% ------------------------------------------------------------------------- %
% Proofs of some properties of RANGE.                                       %
% ------------------------------------------------------------------------- %

let RANGE_TOP =
    prove_thm
    (`RANGE_TOP`,
    "!n m. RANGE m (SUC n) = APPEND (RANGE m n) [m+n]",
    INDUCT_TAC THENL
       [REWRITE_TAC [RANGE; APPEND; ADD_0];
        REWRITE_TAC [APPEND] THEN
        ONCE_REWRITE_TAC [RANGE] THEN
        POP_ASSUM(\th. REWRITE_TAC[th]) THEN
        REWRITE_TAC[APPEND; ADD; ADD_SUC] ]);;

let RANGE_SHIFT =
    prove_thm
    (`RANGE_SHIFT`,
    "!n m. RANGE (SUC m) n = MAP SUC (RANGE m n)",
    INDUCT_TAC THEN
    (GEN_TAC THEN ASM_REWRITE_TAC [RANGE; MAP]));;

%<-------------------------------------------------------------------------->%



%****************************************************************************%
%                                                                            %
% AUTHOR        : R.J.Boulton                                                %
% DATE          : 1990                                                       %
%                                                                            %
%****************************************************************************%


%----------------------------------------------------------------------------%
% FROM0 : num -> (num)list                                                   %
%                                                                            %
% FROM0 n = [0;1;...;n]                                                      %
%----------------------------------------------------------------------------%



let FROM0 =
 new_prim_rec_definition
  (`FROM0`,
   "(FROM0 0 = [0]) /\
    (FROM0 (SUC n) = (CONS 0 (MAP SUC (FROM0 n))))");;




%----------------------------------------------------------------------------%
% FROM0_APPEND = |- !n. FROM0(SUC n) = APPEND(FROM0 n)[SUC n]                %
%----------------------------------------------------------------------------%

let FROM0_APPEND =
 prove_thm
  (`FROM0_APPEND`,
   "!n. FROM0 (SUC n) = APPEND (FROM0 n) [SUC n]",
   INDUCT_TAC THENL
   [REWRITE_TAC [FROM0;MAP;APPEND];
    ONCE_REWRITE_TAC [FROM0] THEN
    ASM_REWRITE_TAC [] THEN
    REWRITE_TAC [APPEND;MAP_APPEND;MAP]]);;


%----------------------------------------------------------------------------%
% NOT_NULL_FROM0 = |- !n. ~NULL(FROM0 n)                                     %
%----------------------------------------------------------------------------%

let NOT_NULL_FROM0 =
 prove_thm
  (`NOT_NULL_FROM0`,
   "!n. ~(NULL (FROM0 n))",
   INDUCT_TAC THEN
   REWRITE_TAC [FROM0;NULL]);;



%----------------------------------------------------------------------------%
% FROM0_PRE = |- !n. 0 < n ==> (FROM0 n = CONS 0(MAP SUC(FROM0(PRE n))))     %
%----------------------------------------------------------------------------%

let FROM0_PRE =
 prove_thm
  (`FROM0_PRE`,
   "!n. (0 < n) ==> ((FROM0 n) = CONS 0 (MAP SUC (FROM0 (PRE n))))",
   INDUCT_TAC THENL
   [REWRITE_TAC [NOT_LESS_0];
    STRIP_TAC THEN
    REWRITE_TAC [PRE;FROM0]]);;

%----------------------------------------------------------------------------%
% FROM0_SUB =                                                                %
% |- !m n. m < n ==> (FROM0(n - m) = CONS 0(MAP SUC(FROM0(n - (SUC m)))))    %
%----------------------------------------------------------------------------%


let FROM0_SUB =
 prove_thm
  (`FROM0_SUB`,
   "!m n. (m < n) ==>
          (FROM0 (n - m) = CONS 0 (MAP SUC (FROM0 (n - (SUC m)))))",
   REPEAT STRIP_TAC THEN
   IMP_RES_TAC SUB_LESS_0 THEN
   IMP_RES_THEN (\th. REWRITE_TAC [th]) FROM0_PRE THEN
   IMP_RES_THEN (\th. REWRITE_TAC [th]) PRE_SUB_SUC);;


%----------------------------------------------------------------------------%
% LENGTH_FROM0 = |- !n. LENGTH(FROM0 n) = SUC n                              %
%----------------------------------------------------------------------------%

let LENGTH_FROM0 =
 prove_thm
  (`LENGTH_FROM0`,
   "!n. LENGTH (FROM0 n) = (SUC n)",
   INDUCT_TAC THENL
   [REWRITE_TAC [FROM0;LENGTH];
    ASM_REWRITE_TAC [FROM0;LENGTH;LENGTH_MAP]]);;
%----------------------------------------------------------------------------%
% EL_MAP_FROM0 =                                                             %
% |- !f m n. m <= n ==> (EL m(MAP f(FROM0 n)) = f(EL m(FROM0 n)))            %
%----------------------------------------------------------------------------%

let EL_MAP_FROM0 =
 prove_thm
  (`EL_MAP_FROM0`,
   "!(f:num->*) m n. (m <= n) ==>
                     (EL m (MAP f (FROM0 n)) = f (EL m (FROM0 n)))",
   REPEAT STRIP_TAC THEN
   IMP_RES_TAC LESS_EQ_LESS_SUC THEN
   ASSUM_LIST
    (\thl.
      EVERY
       (map (ASSUME_TAC o
             (REWRITE_RULE [SYM (SPEC_ALL LENGTH_FROM0)])) thl)) THEN
   IMP_RES_THEN (\th. REWRITE_TAC [th]) EL_MAP);;




%----------------------------------------------------------------------------%
% EL_FROM0 = |- !n m. m <= n ==> (EL m(FROM0 n) = m)                         %
%----------------------------------------------------------------------------%

let EL_FROM0 =
 prove_thm
  (`EL_FROM0`,
   "!n m. (m <= n) ==> (EL m (FROM0 n) = m)",
   INDUCT_TAC THENL
   [REWRITE_TAC [LESS_OR_EQ;NOT_LESS_0] THEN
    REPEAT STRIP_TAC THEN
    ASM_REWRITE_TAC [FROM0;EL;HD];
    INDUCT_TAC THENL
    [REWRITE_TAC [FROM0;EL;HD];
     REWRITE_TAC [LESS_EQ_MONO;FROM0;EL;TL] THEN
     STRIP_TAC THEN
     RES_TAC THEN
     IMP_RES_THEN (\th. ASM_REWRITE_TAC [th]) EL_MAP_FROM0]]);;


%----------------------------------------------------------------------------%
% EVERY_FROM0 = |- !n. EVERY(\m. m <= n)(FROM0 n)                            %
%----------------------------------------------------------------------------%

let EVERY_FROM0 =
 prove_thm
  (`EVERY_FROM0`,
   "!n. EVERY (\m. m <= n) (FROM0 n)",
   GEN_TAC THEN
   REWRITE_TAC [EVERY_EL] THEN
   REWRITE_TAC [LENGTH_FROM0] THEN
   REWRITE_TAC [SYM (SPEC_ALL LESS_EQ_LESS_SUC)] THEN
   REPEAT STRIP_TAC THEN
   BETA_TAC THEN
   IMP_RES_THEN (\th. REWRITE_TAC [th]) EL_FROM0 THEN
   ASM_REWRITE_TAC []);;

%----------------------------------------------------------------------------%
% UPTO : num -> num -> (num)list                                             %
%                                                                            %
% UPTO n m = [n;n+1;...;m-1;m] or [] if n > m.                               %
%----------------------------------------------------------------------------%

let UPTO =
 new_infix_definition
  (`UPTO`,
   "UPTO n1 n2 = (MAP ($+ n1) ((n1 <= n2) => (FROM0 (n2 - n1)) | []))");;


%----------------------------------------------------------------------------%
% SUC_UPTO_SUC = |- !m n. (SUC m) UPTO (SUC n) = MAP SUC(m UPTO n)           %
%----------------------------------------------------------------------------%

let SUC_UPTO_SUC =
 prove_thm
  (`SUC_UPTO_SUC`,
   "!m n. (SUC m) UPTO (SUC n) = MAP SUC (m UPTO n)",
   REPEAT GEN_TAC THEN
   REWRITE_TAC [UPTO] THEN
   REWRITE_TAC [LESS_OR_EQ;LESS_MONO_EQ;INV_SUC_EQ;SUB_MONO_EQ] THEN
   REWRITE_TAC [MAP_MAP_o] THEN
   REWRITE_TAC [o_DEF;SYM (el 3 (CONJUNCTS ADD_CLAUSES));ETA_AX]);;

%----------------------------------------------------------------------------%
% UPTO_EQ_CONS_SUC_UPTO =                                                    %
% |- !m n. m <= n ==> (m UPTO n = CONS m((SUC m) UPTO n))                    %
%----------------------------------------------------------------------------%

let UPTO_EQ_CONS_SUC_UPTO =
 prove_thm
  (`UPTO_EQ_CONS_SUC_UPTO`,
   "!m n. (m <= n) ==> (m UPTO n = CONS m ((SUC m) UPTO n))",
   REPEAT STRIP_TAC THEN
   REWRITE_TAC [UPTO] THEN
   ASM_REWRITE_TAC [] THEN
   ASM_CASES_TAC "m:num = n" THENL
   [ASM_REWRITE_TAC [NOT_SUC_LESS_EQ_SELF] THEN
    REWRITE_TAC [SUB_EQUAL_0;FROM0;MAP;ADD_CLAUSES];
    IMP_RES_TAC SUC_LESS_EQ THEN
    ASM_REWRITE_TAC [] THEN
    IMP_RES_TAC OR_LESS THEN
    IMP_RES_THEN (\th. REWRITE_TAC [th]) FROM0_SUB THEN
    REWRITE_TAC [MAP;ADD_CLAUSES] THEN
    REWRITE_TAC [MAP_MAP_o;o_DEF] THEN
    REWRITE_TAC [el 4 (CONJUNCTS ADD_CLAUSES)] THEN
    REWRITE_TAC [SYM (el 3 (CONJUNCTS ADD_CLAUSES))] THEN
    REWRITE_TAC [ETA_AX]]);;

%----------------------------------------------------------------------------%
% UPTO_SUC_EQ_APPEND_UPTO =                                                  %
% |- !m n. m <= (SUC n) ==> (m UPTO (SUC n) = APPEND(m UPTO n)[SUC n])       %
%----------------------------------------------------------------------------%
let UPTO_SUC_EQ_APPEND_UPTO =
 prove_thm
  (`UPTO_SUC_EQ_APPEND_UPTO`,
   "!m n. (m <= (SUC n)) ==> (m UPTO (SUC n) = APPEND (m UPTO n) [SUC n])",
   REPEAT STRIP_TAC THEN
   REWRITE_TAC [UPTO] THEN
   ASM_REWRITE_TAC [] THEN
   ASM_CASES_TAC "m = SUC n" THENL
   [ASM_REWRITE_TAC [NOT_SUC_LESS_EQ_SELF] THEN
    REWRITE_TAC [SUB_EQUAL_0;FROM0;MAP;APPEND;ADD_CLAUSES];
    IMP_RES_THEN (\th. ASSUME_TAC (REWRITE_RULE [LESS_EQ_MONO] th))
       SUC_LESS_EQ THEN
    RES_TAC THEN
    ASM_REWRITE_TAC [] THEN
    IMP_RES_THEN (\th. REWRITE_TAC [SUB;th]) (SYM (SPEC_ALL NOT_LESS)) THEN
    REWRITE_TAC [FROM0_APPEND;MAP_APPEND] THEN
    REWRITE_TAC [MAP;ADD_CLAUSES] THEN
    PURE_ONCE_REWRITE_TAC [ADD_SYM] THEN
    IMP_RES_THEN (\th. REWRITE_TAC [th]) SUB_ADD]);;
%----------------------------------------------------------------------------%
% EVERY_UPTO = |- !m n. EVERY(\p. m <= p /\ p <= n)(m UPTO n)                %
%----------------------------------------------------------------------------%

let EVERY_UPTO =
 prove_thm
  (`EVERY_UPTO`,
   "!m n. EVERY (\p. (m <= p) /\ (p <= n)) (m UPTO n)",
   REPEAT GEN_TAC THEN
   REWRITE_TAC [UPTO] THEN
   ASM_CASES_TAC "m <= n" THENL
   [ASM_REWRITE_TAC [EVERY_MAP] THEN
    REWRITE_TAC [o_DEF] THEN
    BETA_TAC THEN
    IMP_RES_THEN (\th. REWRITE_TAC [th]) ADD_LESS_EQ_SUB THEN
    REWRITE_TAC [LESS_EQ_ADD] THEN
    REWRITE_TAC [EVERY_FROM0];
    ASM_REWRITE_TAC [MAP;EVERY_DEF]]);;








%----------------------------------------------------------------------------%
% EL1_TL = |- !l. ~NULL l ==> (MAP(\n. EL1 n l)(2 UPTO (LENGTH l)) = TL l)   %
%----------------------------------------------------------------------------%

let lemma1 =
 prove
  ("(0 < n) = (2 <= (SUC n))",
   REWRITE_TAC [num_CONV "2";num_CONV "1"] THEN
   REWRITE_TAC [LESS_OR_EQ;INV_SUC_EQ;LESS_MONO_EQ] THEN
   REWRITE_TAC [SYM (SPEC_ALL LESS_OR_EQ);LESS_EQ]);;


let lemma2 =
 prove
  ("!n. (1 < n) ==> (0 < n)",
   REWRITE_TAC [num_CONV "1"] THEN
   INDUCT_TAC THENL
   [REWRITE_TAC [NOT_LESS_0];
    REWRITE_TAC [LESS_MONO_EQ;LESS_SUC]]);;


let lemma3 =
 prove
  ("!l. (EVERY (\n. 1 < n) l) ==> (EVERY (\n. 0 < n) l)",
   LIST_INDUCT_TAC THENL
   [REWRITE_TAC [EVERY_DEF];
    REWRITE_TAC [EVERY_DEF] THEN
    BETA_TAC THEN
    REPEAT STRIP_TAC THENL
    [IMP_RES_THEN (\th. REWRITE_TAC [th]) lemma2;
     RES_THEN (\th. REWRITE_TAC [th])]]);;


let lemma4 =
 prove
  ("!l. EVERY (\n. 1 < n) (MAP ($+ 2) l)",
   LIST_INDUCT_TAC THEN
   REWRITE_TAC [MAP;EVERY_DEF] THEN
   BETA_TAC THEN
   ASM_REWRITE_TAC
      [num_CONV "2";num_CONV "1";ADD_CLAUSES;LESS_MONO_EQ;LESS_0]);;


let lemma5 =
 prove
  ("!m. EVERY (\n. 1 < n) (2 UPTO m)",
   REWRITE_TAC [UPTO;lemma4]);;

let lemma6 =
 prove
  ("!(h:*) l. EL1 2 (CONS h l) = HD l",
   REWRITE_TAC [num_CONV "2";num_CONV "1"] THEN
   REWRITE_TAC [EL1;EL;TL]);;


let EL1_TL =
 prove_thm
  (`EL1_TL`,
   "!(l:(*)list). (~(NULL l)) ==>
                  (MAP (\n. EL1 n l) (2 UPTO (LENGTH l)) = (TL l))",
   LIST_INDUCT_TAC THENL
   [REWRITE_TAC [NULL];
    REWRITE_TAC [NULL;LENGTH;TL] THEN
    ASM_CASES_TAC "LENGTH (l:(*)list) = 0" THENL
    [IMP_RES_TAC LENGTH_NIL THEN
     ASM_REWRITE_TAC [UPTO;num_CONV "2";num_CONV "1"] THEN
     REWRITE_TAC [LESS_OR_EQ;LESS_MONO_EQ;INV_SUC_EQ;NOT_LESS_0;NOT_SUC] THEN
     REWRITE_TAC [MAP];
     IMP_RES_TAC (REWRITE_RULE [ADD_CLAUSES] (SPEC "0" LESS_ADD_NONZERO)) THEN
     IMP_RES_TAC LENGTH_NOT_NULL THEN
     RES_TAC THEN
     IMP_RES_TAC lemma1 THEN
     IMP_RES_THEN (\th. REWRITE_TAC [th]) UPTO_EQ_CONS_SUC_UPTO THEN
     REWRITE_TAC [MAP;SUC_UPTO_SUC] THEN
     REWRITE_TAC [MAP_MAP_o;o_DEF] THEN
     BETA_TAC THEN
     REWRITE_TAC
      [MATCH_MP MAP_EL1_SUC_CONS
        (MATCH_MP lemma3 (SPEC "LENGTH (l:(*)list)" lemma5))] THEN
     ASM_REWRITE_TAC [lemma6] THEN
     IMP_RES_THEN (\th. REWRITE_TAC [th]) CONS]]);;
%----------------------------------------------------------------------------%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   AUTHOR:       Paul Curzon                                                %
%   ORGANIZATION: U Cambridge CL                                             %
%   DATE:         June 1991                                                  %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% a theorem  proving the INTERVAL definition of ADG in terms of UPTO    %

let INTERVAL0 = prove(
 "(!m. m UPTO 0 = (m > 0) => NIL | [0])",

 GEN_TAC THEN
 (REWRITE_TAC [UPTO;SUB_0;FROM0]) THEN
 (ASM_CASES_TAC "m > 0") THENL
  [
   (ASM_REWRITE_TAC[]) THEN
% PC 13/8/92 NOT_LESS_EQ_LESS -> NOT_LESS_EQUAL%
%   (POP_TAC (REWRITE_RULE[GREATER; GSYM NOT_LESS_EQ_LESS])) THEN%
   (ASM_REWRITE_TAC[MAP;
                REWRITE_RULE[GREATER; GSYM NOT_LESS_EQUAL] (ASSUME"m > 0") ]);

   let th1 = REWRITE_RULE[GREATER; NOT_LESS]  (ASSUME "~m > 0") in
   let th2 = MATCH_MP LESS_EQ_0_EQ th1  in
   (REWRITE_TAC[th1]) THEN
   (ASM_REWRITE_TAC[MAP;ADD_CLAUSES;th2])
  ]);;

let INTERVAL_SUC = prove(
"!m n. m UPTO (SUC n) =
          (m > (SUC n)) => NIL | SNOC (SUC n) (m UPTO n)",

  GEN_TAC THEN
  GEN_TAC THEN
  (REWRITE_TAC [UPTO;SUB_0;GREATER]) THEN
  (ASM_CASES_TAC "m <= n") THENL
  [
   (IMP_RES_TAC LESS_EQ_IMP_LESS_SUC) THEN
   (IMP_RES_TAC LESS_IMP_LESS_OR_EQ) THEN
   (IMP_RES_TAC NOT_LESS) THEN
   (IMP_RES_TAC SUC_SUB) THEN
   (ASM_REWRITE_TAC
     [FROM0_APPEND; GSYM SNOC_APPEND_CONS;MAP_SNOC;ADD_CLAUSES]) THEN
   (IMP_RES_TAC LESS_EQ_ADD_SUB1) THEN
   (ASM_REWRITE_TAC
     [FROM0_APPEND; GSYM SNOC_APPEND_CONS;MAP_SNOC;
      ADD_CLAUSES;ONCE_REWRITE_RULE[ADD_SYM] ADD_SUB]);

   (ASM_REWRITE_TAC[MAP;SNOC_DEF]) THEN
   (ASM_CASES_TAC "SUC n = m") THENL
   [
     (ASM_REWRITE_TAC
        [SUB_EQUAL_0;FROM0;LESS_OR_EQ;LESS_REFL;MAP;ADD_CLAUSES]);

     let th1 = REWRITE_RULE[NOT_LESS_EQUAL] (ASSUME "~m <= n") in
     let th2 = MATCH_MP LESS_NOT_SUC
                     (CONJ th1 (GSYM (ASSUME "~(SUC n = m)"))) in
     let th3 = REWRITE_RULE[GSYM NOT_LESS_EQUAL]  th2 in
     (ASM_REWRITE_TAC[MAP;th2;th3])

   ]
  ]);;


let INTERVAL = prove_thm (`INTERVAL`,
  "(!m. m UPTO 0 = (m > 0) => NIL | [0]) /\
   (!m n. m UPTO (SUC n) =
          (m > (SUC n)) => NIL | SNOC (SUC n) (m UPTO n))",

 (REWRITE_TAC [INTERVAL_SUC;INTERVAL0]));;




close_theory();;

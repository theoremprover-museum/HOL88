%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   FILE:         clauses.ml                                                 %
%   EDITOR:       Paul Curzon                                                %
%   ORGANIZATION: U Cambridge CL                                             %
%   DATE:         June 1991                                                  %
%   DESCRIPTION:  APPEND abbreviation, LENGTH_CLAUSES                        %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%*********************************  HISTORY  ********************************%
%									     %
%   This file is part of the list theory by				     %
%      Paul Loewenstein							     %
%                                                                            %
%  The names of some theorems have been changed from the original sources    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%****************************************************************************%
%                                                                            %
%  DEPENDANCIES :                                                            %
%                                                                            %
%         library more_arithmetic  for arithmetic theorems                   %
%         general_lists            for general list theorems                 %
%         snoc                     for SNOC theorems                         %
%                                                                            %
%****************************************************************************%


%------------------------------------------------------------------------- %
%   APPEND_CLAUSES                                                         %
%------------------------------------------------------------------------- %


let APPEND_NULL = TAC_PROOF (([], "!l1:(*)list. APPEND l1 [] = l1"),
 LIST_INDUCT_TAC THEN
 ASM_REWRITE_TAC[APPEND]);;

let APPEND_SNOC = TAC_PROOF (([], "!(d:*) l1 l2. APPEND l1 (SNOC d l2) =
 SNOC d (APPEND l1 l2)"),
 GEN_TAC THEN
 LIST_INDUCT_TAC THEN
 ASM_REWRITE_TAC[APPEND;SNOC_DEF]);;



let APPEND_CLAUSES = save_thm (`APPEND_CLAUSES`,
 CONJ (GEN_ALL (CONJUNCT1 APPEND)) (CONJ APPEND_NULL
 (CONJ (GEN_ALL (CONJUNCT2 APPEND)) APPEND_SNOC)));;


%------------------------------------------------------------------------- %
%   LENGTH_CLAUSES                                                         %
%------------------------------------------------------------------------- %



let SNOC_LENGTH = TAC_PROOF (([], "! (d:*) l. LENGTH (SNOC d l) = SUC (LENGTH l)"),
 GEN_TAC THEN
 LIST_INDUCT_TAC THEN
 ASM_REWRITE_TAC [LENGTH;SNOC_DEF]);;

let LENGTH_REVERSE = TAC_PROOF(
 ([],"! l:(*)list. LENGTH (REVERSE l) = LENGTH l"),
 LIST_INDUCT_TAC THEN
 ASM_REWRITE_TAC[LENGTH;REVERSE_DEF;SNOC_LENGTH]);;

let LENGTH_CLAUSES = save_thm (`LENGTH_CLAUSES`,
 CONJ (GEN_ALL (CONJUNCT1 LENGTH)) (CONJ (GEN_ALL (CONJUNCT2 LENGTH))
 (CONJ SNOC_LENGTH (CONJ LENGTH_APPEND LENGTH_REVERSE))));;





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   FILE:         append_snoc.ml                                             %
%   EDITOR:       Paul Curzon                                                %
%   ORGANIZATION: U Cambridge CL                                             %
%   DATE:         5-4-1991                                                   %
%   DESCRIPTION:  Theorems about APPEND and SNOC                             %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%*********************************  HISTORY  ********************************%
%									     %
%   This file contains list theorems and definitions from several            %
%   sources:  								     %
%      Paul Curzon 							     %
%      Wim Ploegaerts   (Imec vzw Leuven, Belgium)			     %
%                                                                            %
%  The names of some theorems have been changed from the original sources    %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%****************************************************************************%
%                                                                            %
%  DEPENDANCIES :                                                            %
%                                                                            %
%         library more_arithmetic  for arithmetic theorems                   %
%                                                                            %
%****************************************************************************%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   AUTHOR:       Paul Curzon                                                %
%   ORGANIZATION: U Cambridge CL                                             %
%   DATE:         June 1991                                                  %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

let SNOC_APPEND_CONS = prove_thm(`SNOC_APPEND_CONS`,
   "!(l:(*) list) h. SNOC h l = APPEND l [h]",

   LIST_INDUCT_TAC THENL
   [ REWRITE_TAC [SNOC_DEF;APPEND];
     ASM_REWRITE_TAC [SNOC_DEF;APPEND]]);;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   AUTHOR:       Paul Curzon                                                %
%   ORGANIZATION: U Cambridge CL                                             %
%   DATE:         June 1991                                                  %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% A theorem giving the more normal definition of REVERSE                     %

let REVERSE = prove_thm(`REVERSE`,
 " (REVERSE [] = ([]:(*)list)) /\      
   (!h (t:(*)list). REVERSE (CONS h t) = APPEND (REVERSE t) [h])",
 (REWRITE_TAC[REVERSE_DEF;SNOC_APPEND_CONS]));;


%<-------------------------------------------------------------------------->%
%New proof by PC%
let REVERSE_APPEND = prove_thm (`REVERSE_APPEND`,
"!(l1:(*)list) l2.
  REVERSE (APPEND l2 l1) = (APPEND (REVERSE l1) (REVERSE l2))",
 GEN_TAC THEN
 LIST_INDUCT_TAC THEN
 ASM_REWRITE_TAC[APPEND_CLAUSES;REVERSE_DEF]);;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   AUTHOR:       Wim Ploegaerts                                             %
%   ORGANIZATION: Imec vzw.                                                  %
%                 Kapeldreef 75                                              %
%                 3030 Leuven, Belgium                                       %
%   DATE:         31-5-1990                                                  %
%                                                                            %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%<-------------------------------------------------------------------------->%
% See also REVERSE_CLAUSES %
let REVERSE_APPEND_EL_CONS = prove_thm (
  `REVERSE_APPEND_EL_CONS`,
  "! (h:*) t . REVERSE (APPEND t [h]) = (CONS h (REVERSE t))",
  REWRITE_TAC [REVERSE_APPEND;REVERSE;APPEND]
);;

%<-------------------------------------------------------------------------->%

let APPEND_EL_REVERSE_CONS = prove_thm (`APPEND_EL_REVERSE_CONS`,
   "!t (h:*)  .  (APPEND t [h]) = REVERSE (CONS h (REVERSE t))",
    ACCEPT_TAC (
   GEN_ALL (REWRITE_RULE [REVERSE_REVERSE]
      (AP_TERM "REVERSE:(*)list -> (*)list" (SPEC_ALL REVERSE_APPEND_EL_CONS))))
);;

%<-------------------------------------------------------------------------->%


let LENGTH_APPEND_EL = prove_thm (
  `LENGTH_APPEND_EL`,
  " !(l1:(*)list) y1 l2 y2 .
         (APPEND l1 [y1] = APPEND l2 [y2]) ==>
                  (LENGTH l1 = LENGTH l2)",
  REPEAT STRIP_TAC THEN
  RULE_ASSUM_TAC (AP_TERM "LENGTH:(*)list -> num" ) THEN
  RULE_ASSUM_TAC (REWRITE_RULE [LENGTH_CLAUSES;LENGTH;EQ_MONO_ADD_EQ]) THEN
  FIRST_ASSUM ACCEPT_TAC
);;


%<-------------------------------------------------------------------------->%

let APPEND_CONS_EQ_APPEND = prove_thm (
  `APPEND_CONS_EQ_APPEND`,
  " ! (l1:(*)list) l2 h .
           APPEND l1 (CONS h l2) = APPEND (APPEND l1 [h]) l2",
  REPEAT GEN_TAC THEN
  CONV_TAC (LHS_CONV (ONCE_DEPTH_CONV (REWR_CONV CONS_APPEND_CONS))) THEN
  REWRITE_TAC [APPEND_ASSOC]
);;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%<
   A theorem for allowing recursive definitions such as with CONS h t, but
   with APPEND t [h],  this theorem has the form accepted by Tom Melhams
   package (such that prove_induction_theorem works !)

   This is basicly the same as SNOC_Axiom. The proof has been changed by PC 
   to use that theorem.
>%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


let list_APPEND_Axiom =  prove_thm (
  `list_APPEND_Axiom`,
    "! (x:**) f . 
     ?! (fa:(*)list -> **) . 
          (fa [] = x)  /\ ( ! h t . fa (APPEND t [h]) = f (fa t) h t)",
    (REWRITE_TAC[GSYM SNOC_APPEND_CONS;SNOC_Axiom]));;



let list_APPEND_INDUCT = 
    save_thm (`list_APPEND_INDUCT`,prove_induction_thm list_APPEND_Axiom);;


let LIST_APPEND_INDUCT_TAC = INDUCT_THEN list_APPEND_INDUCT ASSUME_TAC;;
%<-------------------------------------------------------------------------->%

%<
list_APPEND_CASES = |- !l. (l = []) \/ (?t h. l = APPEND t[h]) :
>%


let list_APPEND_CASES = 
    save_thm (`list_APPEND_CASES`,prove_cases_thm list_APPEND_INDUCT);;

let list_APPEND_NULL_CASES = 
    save_thm (`list_APPEND_NULL_CASES`,
  REWRITE_RULE[L_EQ_NIL] list_APPEND_CASES);;


%<-------------------------------------------------------------------------->%
%<
APPEND_EL_11 = 
|- !l1 y1 l2 y2.
    (APPEND l1[y1] = APPEND l2[y2]) = (l1 = l2) /\ ([y1] = [y2])
>%


let APPEND_EL_11 = 
    save_thm (`APPEND_EL_11`,
       GEN_ALL (SPECL ["y1:*";"l1:(*)list";"y2:*";"l2:(*)list"]
                   (prove_constructors_one_one list_APPEND_Axiom)));;

%<
NOT_NIL_APPEND_EL = |- !l h. ~([] = APPEND l[h]) : thm
>%

let NOT_NIL_APPEND_EL = 
   save_thm (`NOT_NIL_APPEND_EL`,
      GEN_ALL (SPECL ["l:(*)list";"h:*"]
                  (prove_constructors_distinct list_APPEND_Axiom)));;

%----------------------------------------------------------------------------%
%PC%
let APPEND_CONS_EQ_APPEND_SNOC = prove_thm (`APPEND_CONS_EQ_APPEND_SNOC`,
  " ! (l1:(*)list) l2 h .
           APPEND l1 (CONS h l2) = APPEND (SNOC h l1) l2",
  (ONCE_REWRITE_TAC[SNOC_APPEND_CONS;APPEND_CONS_EQ_APPEND]) THEN
  (REPEAT GEN_TAC) THEN
  REFL_TAC);;





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   AUTHOR:       Paul Curzon                                                %
%   ORGANIZATION: U Cambridge CL                                             %
%   DATE:         June 1991                                                  %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



let LAST1 = prove_thm(`LAST1`,
"!l y. LAST (APPEND l [y:*]) = y",
 (REWRITE_TAC[GSYM SNOC_APPEND_CONS;LAST]));;

%<-------------------------------------------------------------------------->%


let BUTLAST1 = prove_thm(`BUTLAST1`,
"!l y. BUTLAST (APPEND l [y:*]) = l",
 (REWRITE_TAC[GSYM SNOC_APPEND_CONS;BUTLAST]));;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   AUTHOR:       Wim Ploegaerts                                             %
%   ORGANIZATION: Imec vzw.                                                  %
%                 Kapeldreef 75                                              %
%                 3030 Leuven, Belgium                                       %
%   DATE:         31-5-1990                                                  %
%                                                                            %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%<-------------------------------------------------------------------------->%
%see also SNOC %
let APPEND_BUTLAST_LAST = prove_thm (
  `APPEND_BUTLAST_LAST`,
  "! l:(*)list . ~(NULL l) ==> (APPEND (BUTLAST l) [LAST l] = l)",
  REWRITE_TAC[GSYM SNOC_APPEND_CONS;L_EQ_NIL;SNOC]
);;


%<-------------------------------------------------------------------------->%
let LAST_APPEND = prove_thm (
  `LAST_APPEND`,
  "! l2:(*)list . ~(NULL l2) ==> (! l1 . LAST (APPEND l1 l2) = LAST l2)",
%PC 13/8/92 Remove dependency on auxiliary library%
%  (2 TIMES STRIP_TAC) THEN%
  (STRIP_TAC THEN STRIP_TAC) THEN
  LIST_INDUCT_TAC THEN
  IMP_RES_TAC IMP_APPEND_NOT_NULL THEN
  RULE_ASSUM_TAC SPEC_ALL THEN
  IMP_RES_TAC LAST_CONS_NOT_NULL THEN
  ASM_REWRITE_TAC [APPEND]
);;

%<-------------------------------------------------------------------------->%

let BUTLAST_APPEND = prove_thm (
  `BUTLAST_APPEND`,
  "! l2:(*)list . ~(NULL l2) ==> 
            (! l1 . BUTLAST (APPEND l1 l2) = APPEND l1 (BUTLAST l2))",
%PC 13/8/92 Remove dependency on auxiliary library%
%  (2 TIMES STRIP_TAC) THEN%
  (STRIP_TAC THEN STRIP_TAC) THEN
  LIST_INDUCT_TAC THEN
  IMP_RES_TAC IMP_APPEND_NOT_NULL THEN
  RULE_ASSUM_TAC SPEC_ALL THEN
  IMP_RES_TAC BUTLAST_CONS_NOT_NULL THEN
  ASM_REWRITE_TAC [APPEND]
);;


%****************************************************************************%
%                                                                            %
% AUTHOR        : Rachel Cardell-Oliver                      		     %
% DATE		: 1 August 1989, 9 May 90                                    %
%                                                                            %
%****************************************************************************%



let APPEND_JOIN = prove_thm(`APPEND_JOIN`,
 "!l1 l2:* list.
  ~(NULL l1) /\ ~(NULL l2) ==> 
        ((APPEND l1 l2) = (APPEND (BUTLAST l1)
                                  (APPEND [LAST l1;HD l2] (TL l2))))",
  LIST_INDUCT_TAC THENL
  [ REWRITE_TAC[NULL] ;
    REPEAT GEN_TAC THEN POP_ASSUM(ASSUME_TAC o SPEC "l2:* list") THEN
    ASM_CASES_TAC "NULL (l2:* list)" THENL
    [ ASM_REWRITE_TAC[] ;
      ASM_REWRITE_TAC[NULL;APPEND;LAST_CONS;BUTLAST_CONS] THEN
      ASM_CASES_TAC "NULL (l1:* list)" THENL
      [ IMP_RES_TAC NULL_EQ_EMPTY THEN
        IMP_RES_TAC CONS THEN ASM_REWRITE_TAC[APPEND] ;
        RES_TAC THEN IMP_RES_TAC CONS THEN ASM_REWRITE_TAC[APPEND] ]]] );;




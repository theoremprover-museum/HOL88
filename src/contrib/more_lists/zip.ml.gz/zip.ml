%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   FILE:         zip.ml                                                     %
%   EDITOR:       Paul Curzon                                                %
%   ORGANIZATION: U Cambridge CL                                             %
%   DATE:         June 1991                                                  %
%   DESCRIPTION   : Zipping and unzipping pairs of lists		     %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%*********************************  HISTORY  ********************************%
%									     %
%   This file is based on the PL theory of 				     %
%      Paul Loewenstein							     %
%  Minor additions and name changes have been made by			     %
%      Paul Curzon                                                           %
%                                                                            %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%****************************************************************************%
%                                                                            %
%  DEPENDANCIES :                                                            %
%                                                                            %
%         library more_arithmetic  for arithmetic theorems                   %
%                                                                            %
%****************************************************************************%

system `rm -f zip.th`;;
new_theory `zip`;;

load_library `more_arithmetic`;;
%PC 13/8/92 more_arithmetic is no longer dependent on auxiliary. snoc2 is %
load_library `auxiliary`;;


%****************************************************************************%
%                                                                            %
% AUTHOR        : Paul Loewenstein                      		     %
% DATE		: 2 June 1989	                                             %
%                                                                            %
%****************************************************************************%




%****************************************************************************%

let ZIP_DEF = new_list_rec_definition (`ZIP_DEF`,
 "(ZIP (l:(*)list) [] = []) /\
  (ZIP l (CONS (h:**) t) = NULL l => [] | CONS (HD l,h) (ZIP (TL l) t))");;

let UNZIP_FST = new_list_rec_definition (`UNZIP_FST`,
  "((UNZIP_FST:(*#**)list -> (*)list) [] = []) /\
   (UNZIP_FST (CONS h t) = CONS (FST h) (UNZIP_FST t))");;
			       
let UNZIP_SND = new_list_rec_definition (`UNZIP_SND`,
 "((UNZIP_SND:(*#**)list -> (**)list) [] = []) /\
  (UNZIP_SND (CONS h t) = CONS (SND h) (UNZIP_SND t))");;
%****************************************************************************%

let ZIP = prove_thm(`ZIP`,
  "(ZIP ([]:(*)list) ([]:(**)list) = []) /\
   (!(h1:*) t1. ZIP (CONS h1 t1) ([]:(**)list) = []) /\
   (!(h2:**) t2. ZIP ([]:(*)list) (CONS h2 t2) = []) /\
   (!(h1:*) t1 (h2:**) t2.
    ZIP (CONS h1 t1) (CONS h2 t2) = CONS (h1,h2) (ZIP t1 t2))",
 REWRITE_TAC[ZIP_DEF;NULL;HD;TL]);;			       
%****************************************************************************%

%PC%
let ZIP_CLAUSES = TAC_PROOF(([],
 " (!(l:* list). ZIP ([]:(**)list) l = []) /\
   (!(l:* list). ZIP l ([]:(**)list) = []) /\
   (!(h1:*) t1 (h2:**) t2.
       ZIP (CONS h1 t1) (CONS h2 t2) = CONS (h1,h2) (ZIP t1 t2))"),	

 (REWRITE_TAC[ZIP]) THEN
 (REPEAT STRIP_TAC) THEN
 (DISJ_CASES_THENL 
      [ASSUME_TAC; CHOOSE_THEN (CHOOSE_THEN ASSUME_TAC)]
      (SPEC_ALL list_CASES)) THEN
 (ASM_REWRITE_TAC[ZIP]));;

%****************************************************************************%



let ZIP_UNZIP_FST_SND = TAC_PROOF (([],
  "!l:(*#**)list. ZIP (UNZIP_FST l) (UNZIP_SND l) = l"),
 LIST_INDUCT_TAC THEN
 ASM_REWRITE_TAC[UNZIP_FST;UNZIP_SND;ZIP]);;

let UNZIP_FST_ZIP = TAC_PROOF (([],
  "!(l1:(*)list) (l2:(**)list). LENGTH l1 <= LENGTH l2 =
    (UNZIP_FST (ZIP l1 l2) = l1)"),
 REPEAT (LIST_INDUCT_TAC ORELSE GEN_TAC) THENL
 [
  REWRITE_TAC[UNZIP_FST;ZIP;LENGTH;ZERO_LESS_EQ]
 ;
  REWRITE_TAC[UNZIP_FST;ZIP;LENGTH;ZERO_LESS_EQ]
 ;
  REWRITE_TAC[LENGTH;LESS_OR_EQ;NOT_LESS_0;NOT_SUC;UNZIP_FST;ZIP;NOT_NIL_CONS]
 ;
  ASM_REWRITE_TAC[LENGTH;LESS_EQ_MONO;UNZIP_FST;ZIP;CONS_11]
 ]);;
%****************************************************************************%

let UNZIP_SND_ZIP = TAC_PROOF (([],
  "!(l1:(*)list) (l2:(**)list). LENGTH l2 <= LENGTH l1 =
    (UNZIP_SND (ZIP l1 l2) = l2)"),
 REPEAT (LIST_INDUCT_TAC ORELSE GEN_TAC) THENL
 [
  REWRITE_TAC[UNZIP_SND;ZIP;LENGTH;ZERO_LESS_EQ]
 ;
  REWRITE_TAC[LENGTH;LESS_OR_EQ;NOT_LESS_0;NOT_SUC;UNZIP_SND;ZIP;NOT_NIL_CONS]
 ;
  REWRITE_TAC[UNZIP_SND;ZIP;LENGTH;ZERO_LESS_EQ]
 ;
  ASM_REWRITE_TAC[LENGTH;LESS_EQ_MONO;UNZIP_SND;ZIP;CONS_11]
 ]);;
%****************************************************************************%


let FST_SND_UNZIP_ZIP = TAC_PROOF (([],
  "!(l1:(*)list) (l2:(**)list). (LENGTH l1 = LENGTH l2) =
    (UNZIP_FST (ZIP l1 l2) = l1) /\ (UNZIP_SND (ZIP l1 l2) = l2)"),
 REPEAT GEN_TAC THEN
 REWRITE_TAC[SYM (SPEC_ALL LESS_EQ_LESS_EQ_EQ)] THEN
 SUBST_TAC (map SPEC_ALL [UNZIP_FST_ZIP;UNZIP_SND_ZIP]) THEN
 REFL_TAC);;

%****************************************************************************%





save_thm (`ZIP_CLAUSES`,ZIP_CLAUSES);;
save_thm (`ZIP_UNZIP_FST_SND`,ZIP_UNZIP_FST_SND);;
save_thm (`UNZIP_FST_ZIP`,UNZIP_FST_ZIP);;
save_thm (`UNZIP_SND_ZIP`,UNZIP_SND_ZIP);;
save_thm (`FST_SND_UNZIP_ZIP`,FST_SND_UNZIP_ZIP);;

close_theory();;

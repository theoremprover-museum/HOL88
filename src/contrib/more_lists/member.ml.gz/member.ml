
%****************************************************************************%
% FILE          : member.ml                                                  %
% DESCRIPTION   : List Membership                                            %
%                 Test for a list being an initial sublist                   %
% AUTHOR        : P. Curzon                                                  %
% DATE          : Sept  1991                                                 %
%                                                                            %
%****************************************************************************%
%                                                                            %
%  DEPENDANCIES :                                                            %
%                                                                            %
%         library more_arithmetic  for arithmetic theorems                   %
%         library TAUT             for TAUT_TAC                              %
%         general_lists            for general list theorems                 %
%         snoc.ml                  for SNOC definition                       %
%         append.ml                for append theorems                       %
%                                                                            %
%****************************************************************************%


%*********************************  HISTORY  ********************************%
%									     %
%   This file includes theorems and definitions from 			     %
%      Paul Curzon							     %
%      Paul Loewenstein							     %
%                                                                            %
%  The names of some theorems have been changed from the original sources    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
system `rm -f member.th`;;

new_theory `member`;;


load_library `more_arithmetic`;;
%PC 13/8/92 more_arithmetic is no longer dependent on auxiliary. snoc2 is %
load_library `auxiliary`;;
load_library `taut`;;

new_parent `last_subseq`;;

autoload_defs_and_thms `snoc`;;
autoload_defs_and_thms `general_lists`;;
autoload_defs_and_thms `append`;;


let SNOC_INDUCT_TAC = INDUCT_THEN SNOC_INDUCT ASSUME_TAC;;


%****************************************************************************%
% AUTHOR        : Paul Loewenstein                      		     %
% DATE		: 2 June 1989	                                             %
%                                                                            %
%****************************************************************************%

%------------------------------------------------------------------------- %
%  list Membership                                                         %
%------------------------------------------------------------------------- %




let MEMBER = new_list_rec_definition (`MEMBER`,
 "(MEMBER (x:*) [] = F) /\
  (MEMBER x (CONS h t) = (h = x) \/ MEMBER x t)");;

let MEMBER_SNOC = prove_thm (`MEMBER_SNOC`,
 "!t (x:*) h. MEMBER x (SNOC h t) = (h = x) \/ MEMBER x t",
 LIST_INDUCT_TAC THEN
 ASM_REWRITE_TAC[MEMBER;SNOC_DEF] THEN
 TAUT_TAC);;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   AUTHOR:       Paul Curzon                                                %
%   ORGANIZATION: U Cambridge CL                                             %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%----------------------------------------------------------------------------%
% Tests for initial sublists                                                 %
%----------------------------------------------------------------------------%


%----------------------------------------------------------------------------%
% DEFINITIONS                                                                %
%----------------------------------------------------------------------------%


let LLESS_LEFT = new_infix_list_rec_definition(`LLESS_LEFT`,
      "(LLESS_LEFT ([]:* list) l = ~(NULL l)) /\
       (LLESS_LEFT (CONS a rest)  l =
             ~(NULL l) /\ (a = HD l) /\ (LLESS_LEFT rest (TL l)))");;

%**************************************************************************%

let LLEQ_LEFT = new_infix_definition(`LLEQ_LEFT`,
      "LLEQ_LEFT (l1:* list) l2 = (l1 LLESS_LEFT l2) \/ (l1 = l2)");;

%**************************************************************************%

%----------------------------------------------------------------------------%
% THEOREMS                                                                   %
%----------------------------------------------------------------------------%

%**************************************************************************%
let NOT_LLESS_LEFT_NIL = prove_thm(`NOT_LLESS_LEFT_NIL`,
"!l:(*)list . ~ (l LLESS_LEFT [])",
LIST_INDUCT_TAC
THENL
[ (REWRITE_TAC [LLESS_LEFT;NULL]);
  (ASM_REWRITE_TAC [LLESS_LEFT;NULL]) ]);;
%**************************************************************************%
let LLESS_LEFT_LENGTH1_NULL = prove_thm (`LLESS_LEFT_LENGTH1_NULL`,
"!(l1:(*)list) l2.
     l2 LLESS_LEFT l1 /\
     (LENGTH l1 = 1) ==>
          (NULL l2)",
GEN_TAC
THEN LIST_INDUCT_TAC
THENL
[ (REWRITE_TAC [NULL]);
  (REWRITE_TAC [LLESS_LEFT;LENGTH_NIL])
  THEN (REPEAT STRIP_TAC)
  THEN (POP_ASSUM (\th. ASSUME_TAC  (REWRITE_RULE [LENGTH_NIL] th)) )
  THEN (IMP_RES_TAC TL_NIL)
  THEN
   (CONTR_TAC
     (REWRITE_RULE
       [ASSUME "TL (l1:(*)list) = []";NOT_LLESS_LEFT_NIL]
         (ASSUME "l2 LLESS_LEFT (TL (l1:(*)list))")))]);;

%**************************************************************************%
let CONS_LLESS_LEFT_TL = prove_thm (`CONS_LLESS_LEFT_TL`,
"! (l1:* list) l2.
       ((CONS h l1) LLESS_LEFT l2) ==> (l1 LLESS_LEFT (TL l2))",
LIST_INDUCT_TAC
THENL
[ (REWRITE_TAC [LLESS_LEFT])
  THEN  (REPEAT STRIP_TAC);
  (REWRITE_TAC [LLESS_LEFT])
  THEN (REPEAT GEN_TAC)
  THEN STRIP_TAC
  THEN  (ASM_REWRITE_TAC []) ]);;

%**************************************************************************%
let CONS_LLEQ_LEFT_TL = prove_thm ( `CONS_LLEQ_LEFT_TL`,
"! (l1:* list) l2.
       ((CONS h l1) LLEQ_LEFT l2) ==> (l1 LLEQ_LEFT (TL l2))",
(REWRITE_TAC [LLEQ_LEFT])
THEN (REPEAT STRIP_TAC)
THENL
[ (IMP_RES_TAC CONS_LLESS_LEFT_TL)
  THEN  ASM_REWRITE_TAC[];
  (POP_ASSUM (\th . ASSUME_TAC (GSYM th)))
  THEN  (ASM_REWRITE_TAC [TL]) ]);;
%**************************************************************************%

let LLESS_LEFT_NULL =  prove_thm ( `LLESS_LEFT_NULL`,
"! (l1:* list) l2.
      l1 LLESS_LEFT l2 ==> ~(NULL l2)",
LIST_INDUCT_TAC
THENL
[ (REWRITE_TAC [LLESS_LEFT;L_EQ_NIL]);
  (REWRITE_TAC [LLESS_LEFT;L_EQ_NIL])
  THEN  (REPEAT STRIP_TAC) ]);;

%**************************************************************************%
let NIL_LLEQ_LEFT = prove_thm ( `NIL_LLEQ_LEFT`,
"! (l:* list).  [] LLEQ_LEFT l",
GEN_TAC
THEN (REWRITE_TAC [LLEQ_LEFT;LLESS_LEFT;NIL_EQ_L])
THEN (ASM_CASES_TAC "(NULL (l:* list))")
THEN ASM_REWRITE_TAC[]);;
%**************************************************************************%
let CONS_LLESS_LEFT_HD = prove_thm ( `CONS_LLESS_LEFT_HD`,
"!h (l1:* list) l2.
   (CONS h l1) LLESS_LEFT l2 ==>
       (h = HD l2)",
(REWRITE_TAC [LLESS_LEFT])
THEN  (REPEAT STRIP_TAC));;
%**************************************************************************%
let NOT_NIL_LLESS_LEFT  =prove_thm ( `NOT_NIL_LLESS_LEFT`,
"!(l:* list).
    ~ [] LLESS_LEFT l ==> (NULL l)",
 (REWRITE_TAC[LLESS_LEFT]));;
%**************************************************************************%
let LLESS_LEFT_APPEND = prove_thm ( `LLESS_LEFT_APPEND`,
"!l (l1:* list) l2.
   (l LLESS_LEFT l1) ==>
          (l LLESS_LEFT (APPEND l1 l2))",
LIST_INDUCT_TAC
THENL
[ (REWRITE_TAC [LLESS_LEFT])
  THEN (REPEAT STRIP_TAC)
  THEN (IMP_RES_TAC APPEND_IS_NULL)
  THEN  RES_TAC;
  (REWRITE_TAC [LLESS_LEFT])
  THEN (REPEAT GEN_TAC) THEN STRIP_TAC
  THEN RES_TAC
  THEN (IMP_RES_TAC IMP_APPEND_NOT_NULL)
  THEN (IMP_RES_TAC HD_APPEND_NULL)
  THEN (IMP_RES_TAC TL_APPEND_NULL)
  THEN  (ASM_REWRITE_TAC []) ]);;


%**************************************************************************%
let CONS_LLESS_LEFT_APPEND_HD = prove_thm ( `CONS_LLESS_LEFT_APPEND_HD`,
"! l (l1:* list) l2.
       ~(NULL l1) /\
       (CONS h l) LLESS_LEFT (APPEND l1 l2) ==> (h = (HD l1))",
(REPEAT STRIP_TAC)
THEN (IMP_RES_TAC CONS_LLESS_LEFT_HD)
THEN (IMP_RES_TAC HD_APPEND_NULL)
THEN ASM_REWRITE_TAC []);;
%**************************************************************************%
let NOT_LLESS_LEFT_TL =  prove_thm (`NOT_LLESS_LEFT_TL`,
"!(l1:* list) l2 h.
   (~ ((CONS h l1) LLESS_LEFT l2) /\
   (h = HD l2) /\
   ~ (NULL l2)) ==>
        (~ (l1 LLESS_LEFT (TL l2)))",
(REWRITE_TAC [LLESS_LEFT])
THEN (REPEAT STRIP_TAC)
THEN   RES_TAC);;

%**************************************************************************%
let LLESS_LEFT_CONS =  prove_thm ( `LLESS_LEFT_CONS`,
"!(l1:* list) l2 h.
   ((TL l1) LLESS_LEFT l2) /\
   (h = HD l1) /\
   ~ (NULL l1) ==>
         (l1 LLESS_LEFT (CONS h l2))",
LIST_INDUCT_TAC
THENL
[ (REWRITE_TAC [NULL]);
  (REWRITE_TAC [NULL;HD;TL;LLESS_LEFT])
  THEN (REPEAT GEN_TAC) THEN STRIP_TAC
  THEN  (ASM_REWRITE_TAC []) ]);;

%**************************************************************************%
% New proof by PC April 1993 %

let LLESS_LEFT_APPEND_LLEQ_LEFT = prove_thm( `LLESS_LEFT_APPEND_LLEQ_LEFT`,
"!l (l1:* list) l2.
   ~ (l LLESS_LEFT l1) /\
   (l LLESS_LEFT (APPEND l1 l2)) ==>
        (l1 LLEQ_LEFT l)",

(REWRITE_TAC [LLEQ_LEFT])
THEN LIST_INDUCT_TAC
THENL
[ (REPEAT STRIP_TAC)
  THEN (IMP_RES_TAC NOT_NIL_LLESS_LEFT)
  THEN  (ASM_REWRITE_TAC[L_EQ_NIL]);

  (REPEAT STRIP_TAC) THEN
  let asm1 = ASSUME "~(CONS h l) LLESS_LEFT (l1:* list)" in
  let asm2 = ASSUME "(CONS h l) LLESS_LEFT (APPEND (l1:* list) l2)" in
  let ind_asm = ASSUME "!(l1:* list) l2.
        ~l LLESS_LEFT l1 /\ l LLESS_LEFT (APPEND l1 l2) ==>
        l1 LLESS_LEFT l \/ (l1 = l)" in
  let th1 = MATCH_MP CONS_LLESS_LEFT_TL asm2 in
  (ASM_CASES_TAC "NULL (l2:* list)")
  THENL
  [ (ASSUME_TAC
      (REWRITE_RULE
        [REWRITE_RULE[NULL_EQ_EMPTY] (ASSUME"NULL (l2:* list)");APPEND_NIL]
         asm2))
    THEN  RES_TAC;

    (ASM_CASES_TAC"(l1:* list) = []")
    THENL
    [ (ASM_REWRITE_TAC [LLESS_LEFT;NULL]);
      let notl1nil = ASSUME "~((l1:* list) = [])" in
      let th2 = REWRITE_RULE [L_EQ_NIL] notl1nil in
      let th3 = MATCH_MP CONS_LLESS_LEFT_APPEND_HD (CONJ th2 asm2) in
      let th4 = MATCH_MP NOT_LLESS_LEFT_TL (CONJ  asm1 (CONJ th3 th2)) in
      let th5 = REWRITE_RULE [MATCH_MP TL_APPEND_NULL th2] th1 in
      let th6 = MATCH_MP ind_asm (CONJ th4 th5)  in
      DISJ_CASES_TAC th6
      THENL
      [ let asm3 = ASSUME "(TL l1) LLESS_LEFT (l:* list)" in
        ASM_REWRITE_TAC [MATCH_MP LLESS_LEFT_CONS (CONJ  asm3 (CONJ th3 th2))];

       let asm4 = ASSUME "(TL l1) = (l:* list)" in
        REWRITE_TAC[REWRITE_RULE [asm4;GSYM th3] (MATCH_MP CONS th2)]
 ] ] ] ]);;

%**************************************************************************%
let LLESS_LEFT_CONS_HD = prove_thm( `LLESS_LEFT_CONS_HD`,
"! (l:* list) h t.
   l LLESS_LEFT (CONS h t) /\  ~(NULL l) ==> (h = HD l)",
LIST_INDUCT_TAC
THENL
[ (REWRITE_TAC [NULL]);
  (REWRITE_TAC [LLESS_LEFT;TL;HD])
  THEN (REPEAT STRIP_TAC)
  THEN  (ASM_REWRITE_TAC []) ]);;

%**************************************************************************%
let LLESS_LEFT_CONS_TL_LLESS_LEFT = prove_thm( `LLESS_LEFT_CONS_TL_LLESS_LEFT`,
"! (l:* list) h t.
   l LLESS_LEFT (CONS h t) /\  ~(NULL l) ==> ((TL l) LLESS_LEFT t)",
LIST_INDUCT_TAC
THENL
[ (REWRITE_TAC [NULL]);
  (REWRITE_TAC [LLESS_LEFT;TL;HD])
  THEN  (REPEAT STRIP_TAC) ]);;
%**************************************************************************%
let NOT_LLESS_LEFT_CONS_NOT_TL_LLESS_LEFT = prove_thm(
 `NOT_LLESS_LEFT_CONS_NOT_TL_LLESS_LEFT`,
"! (l:* list) h t.
   ~(l LLESS_LEFT (CONS h t)) /\  ~(NULL l) /\ (h = HD l)  ==> ~((TL l) LLESS_LEFT t)",
LIST_INDUCT_TAC
THENL
[ (REWRITE_TAC [NULL]);
  (REWRITE_TAC [LLESS_LEFT;TL;HD])
  THEN (REPEAT STRIP_TAC)
  THEN RES_TAC
  THEN POP_ASSUM (\th. CONTR_TAC
         (REWRITE_RULE
           [NULL;(ASSUME "h' = (h:*)")] th)) ]);;

%**************************************************************************%
let NOT_LLESS_LEFT_NOT_NULL  = prove_thm (`NOT_LLESS_LEFT_NOT_NULL`,
"! (l1:* list) l2.
     ~(l1 LLESS_LEFT l2) /\ ~(NULL l2) ==> ~(NULL l1)",
LIST_INDUCT_TAC
THENL
[ (REWRITE_TAC [LLESS_LEFT])
  THEN  TAUT_TAC;
  (REWRITE_TAC [NULL]) ]);;
%**************************************************************************%
let NOT_LLESS_LEFT_CONS_NOT_NULL  =  prove_thm (`NOT_LLESS_LEFT_CONS_NOT_NULL`,
"! (l:* list) h t.
     ~(l LLESS_LEFT (CONS h t)) ==> ~(NULL l)",
 (REWRITE_TAC[
     (REWRITE_RULE[NULL]
      (SPECL["l1: * list"; "(CONS h t): * list"] NOT_LLESS_LEFT_NOT_NULL))]));;
%**************************************************************************%
let LLESS_LEFT_SINGLE_NULL = prove_thm(`LLESS_LEFT_SINGLE_NULL`,
"!(l:* list) h. l LLESS_LEFT [h] = (NULL l)",
 LIST_INDUCT_TAC THENL
 [(REWRITE_TAC[LLESS_LEFT;NULL]);
  (REWRITE_TAC[LLESS_LEFT;TL;NOT_LLESS_LEFT_NIL;NULL])]);;
%**************************************************************************%


let LLESS_LEFT_EXISTS_APPEND = prove_thm(`LLESS_LEFT_EXISTS_APPEND`,
"!(l1:* list) l2. l1 LLESS_LEFT l2 ==> ?l. (l2 = APPEND l1 l)",

  LIST_INDUCT_TAC THENL
[
 (REPEAT STRIP_TAC) THEN
 (EXISTS_TAC "l2 : * list") THEN
 (REWRITE_TAC[APPEND_CLAUSES]);

 (REPEAT STRIP_TAC) THEN
 (IMP_RES_TAC CONS_LLESS_LEFT_HD) THEN
 (IMP_RES_TAC CONS_LLESS_LEFT_TL) THEN
 RES_TAC THEN
 (EXISTS_TAC "l : * list") THEN
 (POP_ASSUM (\th. ASSUME_TAC (GSYM th))) THEN
 (IMP_RES_TAC LLESS_LEFT_NULL) THEN
 (IMP_RES_TAC CONS) THEN
 (ASM_REWRITE_TAC[APPEND_CLAUSES])]);;





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   AUTHOR:       Paul Curzon                                                %
%   ORGANIZATION: University of Cambridge                                    %
%   DATE:         Sept 1991                                                  %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




%----------------------------------------------------------------------------%
% Tests for final sublists                                                 %
%----------------------------------------------------------------------------%


%----------------------------------------------------------------------------%
% DEFINITIONS                                                                %
%----------------------------------------------------------------------------%


let LLESS_RIGHT = new_recursive_definition true SNOC_Axiom `LLESS_RIGHT` 
      "(LLESS_RIGHT ([]:* list) l = ~(NULL l)) /\
       (LLESS_RIGHT (SNOC a rest)  l =
             ~(NULL l) /\ (a = LAST l) /\ (LLESS_RIGHT rest (BUTLAST l)))";;

%**************************************************************************%

let LLEQ_RIGHT = new_infix_definition(`LLEQ_RIGHT`,
      "LLEQ_RIGHT (l1:* list) l2 = (l1 LLESS_RIGHT l2) \/ (l1 = l2)");;

%**************************************************************************%

%----------------------------------------------------------------------------%
% THEOREMS                                                                   %
%----------------------------------------------------------------------------%

%**************************************************************************%
let NOT_LLESS_RIGHT_NIL = prove_thm(`NOT_LLESS_RIGHT_NIL`,
"!l:(*)list . ~ (l LLESS_RIGHT [])",
SNOC_INDUCT_TAC
THENL
[ (REWRITE_TAC [LLESS_RIGHT;NULL]);
  (ASM_REWRITE_TAC [LLESS_RIGHT;NULL]) ]);;
%**************************************************************************%
let LLESS_RIGHT_LENGTH1_NULL = prove_thm (`LLESS_RIGHT_LENGTH1_NULL`,
"!(l1:(*)list) l2.
     l2 LLESS_RIGHT l1 /\
     (LENGTH l1 = 1) ==>
          (NULL l2)",
GEN_TAC
THEN SNOC_INDUCT_TAC
THENL
[ (REWRITE_TAC [NULL]);
  (REWRITE_TAC [LLESS_RIGHT;LENGTH_NIL])
  THEN (REPEAT STRIP_TAC)
  THEN (POP_ASSUM (\th . ASSUME_TAC  (REWRITE_RULE [LENGTH_NIL] th)))
  THEN (IMP_RES_TAC BUTLAST_NIL)
  THEN
   (CONTR_TAC
     (REWRITE_RULE
       [ASSUME "BUTLAST (l1:(*)list) = []";NOT_LLESS_RIGHT_NIL]
         (ASSUME "l2 LLESS_RIGHT (BUTLAST (l1:(*)list))")))]);;

%**************************************************************************%
let SNOC_LLESS_RIGHT_BUTLAST = prove_thm (`SNOC_LLESS_RIGHT_BUTLAST`,
"! (l1:* list) l2.
       ((SNOC h l1) LLESS_RIGHT l2) ==> (l1 LLESS_RIGHT (BUTLAST l2))",
SNOC_INDUCT_TAC
THENL
[ (REWRITE_TAC [LLESS_RIGHT])
  THEN  (REPEAT STRIP_TAC);
  (REWRITE_TAC [LLESS_RIGHT])
  THEN (REPEAT GEN_TAC) THEN STRIP_TAC
  THEN  (ASM_REWRITE_TAC []) ]);;

%**************************************************************************%

let SNOC_LLEQ_RIGHT_BUTLAST = prove_thm ( `SNOC_LLEQ_RIGHT_BUTLAST`,
"! (l1:* list) l2.
       ((SNOC h l1) LLEQ_RIGHT l2) ==> (l1 LLEQ_RIGHT (BUTLAST l2))",
(REWRITE_TAC [LLEQ_RIGHT])
THEN (REPEAT STRIP_TAC)
THENL
[ (IMP_RES_TAC SNOC_LLESS_RIGHT_BUTLAST)
  THEN  ASM_REWRITE_TAC[];
  (POP_ASSUM (\th. ASSUME_TAC (GSYM th)))
  THEN  (ASM_REWRITE_TAC [BUTLAST]) ]);;
%**************************************************************************%

let LLESS_RIGHT_NULL =  prove_thm ( `LLESS_RIGHT_NULL`,
"! (l1:* list) l2.
      l1 LLESS_RIGHT l2 ==> ~(NULL l2)",
SNOC_INDUCT_TAC
THENL
[ (REWRITE_TAC [LLESS_RIGHT;L_EQ_NIL]);
  (REWRITE_TAC [LLESS_RIGHT;L_EQ_NIL])
  THEN  (REPEAT STRIP_TAC) ]);;

%**************************************************************************%
let NIL_LLEQ_RIGHT = prove_thm ( `NIL_LLEQ_RIGHT`,
"! (l:* list).  [] LLEQ_RIGHT l",
GEN_TAC
THEN (REWRITE_TAC [LLEQ_RIGHT;LLESS_RIGHT;NIL_EQ_L])
THEN (ASM_CASES_TAC "(NULL (l:* list))")
THEN ASM_REWRITE_TAC[]);;
%**************************************************************************%
let SNOC_LLESS_RIGHT_LAST = prove_thm ( `SNOC_LLESS_RIGHT_LAST`,
"!h (l1:* list) l2.
   (SNOC h l1) LLESS_RIGHT l2 ==>
       (h = LAST l2)",
(REWRITE_TAC [LLESS_RIGHT])
THEN  (REPEAT STRIP_TAC));;
%**************************************************************************%
let NOT_NIL_LLESS_RIGHT  =prove_thm ( `NOT_NIL_LLESS_RIGHT`,
"!(l:* list).
    ~ [] LLESS_RIGHT l ==> (NULL l)",
 (REWRITE_TAC[LLESS_RIGHT]));;
%**************************************************************************%
let LLESS_RIGHT_APPEND = prove_thm ( `LLESS_RIGHT_APPEND`,
"!l (l1:* list) l2.
   (l LLESS_RIGHT l2) ==>
          (l LLESS_RIGHT (APPEND l1 l2))",
SNOC_INDUCT_TAC
THENL
[ (REWRITE_TAC [LLESS_RIGHT])
  THEN (REPEAT STRIP_TAC)
  THEN (IMP_RES_TAC  APPEND_IS_NULL)
  THEN  RES_TAC;
  (REWRITE_TAC [LLESS_RIGHT])
  THEN (REPEAT GEN_TAC) THEN STRIP_TAC
  THEN RES_TAC
  THEN (IMP_RES_TAC IMP_APPEND_NOT_NULL)
  THEN (IMP_RES_TAC LAST_APPEND)
  THEN (IMP_RES_TAC BUTLAST_APPEND)
  THEN  (ASM_REWRITE_TAC []) ]);;

%**************************************************************************%
let SNOC_LLESS_RIGHT_APPEND_LAST = prove_thm ( `SNOC_LLESS_RIGHT_APPEND_LAST`,
"! l (l1:* list) l2.
       ~(NULL l2) /\
       (SNOC h l) LLESS_RIGHT (APPEND l1 l2) ==> (h = (LAST l2))",
(REPEAT STRIP_TAC)
THEN (IMP_RES_TAC SNOC_LLESS_RIGHT_LAST)
THEN (IMP_RES_TAC LAST_APPEND)
THEN ASM_REWRITE_TAC []);;
%**************************************************************************%
let NOT_LLESS_RIGHT_BUTLAST =  prove_thm (`NOT_LLESS_RIGHT_BUTLAST`,
"!(l1:* list) l2 h.
   (~ ((SNOC h l1) LLESS_RIGHT l2) /\
   (h = LAST l2) /\
   ~ (NULL l2)) ==>
        (~ (l1 LLESS_RIGHT (BUTLAST l2)))",
(REWRITE_TAC [LLESS_RIGHT])
THEN (REPEAT STRIP_TAC)
THEN   RES_TAC);;

%**************************************************************************%
let LLESS_RIGHT_SNOC =  prove_thm ( `LLESS_RIGHT_SNOC`,
"!(l1:* list) l2 h.
   ((BUTLAST l1) LLESS_RIGHT l2) /\
   (h = LAST l1) /\
   ~ (NULL l1) ==>
         (l1 LLESS_RIGHT (SNOC h l2))",
SNOC_INDUCT_TAC
THENL
[ (REWRITE_TAC [NULL]);
  (REWRITE_TAC [SNOC_NOT_NULL;LAST;BUTLAST;LLESS_RIGHT])
  THEN (REPEAT GEN_TAC) THEN STRIP_TAC
  THEN  (ASM_REWRITE_TAC []) ]);;

%**************************************************************************%
% Proof modified by PC April 1993 %
let LLESS_RIGHT_APPEND_LLEQ_RIGHT = prove_thm( `LLESS_RIGHT_APPEND_LLEQ_RIGHT`,
"!l (l1:* list) l2.
   ~ (l LLESS_RIGHT l2) /\
   (l LLESS_RIGHT (APPEND l1 l2)) ==>
        (l2 LLEQ_RIGHT l)",

(REWRITE_TAC [LLEQ_RIGHT])
THEN SNOC_INDUCT_TAC
THENL
[ (REPEAT STRIP_TAC)
  THEN (IMP_RES_TAC NOT_NIL_LLESS_RIGHT)
  THEN  (ASM_REWRITE_TAC[L_EQ_NIL]);

  let asm1 = ASSUME "~(SNOC h l) LLESS_RIGHT (l2:* list)" in
  let asm2 = ASSUME "(SNOC h l) LLESS_RIGHT (APPEND l1 (l2:* list))" in
  let ind_asm = ASSUME "!l1  (l2:* list).
        ~l LLESS_RIGHT l2 /\ l LLESS_RIGHT (APPEND l1 l2) ==>
        l2 LLESS_RIGHT l \/ (l2 = l)" in
  (REPEAT STRIP_TAC) THEN
  let th1 = MATCH_MP SNOC_LLESS_RIGHT_BUTLAST asm2 in
  (ASM_CASES_TAC "NULL (l1:* list)")
  THENL
  [ (ASSUME_TAC
      (REWRITE_RULE
        [REWRITE_RULE[NULL_EQ_EMPTY] (ASSUME"NULL (l1:* list)");APPEND_NIL]
         asm2))
    THEN  RES_TAC;

    (ASM_CASES_TAC"(l2:* list) = []")
    THENL
    [ (ASM_REWRITE_TAC [LLESS_RIGHT;SNOC_NOT_NULL]);

      let notl2nil = ASSUME "~((l2:* list) = [])" in
      let th2 = REWRITE_RULE [L_EQ_NIL] notl2nil in
      let th3 = MATCH_MP SNOC_LLESS_RIGHT_APPEND_LAST (CONJ th2 asm2) in
      let th4 = MATCH_MP NOT_LLESS_RIGHT_BUTLAST (CONJ  asm1 (CONJ th3 th2)) in
      let th5 = REWRITE_RULE [MATCH_MP BUTLAST_APPEND th2] th1 in
      let th6 = MATCH_MP ind_asm (CONJ th4 th5)  in

      (DISJ_CASES_TAC th6)
      THENL
      [ let asm3 = ASSUME  "(BUTLAST l2) LLESS_RIGHT (l:* list)" in
        ASM_REWRITE_TAC
            [MATCH_MP LLESS_RIGHT_SNOC (CONJ  asm3 (CONJ th3 th2))];

       let asm4 = ASSUME "BUTLAST l2 = (l:* list)" in
        REWRITE_TAC[REWRITE_RULE [asm4;GSYM th3] (MATCH_MP SNOC th2)]
 ] ] ] ]);;

%**************************************************************************%
let LLESS_RIGHT_SNOC_LAST = prove_thm( `LLESS_RIGHT_SNOC_LAST`,
"! (l:* list) h t.
   l LLESS_RIGHT (SNOC h t) /\  ~(NULL l) ==> (h = LAST l)",
SNOC_INDUCT_TAC
THENL
[ (REWRITE_TAC [NULL]);
  (REWRITE_TAC [LLESS_RIGHT;BUTLAST;LAST])
  THEN (REPEAT STRIP_TAC)
  THEN  (ASM_REWRITE_TAC []) ]);;

%**************************************************************************%
let LLESS_RIGHT_SNOC_BUTLAST_LLESS_RIGHT = prove_thm( `LLESS_RIGHT_SNOC_BUTLAST_LLESS_RIGHT`,
"! (l:* list) h t.
   l LLESS_RIGHT (SNOC h t) /\  ~(NULL l) ==> ((BUTLAST l) LLESS_RIGHT t)",
SNOC_INDUCT_TAC
THENL
[ (REWRITE_TAC [NULL]);
  (REWRITE_TAC [LLESS_RIGHT;BUTLAST;LAST])
  THEN  (REPEAT STRIP_TAC) ]);;
%**************************************************************************%
let NOT_LLESS_RIGHT_SNOC_NOT_BUTLAST_LLESS_RIGHT = prove_thm( `NOT_LLESS_RIGHT_SNOC_NOT_BUTLAST_LLESS_RIGHT`,
"! (l:* list) h t.
   ~(l LLESS_RIGHT (SNOC h t)) /\  ~(NULL l) /\ (h = LAST l)  ==> ~((BUTLAST l) LLESS_RIGHT t)",
SNOC_INDUCT_TAC
THENL
[ (REWRITE_TAC [NULL]);
  (REWRITE_TAC [LLESS_RIGHT;BUTLAST;LAST])
  THEN (REPEAT STRIP_TAC)
  THEN RES_TAC
  THEN POP_ASSUM (\th. CONTR_TAC
         (REWRITE_RULE
           [SNOC_NOT_NULL;(ASSUME "h' = (h:*)")] th))  ]);;

%**************************************************************************%
let NOT_LLESS_RIGHT_NOT_NULL  = prove_thm (`NOT_LLESS_RIGHT_NOT_NULL`,
"! (l1:* list) l2.
     ~(l1 LLESS_RIGHT l2) /\ ~(NULL l2) ==> ~(NULL l1)",
SNOC_INDUCT_TAC
THENL
[ (REWRITE_TAC [LLESS_RIGHT])
  THEN  TAUT_TAC;
  (REWRITE_TAC [SNOC_NOT_NULL]) ]);;
%**************************************************************************%
let NOT_LLESS_RIGHT_SNOC_NOT_NULL  =  prove_thm (`NOT_LLESS_RIGHT_SNOC_NOT_NULL`,
"! (l:* list) h t.
     ~(l LLESS_RIGHT (SNOC h t)) ==> ~(NULL l)",
 (REWRITE_TAC[
     (REWRITE_RULE[SNOC_NOT_NULL]
       (SPECL["l2: * list"; "(SNOC h t): * list"] NOT_LLESS_RIGHT_NOT_NULL))]));;
%**************************************************************************%
let LLESS_RIGHT_SINGLE_NULL = prove_thm(`LLESS_RIGHT_SINGLE_NULL`,
"!(l:* list) h. l LLESS_RIGHT [h] = (NULL l)",
 SNOC_INDUCT_TAC THENL
 [(REWRITE_TAC[LLESS_RIGHT;NULL]);
  (REWRITE_TAC[LAST_EL;BUTLAST_EL;LLESS_RIGHT;BUTLAST;NOT_LLESS_RIGHT_NIL;SNOC_NOT_NULL;NULL])]);;
%**************************************************************************%

let LLESS_RIGHT_EXISTS_APPEND = prove_thm(`LLESS_RIGHT_EXISTS_APPEND`,
"!(l1:* list) l2. l1 LLESS_RIGHT l2 ==> ?l. (l2 = APPEND l l1)",

  SNOC_INDUCT_TAC THENL
[
 (REPEAT STRIP_TAC) THEN
 (EXISTS_TAC "l2 : * list") THEN
 (REWRITE_TAC[APPEND_CLAUSES]);

 (REPEAT STRIP_TAC) THEN
 (IMP_RES_TAC SNOC_LLESS_RIGHT_LAST) THEN
 (IMP_RES_TAC SNOC_LLESS_RIGHT_BUTLAST) THEN
 RES_TAC THEN
 (EXISTS_TAC "l : * list") THEN
 (POP_ASSUM (\th . ASSUME_TAC (GSYM th))) THEN
 (IMP_RES_TAC LLESS_RIGHT_NULL) THEN
 (IMP_RES_TAC SNOC) THEN
 (ASM_REWRITE_TAC[APPEND_CLAUSES])]);;



%----------------------------------------------------------------------------%




close_theory();;

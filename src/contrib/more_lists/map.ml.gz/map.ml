
%****************************************************************************%
% FILE          : map.ml                                                     %
% DESCRIPTION   : Extra theorems about map and every                         %
%                                                                            %
% READS LIBRARY : more_arithmetic                                            %
%                                                                            %
% AUTHOR        : R.J.Boulton                                                %
% DATE          : 1990                                                       %
%                                                                            %
% LAST MODIFIED : R.J.Boulton                                                %
% DATE          : 27th February 1991                                         %
%****************************************************************************%
% LAST MODIFIED : P Curzon         for more_lists library                    %
% DATE          : June1991                                                   %
%****************************************************************************%
%                                                                            %
%      These theorems were taken from Richard Boltons more_lists theory      %
%      Extras by Paul Curzon                                                 %
%                                                                            %
%****************************************************************************%
% LAST MODIFIED : P Curzon/Wai Wong                                          %
% DATE          : April 1993                                                 %
%****************************************************************************%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%  DEPENDANCIES :                                                            %
%                                                                            %
%     Library arithmetic          for arithmetic theorems                    %
%     snoc                        for SNOC theorems                          %
%     append                      for APPEND theorems                        %
%                                                                            %
%****************************************************************************%
system `rm -f map.th`;;

new_theory `map`;;
			     
%< WW use load_library instead of loadf
set_search_path (search_path()  @ 
		 [`../more_arithmetic/`;`../auxiliary/`]);;

loadf `more_arithmetic`;;
%PC 13/8/92 more_arithmetic is no longer dependent on auxiliary. snoc2 is %
loadf `auxiliary`;;
>%
load_library `more_arithmetic`;;
load_library `auxiliary`;;
new_parent `append`;;
new_parent `tail`;;

loadf`list_tactics`;;

autoload_defs_and_thms `snoc`;;
autoload_defs_and_thms `tail`;;
autoload_defs_and_thms `append`;;

%----------------------------------------------------------------------------%
% MAP_MAP_o = |- !f g l. MAP f(MAP g l) = MAP(f o g)l                        %
%----------------------------------------------------------------------------%

let MAP_o = theorem `tydefs` `MAP_o`;;

let MAP_MAP_o =
 prove_thm
  (`MAP_MAP_o`,
   "!(f:**->***) (g:*->**) l. MAP f (MAP g l) = MAP (f o g) l",
   REPEAT GEN_TAC THEN
   REWRITE_TAC [MAP_o;o_DEF] THEN
   BETA_TAC THEN
   REFL_TAC);;

%----------------------------------------------------------------------------%
% EVERY_MAP = |- !f P l. EVERY P(MAP f l) = EVERY(P o f)l                    %
%----------------------------------------------------------------------------%

let EVERY_MAP =
 prove_thm
  (`EVERY_MAP`,
   "!(f:*->**) P l. EVERY P (MAP f l) = EVERY (P o f) l",
   GEN_TAC THEN
   GEN_TAC THEN
   LIST_INDUCT_TAC THENL
   [REWRITE_TAC [EVERY_DEF;MAP];
    REWRITE_TAC [EVERY_DEF;MAP] THEN
    ASM_REWRITE_TAC [o_DEF] THEN
    BETA_TAC THEN
    REWRITE_TAC []]);;

%----------------------------------------------------------------------------%
% HD_MAP = |- !f l. ~NULL l ==> (HD(MAP f l) = f(HD l))                      %
%----------------------------------------------------------------------------%

let HD_MAP =
 prove_thm
  (`HD_MAP`,
   "!(f:*->**) l. ~(NULL l) ==> (HD (MAP f l) = f (HD l))",
   GEN_TAC THEN
   LIST_INDUCT_TAC THENL
   [REWRITE_TAC [NULL];
    REWRITE_TAC [MAP;HD]]);;

%----------------------------------------------------------------------------%
% TL_MAP = |- !f l. ~NULL l ==> (TL(MAP f l) = MAP f(TL l))                  %
%----------------------------------------------------------------------------%

let TL_MAP =
 prove_thm
  (`TL_MAP`,
   "!(f:*->**) l. ~(NULL l) ==> (TL (MAP f l) = MAP f (TL l))",
   GEN_TAC THEN
   LIST_INDUCT_TAC THENL
   [REWRITE_TAC [NULL];
    REWRITE_TAC [MAP;TL]]);;


%----------------------------------------------------------------------------%
% EVERY_APPEND =                                                             %
% |- !l1 l2 P. EVERY P(APPEND l1 l2) = EVERY P l1 /\ EVERY P l2              %
%----------------------------------------------------------------------------%

let EVERY_APPEND =
 prove_thm
  (`EVERY_APPEND`,
   "!(l1:(*)list) l2 P.
       (EVERY P (APPEND l1 l2)) = ((EVERY P l1) /\ (EVERY P l2))",
   LIST_INDUCT_TAC THEN
   REWRITE_TAC [APPEND;EVERY_DEF] THEN
   ASM_REWRITE_TAC [] THEN
   REWRITE_TAC [CONJ_ASSOC]);;



%----------------------------------------------------------------------------%
% ITLIST : (*->**->**) -> (*)list -> ** -> **                                %
%                                                                            %
% ITLIST f [y1;...;yn] x = f y1 (f y2 (...(f yn x)...))                      %
%----------------------------------------------------------------------------%

let ITLIST =
 new_list_rec_definition
  (`ITLIST`,
   "(ITLIST (f:*->**->**) NIL x = x) /\
    (ITLIST f (CONS hd tl) x = f hd (ITLIST f tl x))");;

%----------------------------------------------------------------------------%
% ITLIST_MAP_EQ =                                                            %
% |- !f g l. ITLIST $/\(MAP(\x. f x = g x)l)T = (MAP f l = MAP g l)          %
%----------------------------------------------------------------------------%

let ITLIST_MAP_EQ =
 prove_thm
  (`ITLIST_MAP_EQ`,
   "!(f:*->**) g l. ITLIST $/\ (MAP (\x. f x = g x) l) T =
                    (MAP f l = MAP g l)",
   GEN_TAC THEN
   GEN_TAC THEN
   LIST_INDUCT_TAC THEN
   REWRITE_TAC [MAP;ITLIST] THEN
   BETA_TAC THEN
   ASM_REWRITE_TAC [CONS_11]);;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   AUTHOR:       Paul Curzon                                                %
%   ORGANIZATION: U Cambridge CL                                             %
%   DATE:         June 1991                                                  %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


let MAP_SNOC  = prove_thm(`MAP_SNOC`,
"!(f:*->**) h (t:* list).
       MAP f(SNOC h t) = SNOC(f h)(MAP f t)",

 (REWRITE_TAC [SNOC_APPEND_CONS;MAP_APPEND;MAP]));;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   AUTHOR:       John Harrison                                              %
%   ORGANIZATION: U Cambridge CL                                             %
%   DATE:         July 1991                                                  %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%--------------------------------------------------------------------------%
% ITLIST_MAP = |- !l. ITLIST p(MAP f l) = ITLIST (\x y. p (f x) y) l       %
%--------------------------------------------------------------------------%

let ITLIST_MAP =
  let ty = ":(* -> (** -> **)) -> ((*)list -> (** -> **))" in
  PROVE
   ("!l:(*)list. (ITLIST:^ty) p (MAP f l) = ITLIST (\x y. p (f x) y) l",
    CONV_TAC (ONCE_DEPTH_CONV FUN_EQ_CONV) THEN LIST_INDUCT_TAC THEN
    ASM_REWRITE_TAC[MAP; ITLIST] THEN BETA_TAC THEN REWRITE_TAC[]);;

%--------------------------------------------------------------------------%
% Following theorems added by Wai Wong on 2/4/1993			   %
%--------------------------------------------------------------------------%


let MAP2_SNOC = prove_thm(`MAP2_SNOC`,
    "!(f:*->**->***) h1 h2 l1 l2. (LENGTH l1 = LENGTH l2) ==>
     (MAP2 f(SNOC h1 l1)(SNOC h2 l2) = SNOC(f h1 h2)(MAP2 f l1 l2))",
    GEN_TAC THEN GEN_TAC THEN GEN_TAC THEN EQ_LENGTH_INDUCT_TAC THENL[
      REWRITE_TAC[SNOC_DEF;MAP2];
      REWRITE_TAC[LENGTH;INV_SUC_EQ;SNOC_DEF;MAP2;CONS_11]
      THEN REPEAT STRIP_TAC THEN RES_TAC]);;
% *************************************************************************%
% PC April 1993 %
let NULL_MAP = prove_thm(`NULL_MAP`,
  "!(f:* -> **) (l:* list) .  NULL (MAP f l) = NULL l",

 GEN_TAC THEN LIST_INDUCT_TAC THEN
 (REWRITE_TAC [MAP;NULL])
);;

let TAIL_MAP = prove_thm(`TAIL_MAP`,
  "!(f:* -> **) (l:* list) . TAIL (MAP f l) = MAP f (TAIL l)",

 GEN_TAC THEN LIST_INDUCT_TAC THEN
 (REWRITE_TAC [MAP;TAIL])
);;


% Added by WW 12 May 1993 %
let EVERY_SNOC = prove_thm(`EVERY_SNOC`,
    "!P (h:*) l. EVERY P (SNOC h l) = EVERY P l /\ P h",
    GEN_TAC THEN GEN_TAC THEN LIST_INDUCT_TAC
    THEN ASM_REWRITE_TAC[SNOC_DEF;EVERY_DEF;CONJ_ASSOC]);;

close_theory();;


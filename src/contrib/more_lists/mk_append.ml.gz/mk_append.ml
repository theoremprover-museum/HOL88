%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   FILE:         mk_append.ml                                               %
%   EDITOR:       Paul Curzon                                                %
%   ORGANIZATION: U Cambridge CL                                             %
%   DATE:         June 1991                                                  %
%   DESCRIPTION:  Make the theory of APPEND                                  %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
system `rm -f append.th`;;

new_theory `append`;;
			     
%< WW 2/4/93  Use load_library instead of loadf 
set_search_path (search_path()  @ 
		 [`../more_arithmetic/`;`../auxiliary/`]);; 

loadf `more_arithmetic`;;
%PC 13/8/92 more_arithmetic is no longer dependent on auxiliary. snoc2 is %
loadf `auxiliary`;;
>% 

load_library `more_arithmetic`;;
load_library `auxiliary`;;

new_parent `snoc`;;

autoload_defs_and_thms  `general_lists`;;
autoload_defs_and_thms `snoc`;;


loadt `append`;;
loadt `clauses`;;
loadt `append_snoc`;;

close_theory();;
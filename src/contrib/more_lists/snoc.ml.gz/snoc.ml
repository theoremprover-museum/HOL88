%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   FILE:         snoc.ml                                                    %
%   EDITOR:       Paul Curzon                                                %
%   ORGANIZATION: U Cambridge CL                                             %
%   DATE:         5-4-1991                                                   %
%   DESCRIPTION:  Additional theorems about SNOC, REVERSE and APPEND t [h]   %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%*********************************  HISTORY  ********************************%
%									     %
%   This file is part of the list theory by				     %
%      Paul Loewenstein							     %
%   Additional theorems from 						     %
%      Paul Curzon							     %
%  have been added to allow conversions to the APPEND t [h] form	     %
%                                                                            %
%  The names of some theorems have been changed from the original sources    %
%                                                                            %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%****************************************************************************%
%                                                                            %
%  DEPENDANCIES :                                                            %
%                                                                            %
%****************************************************************************%



%****************************************************************************%
% AUTHOR        : Paul Loewenstein                      		     %
% DATE		: 2 June 1989	                                             %
%                                                                            %
%****************************************************************************%


% CONS, HD and TL from other end of list %

let SNOC_DEF = new_list_rec_definition (`SNOC_DEF`,
 "(SNOC (d:*) ([]:(*)list) = [d]) /\
  (SNOC d (CONS h t) = CONS h (SNOC d t))");;

let REVERSE_DEF = new_list_rec_definition (`REVERSE_DEF`,
 "(REVERSE [] = []) /\
  (REVERSE (CONS (h:*) l) = SNOC h (REVERSE l))");;


%****************************************************************************%

let REVERSE_SNOC =
 TAC_PROOF (([],"!(d:*) l. REVERSE (SNOC d l) = CONS d (REVERSE l)"),
  GEN_TAC THEN LIST_INDUCT_TAC THEN
  ASM_REWRITE_TAC[SNOC_DEF;REVERSE_DEF]);;



let REVERSE_REVERSE = prove_thm (`REVERSE_REVERSE`,
 "!l:(*)list. REVERSE (REVERSE l) = l",
 LIST_INDUCT_TAC THEN
 ASM_REWRITE_TAC[REVERSE_DEF;REVERSE_SNOC]);;



let REVERSE_CLAUSES = save_thm (`REVERSE_CLAUSES`,
 CONJ (GEN_ALL (CONJUNCT1 REVERSE_DEF)) (CONJ (GEN_ALL (CONJUNCT2 REVERSE_DEF))
 (CONJ REVERSE_SNOC REVERSE_REVERSE)));;


let forall_REVERSE = TAC_PROOF 
    (([], "!P. (!t:(*)list. P(REVERSE t)) = (!t. P t)"),
 GEN_TAC THEN
 EQ_TAC THEN
 DISCH_TAC THEN
 GEN_TAC THEN
 POP_ASSUM (ACCEPT_TAC o (REWRITE_RULE[REVERSE_REVERSE] o (SPEC "REVERSE t:(*)list")))
);;



let f_REVERSE_lemma = TAC_PROOF (([],
 "!f1 f2. ((\x. (f1:(*)list->**) (REVERSE x)) = (\x. f2 (REVERSE x))) = (f1 = f2)"),
 REPEAT GEN_TAC THEN EQ_TAC THEN DISCH_TAC THENL
 [
  POP_ASSUM (\x.ACCEPT_TAC (EXT (REWRITE_RULE[REVERSE_REVERSE]
   (GEN "x:(*)list" (BETA_RULE (AP_THM x "REVERSE (x:(*)list)"))))))
 ;
  ASM_REWRITE_TAC[]
 ]);;




let SNOC_Axiom = prove_thm(`SNOC_Axiom`,
 "!(x:**) (f:** -> (* -> ((*)list -> **))).
  ?! fn. (fn[] = x) /\ (!h t. fn(SNOC h t) = f(fn t)h t)",
 REPEAT GEN_TAC THEN
 CONV_TAC EXISTS_UNIQUE_CONV THEN
 STRIP_ASSUME_TAC (CONV_RULE (EXISTS_UNIQUE_CONV)
   (REWRITE_RULE[REVERSE_REVERSE] (BETA_RULE (SPECL
 ["x:**";"(\ft h t. f ft h (REVERSE t)):** -> (* -> ((*)list -> **))"]
 (PURE_ONCE_REWRITE_RULE [SYM (CONJUNCT1 REVERSE_DEF);PURE_ONCE_REWRITE_RULE
 [SYM (SPEC_ALL REVERSE_SNOC)] (BETA_RULE
 (SPEC "\t:(*)list.fn(CONS h t) = (f:** -> (* -> ((*)list -> **)))(fn t)h t"
 (CONV_RULE (ONCE_DEPTH_CONV SYM_CONV) forall_REVERSE)))] list_Axiom))))) THEN
 CONJ_TAC THENL
 [
  EXISTS_TAC "(fn:(*)list->**) o REVERSE" THEN
  REWRITE_TAC[o_DEF] THEN BETA_TAC THEN
  ASM_REWRITE_TAC[]
 ;
  REPEAT GEN_TAC THEN
  POP_ASSUM (ACCEPT_TAC o SPEC_ALL o REWRITE_RULE[REVERSE_REVERSE;f_REVERSE_lemma] o
   BETA_RULE o REWRITE_RULE[o_DEF] o
   SPECL ["(fn' o REVERSE):(*)list->**"; "(fn'' o REVERSE):(*)list->**"])
 ]);;

let SNOC_INDUCT = save_thm(`SNOC_INDUCT`, prove_induction_thm SNOC_Axiom);;
let SNOC_CASES =  save_thm(`SNOC_CASES`,prove_cases_thm SNOC_INDUCT);;


let SNOC_NULL_CASES = save_thm(`SNOC_NULL_CASES`,
  (REWRITE_RULE[L_EQ_NIL] SNOC_CASES));;


let SNOC_11 =  save_thm(`SNOC_11`,prove_constructors_one_one SNOC_Axiom);;
let SNOC_ONE_ONE = save_thm(`SNOC_ONE_ONE`,
     GEN_ALL (fst (EQ_IMP_RULE (SPEC_ALL (SNOC_11)))));;
let NOT_NIL_SNOC = save_thm(`NOT_NIL_SNOC`,
       prove_constructors_distinct SNOC_Axiom);;
let NOT_SNOC_NIL = save_thm(`NOT_SNOC_NIL`,
      CONV_RULE (ONCE_DEPTH_CONV SYM_CONV) NOT_NIL_SNOC);;


let SNOC_NOT_NULL = prove_thm(`SNOC_NOT_NULL`,
  "! (d:*) l. ~NULL (SNOC d l)",
 REPEAT GEN_TAC THEN
 STRUCT_CASES_TAC (SPEC "l:(*)list" list_CASES) THEN
 REWRITE_TAC[SNOC_DEF;NULL]);;



let HD_SNOC =  prove_thm(`HD_SNOC`,
  "!(h:*) t. HD (SNOC h t) = NULL t => h | HD t",
 REPEAT GEN_TAC THEN
 STRUCT_CASES_TAC (SPEC "t:(*)list" list_CASES) THEN
 REWRITE_TAC [NULL;SNOC_DEF;HD]);;




let TL_SNOC =  prove_thm(`TL_SNOC`,
 "!(h:*) t. TL (SNOC h t) = NULL t => [] | SNOC h (TL t)",
 REPEAT GEN_TAC THEN
 STRUCT_CASES_TAC (SPEC "t:(*)list" list_CASES) THEN
 REWRITE_TAC [NULL;SNOC_DEF;TL]);;

%****************************************************************************%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   FILE:         shift.ml                                                   %
%   EDITOR:       Paul Curzon                                                %
%   ORGANIZATION: U Cambridge CL                                             %
%   DATE:         July 1991                                                  %
%   DESCRIPTION:  Shifting and Rotating lists                                %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%****************************************************************************%
%                                                                            %
%  DEPENDANCIES :                                                            %
%                                                                            %
%         library more_arithmetic  for arithmetic theorems                   %
%         snoc                     for last,butlast theorems                 %
%         append                   for append theorems                       %
%         subseq                   for FIRSTN etc theorems                   %
%         last_subseq              for LASTN  theorems                       %
%                                                                            %
%****************************************************************************%

%****************************************************************************%
%                                                                            %
%  HISTORY :                                                                 %
%                                                                            %
%    June 92 PC:                                                             %
%             PAD_LEFT and PAD_RIGHT definitions swapped                     %
%             Theorem ROTATE1_RIGHT --> ROTATE1_RIGHT_SNOC                   %
%             Theorem ROTATE1_LEFT --> ROTATE1_LEFT_CONS                     %
%                                                                            %
%****************************************************************************%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   AUTHOR:       Wim Ploegaerts                                             %
%   ORGANIZATION: Imec vzw.                                                  %
%                 Kapeldreef 75                                              %
%                 3030 Leuven, Belgium                                       %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

system `rm -f shift.th`;;
new_theory `shift`;;

		
load_library `more_arithmetic`;;
%PC 13/8/92 more_arithmetic is no longer dependent on auxiliary. snoc2 is %
load_library `auxiliary`;;

new_parent `last_subseq`;;


autoload_defs_and_thms  `general_lists`;;
autoload_defs_and_thms  `snoc`;;
autoload_defs_and_thms  `append`;;
autoload_defs_and_thms  `subseq`;;
autoload_defs_and_thms  `last_subseq`;;




%----------------------------------------------------------------------------%
%									     %
% "PAD_LEFT x n" adds n copies of element x on the left of a given list	     %
%									     %
%----------------------------------------------------------------------------%
% 
 Name changed from PAD_RIGHT which was counter intuitive 
 PC 23/6/92
%

let PAD_LEFT = new_prim_rec_definition (`PAD_LEFT`,
    "(PAD_LEFT (x:*) 0 (l:* list) = l) /\
     (PAD_LEFT (x:*) (SUC n) l = CONS x (PAD_LEFT x n l))");;

%----------------------------------------------------------------------------%
%									     %
% "PAD_RIGHT x n" adds n copies of element x on the right of a given list    %
%									     %
%----------------------------------------------------------------------------%
% 
 Name changed from PAD_LEFT which was counter intuitive 
 PC 23/6/92
%

let PAD_RIGHT = new_prim_rec_definition (`PAD_RIGHT`,
    "(PAD_RIGHT (x:*) 0 (l:* list) = l) /\
     (PAD_RIGHT  x (SUC n) l = SNOC x (PAD_RIGHT x n l))");;

%<-------------------------------------------------------------------------->%

let LENGTH_PAD_LEFT = prove_thm (`LENGTH_PAD_LEFT`,
  "!l:* list.! n x. LENGTH (PAD_LEFT x n l) = (LENGTH l) + n",
  GEN_TAC THEN INDUCT_TAC THEN 
  ASM_REWRITE_TAC [PAD_LEFT;ADD_CLAUSES;LENGTH_CLAUSES]
);;

%<-------------------------------------------------------------------------->%

let LENGTH_PAD_RIGHT = prove_thm (`LENGTH_PAD_RIGHT`,
  "!l:* list.! n x. LENGTH (PAD_RIGHT x n l) = (LENGTH l) + n",
  GEN_TAC THEN INDUCT_TAC THEN 
  ASM_REWRITE_TAC [PAD_RIGHT;ADD_CLAUSES;LENGTH_CLAUSES]
);;

%<-------------------------------------------------------------------------->%





let ROTATE1_LEFT = new_definition (`ROTATE1_LEFT`,
  "!l:* list. ROTATE1_LEFT l = SNOC (HD l) (TL l)");;

% Name saved as changed from  ROTATE1_LEFT to ROTATE1_LEFT_CONS to avoid clash
  with the definition name
  PC  23/6/92
%
let ROTATE1_LEFT_CONS = prove_thm (`ROTATE1_LEFT_CONS`,
  "!x:*.!l. ROTATE1_LEFT (CONS x l) = SNOC x l",
  REWRITE_TAC [ROTATE1_LEFT;TL;HD]
);;

let LENGTH_ROTATE1_LEFT = prove_thm(
  `LENGTH_ROTATE1_LEFT`,
  "!l:* list. ~(NULL l) ==>
            (LENGTH (ROTATE1_LEFT l) = LENGTH l)",
  REWRITE_TAC [ROTATE1_LEFT;LENGTH_CLAUSES;LENGTH;ADD_CLAUSES] THEN
  INDUCT_THEN list_INDUCT ASSUME_TAC THEN
  REWRITE_TAC [NULL;TL;LENGTH]
);;




let ROTATE1_LEFT_NIL = prove_thm (
  `ROTATE1_LEFT_NIL`,
  "!l:* list. ~(NULL l) ==> ~(NULL (ROTATE1_LEFT l))",
  GEN_TAC THEN 
  DISCH_THEN  \t. 
      MP_TAC t THEN
      REWRITE_TAC [GSYM LENGTH_NULL] THEN
      SUBST1_TAC (SYM (MATCH_MP LENGTH_ROTATE1_LEFT t)) THEN
  DISCH_THEN ACCEPT_TAC
);;


let ROTATE1_RIGHT = new_definition (`ROTATE1_RIGHT`,
  "!l:* list. ROTATE1_RIGHT l = CONS (LAST l) (BUTLAST l)");;

% Name saved as changed from  ROTATE1_RIGHT to ROTATE1_RIGHT_SNOC to avoid
  clash with the definition name
  PC  23/6/92
%
let ROTATE1_RIGHT_SNOC = prove_thm (`ROTATE1_RIGHT_SNOC`,
  "!x:*.!l. ROTATE1_RIGHT (SNOC x l) =  (CONS x l) ",
  REWRITE_TAC [ROTATE1_RIGHT;LAST;BUTLAST]
);;

let LENGTH_ROTATE1_RIGHT = prove_thm(
  `LENGTH_ROTATE1_RIGHT`,
  "!l:* list. ~(NULL l) ==>
            (LENGTH (ROTATE1_RIGHT l) = LENGTH l)",
  REWRITE_TAC [ROTATE1_RIGHT;LENGTH] THEN
  INDUCT_THEN SNOC_INDUCT ASSUME_TAC THEN
  REWRITE_TAC [SNOC_NOT_NULL;BUTLAST;LENGTH_CLAUSES;ADD_CLAUSES;NULL]
);;

let ROTATE1_RIGHT_NIL = prove_thm (
  `ROTATE1_RIGHT_NIL`,
  "!l:* list. ~(NULL l) ==> ~(NULL (ROTATE1_RIGHT l))",
  GEN_TAC THEN 
  DISCH_THEN  \t. 
      MP_TAC t THEN
      REWRITE_TAC [GSYM LENGTH_NULL] THEN
      SUBST1_TAC (SYM (MATCH_MP LENGTH_ROTATE1_RIGHT t)) THEN
  DISCH_THEN ACCEPT_TAC
);;


let ROTATE1_RIGHT_ROTATE1_LEFT = prove_thm (
  `ROTATE1_RIGHT_ROTATE1_LEFT`,
  "!l:* list. ~(NULL l) ==> (ROTATE1_RIGHT (ROTATE1_LEFT l) = l)",
  INDUCT_THEN list_INDUCT ASSUME_TAC THEN
  REWRITE_TAC [NULL;ROTATE1_LEFT;ROTATE1_RIGHT;HD;TL;LAST;BUTLAST]
);;

let ROTATE1_LEFT_ROTATE1_RIGHT = prove_thm (
  `ROTATE1_LEFT_ROTATE1_RIGHT`,
  "!l:* list. ~(NULL l) ==> (ROTATE1_LEFT (ROTATE1_RIGHT l) = l)",
  INDUCT_THEN SNOC_INDUCT ASSUME_TAC THEN
  REWRITE_TAC[SNOC_NOT_NULL;ROTATE1_RIGHT;ROTATE1_LEFT;HD;TL;LAST;BUTLAST;NULL]
);;



let ROTATE_LEFT = new_prim_rec_definition (`ROTATE_LEFT`,		    
   "(ROTATE_LEFT 0 l = l:* list) /\
    (ROTATE_LEFT (SUC n) l = ROTATE1_LEFT (ROTATE_LEFT n l))");;

let ROTATE_RIGHT = new_prim_rec_definition (`ROTATE_RIGHT`,
   "(ROTATE_RIGHT 0 l = l:* list) /\ 
    (ROTATE_RIGHT (SUC n) l = ROTATE1_RIGHT (ROTATE_RIGHT n l))");;


let ROTATE_LEFT_EL = prove_thm (
  `ROTATE_LEFT_EL`,
  "!n x. ROTATE_LEFT n [x] = [x:*]",
  INDUCT_TAC THEN
  ASM_REWRITE_TAC [ROTATE_LEFT;ROTATE1_LEFT;TL;HD;SNOC_DEF]
);;

let ROTATE_RIGHT_EL = prove_thm (
  `ROTATE_RIGHT_EL`,
  "!n x. ROTATE_RIGHT n [x] = [x:*]",
  INDUCT_TAC THEN
  ASM_REWRITE_TAC [ROTATE_RIGHT; ROTATE1_RIGHT;LAST_EL;BUTLAST_CONS;NULL]);;


let ROTATE_LEFT_SUC_CONS = prove_thm (`ROTATE_LEFT_SUC_CONS`,
 "!l:* list. !x n. ROTATE_LEFT (SUC n) (CONS x l) = ROTATE_LEFT n (SNOC x l)",
  REWRITE_TAC [ROTATE_LEFT;ROTATE1_LEFT] THEN GEN_TAC THEN GEN_TAC THEN
  INDUCT_TAC THEN ASM_REWRITE_TAC [ROTATE_LEFT;ROTATE1_LEFT;HD;TL]
);;

let ROTATE_RIGHT_SUC_SNOC = prove_thm (`ROTATE_RIGHT_SUC_SNOC`,
  "!l:* list. !x n. ROTATE_RIGHT (SUC n) (SNOC x l) = ROTATE_RIGHT n (CONS x l)",
  REWRITE_TAC [ROTATE_RIGHT;ROTATE1_RIGHT] THEN GEN_TAC THEN GEN_TAC THEN
  INDUCT_TAC THEN ASM_REWRITE_TAC [ROTATE_RIGHT;ROTATE1_RIGHT;LAST;BUTLAST]
);;


let ROTATE_LEFT_ROTATE1_LEFT = prove_thm (
  `ROTATE_LEFT_ROTATE1_LEFT`,
  "!l n. ~(NULL l) ==> 
             (ROTATE_LEFT (SUC n) l = ROTATE_LEFT n (ROTATE1_LEFT l):* list)",
  INDUCT_THEN list_INDUCT ASSUME_TAC THEN
  REWRITE_TAC [NULL;ROTATE_LEFT_SUC_CONS;ROTATE1_LEFT;HD;TL] 
);;

let ROTATE_RIGHT_ROTATE1_RIGHT = prove_thm (
  `ROTATE_RIGHT_ROTATE1_RIGHT`,
  "!l n. ~(NULL l) ==> 
              (ROTATE_RIGHT (SUC n) l = ROTATE_RIGHT n (ROTATE1_RIGHT l):* list)",
  INDUCT_THEN SNOC_INDUCT ASSUME_TAC THEN
  REWRITE_TAC [NULL;ROTATE_RIGHT_SUC_SNOC;ROTATE1_RIGHT;HD;TL;LAST;BUTLAST] 
);;

let ROTATE_RIGHT_ROTATE_LEFT = prove_thm (
  `ROTATE_RIGHT_ROTATE_LEFT`,
  "!n . !l:* list. ~(NULL l) ==> (ROTATE_RIGHT n (ROTATE_LEFT n l) = l)",
  INDUCT_TAC THENL
 [
  REWRITE_TAC [ROTATE_RIGHT;ROTATE_LEFT]
 ;
  REPEAT STRIP_TAC THEN
  IMP_RES_TAC ROTATE_LEFT_ROTATE1_LEFT THEN
  ASM_REWRITE_TAC [ROTATE_LEFT_ROTATE1_LEFT;ROTATE_RIGHT] THEN
  IMP_RES_TAC ROTATE1_RIGHT_ROTATE1_LEFT THEN
  IMP_RES_TAC ROTATE1_LEFT_NIL THEN 
  RES_TAC THEN
  ASM_REWRITE_TAC []
 ]
);;

let ROTATE_LEFT_ROTATE_RIGHT = prove_thm (
  `ROTATE_LEFT_ROTATE_RIGHT`,
  "!n . !l:* list. ~(NULL l) ==> (ROTATE_LEFT n (ROTATE_RIGHT n l) = l)",
 INDUCT_TAC THENL
 [
  REWRITE_TAC [ROTATE_RIGHT;ROTATE_LEFT]
 ;
  REPEAT STRIP_TAC THEN
  IMP_RES_TAC ROTATE_RIGHT_ROTATE1_RIGHT THEN
  ASM_REWRITE_TAC [ROTATE_RIGHT_ROTATE1_RIGHT;ROTATE_LEFT]  THEN
  IMP_RES_TAC ROTATE1_LEFT_ROTATE1_RIGHT THEN
  IMP_RES_TAC ROTATE1_RIGHT_NIL THEN 
  RES_TAC THEN
  ASM_REWRITE_TAC []
 ]
);;

close_theory();;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   FILE:         el.ml                                                      %
%   EDITOR:       Paul Curzon                                                %
%   ORGANIZATION: U Cambridge CL                                             %
%   DATE:         5-4-1991                                                   %
%   DESCRIPTION:  Additional theorems about EL                               %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%*********************************  HISTORY  ********************************%
%									     %
%   This file contains list theorems and definitions from the following      %
%   sources:  								     %
%      Richard Boulton 							     %
%      Paul Curzon 							     %
%      Wai Wong                                                              %
%      Wim Ploegaerts   (Imec vzw Leuven, Belgium)			     %
%                                                                            %
%  The names of some theorems have been changed from the original sources    %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%****************************************************************************%
%                                                                            %
%  DEPENDANCIES :                                                            %
%                                                                            %
%         library more_arithmetic  for arithmetic theorems                   %
%         general_lists            for list theorems                         %
%         snoc                     for snoc theorems                         %
%                                                                            %
%****************************************************************************%
system `rm -f el.th`;;

new_theory `el`;;

load_library `taut`;;
			     
%< WW use load_library instead of loadf
set_search_path (search_path()  @ 
		 [`../more_arithmetic/`;`../auxiliary/`]);;

loadf `more_arithmetic`;;
%PC 13/8/92 more_arithmetic is no longer dependent on auxiliary. snoc2 is %
loadf `auxiliary`;;
>%
load_library `more_arithmetic`;;
load_library `auxiliary`;;

new_parent `map`;;


autoload_defs_and_thms `snoc`;;
autoload_defs_and_thms `general_lists`;;
autoload_defs_and_thms `append`;;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                          %< theorems about EL >%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



let EL_LENGTH_APPEND = prove_thm (
  `EL_LENGTH_APPEND`,
  "!(l1:(*)list) (l2:(*)list) .
      ~(NULL l2)==> ( EL (LENGTH l1) (APPEND l1 l2) = HD l2)",
  LIST_INDUCT_TAC THEN
  REWRITE_TAC [LENGTH;APPEND;EL;TL;NULL] THEN
  REPEAT STRIP_TAC THEN
  RES_TAC
);;
%<-------------------------------------------------------------------------->%



let EL_HD  = prove_thm (
  `EL_HD`,
  "!l:(*)list . ~(NULL l) ==> (EL 0 l = HD l)",
  LIST_INDUCT_TAC THEN
  REWRITE_TAC [EL;HD;NULL]
);;

%<-------------------------------------------------------------------------->%


let EL_CONS = prove_thm (
  `EL_CONS`,
  "! k l (y:*) . (0 < k) ==> (EL k (CONS y l) = EL (PRE k) l)",
  INDUCT_TAC THEN
  REWRITE_TAC [NOT_LESS_0;EL;TL;PRE] 
);;


%<-------------------------------------------------------------------------->%

let EL_APPEND_2 = prove_thm (
  `EL_APPEND_2`,
  "! (l1:(*)list) l2 k . 
           ((LENGTH l1) <= k) ==> 
               (EL k (APPEND l1 l2) = EL (k - (LENGTH l1)) l2)",
  LIST_INDUCT_TAC THEN
  REWRITE_TAC [LENGTH;APPEND;SUB_0] THEN
  REPEAT GEN_TAC THEN
  RULE_ASSUM_TAC (SPECL ["l2:(*)list";"PRE k"]) THEN
  DISJ_CASES_TAC (CONV_RULE (ONCE_DEPTH_CONV SYM_CONV)
                                 (SPEC "k:num" LESS_0_CASES)) THENL
 [
  FIRST_ASSUM \thm . REWRITE_TAC [thm;GSYM LESS_EQ;NOT_LESS_0]
 ;
  IMP_RES_TAC EL_CONS THEN
  DISCH_TAC THEN
  IMP_RES_TAC SUC_LESS_EQ_PRE THEN
  RES_TAC THEN
  IMP_RES_TAC SUB_SUC_PRE_SUB THEN
  ASM_REWRITE_TAC []
 ]
);;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   AUTHOR:       Paul Curzon                                                %
%   ORGANIZATION: U Cambridge CL                                             %
%   DATE:         5-4-1991                                                   %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


let EL_APPEND_1 = prove_thm(`EL_APPEND_1`,
  "! (l1:* list) l2 k.
      (k < (LENGTH l1)) ==>
           ((EL k (APPEND l1 l2)) = (EL k l1))",

 LIST_INDUCT_TAC THENL
 [
 (REWRITE_TAC[LENGTH;APPEND;EL]) THEN
 (REPEAT STRIP_TAC) THEN
 (IMP_RES_TAC NOT_LESS_0);

 (REWRITE_TAC[LENGTH;APPEND;EL]) THEN
 (GEN_TAC THEN GEN_TAC) THEN
 INDUCT_TAC THENL
  [
   STRIP_TAC THEN
   (REWRITE_TAC[EL;HD]);

   STRIP_TAC THEN
   (REWRITE_TAC[EL;TL]) THEN
   (POP_ASSUM (\th. (ASSUME_TAC (REWRITE_RULE[LESS_MONO_EQ] th)))) THEN
   RES_TAC THEN
   (ASM_REWRITE_TAC[])
]]);;


%<-------------------------------------------------------------------------->%

%*****************************************%
% EXISTS_EL = |-  !n a . ? l . EL n l = a %
%*****************************************%


let EXISTS_EL = prove_thm(
   `EXISTS_EL`,
   "!n (a:*) . ? l . EL n l = a",
 INDUCT_TAC THEN
 GEN_TAC THENL
  [(EXISTS_TAC "[a:*]") THEN
   (REWRITE_TAC [EL;HD]);

   (REWRITE_TAC [EL]) THEN
   (POP_ASSUM ((X_CHOOSE_THEN "(l:* list)" ASSUME_TAC) o SPEC_ALL)) THEN
   (EXISTS_TAC "CONS (b:*) l") THEN
   (ASM_REWRITE_TAC [TL])]);;

%<-------------------------------------------------------------------------->%

%**********************************************************************%
% EL_CONS_SUB1 = |- !n h l. ~(n = 0) ==> (EL n(CONS h l) = EL(n - 1)l) %
%**********************************************************************%

let EL_CONS_SUB1 = prove_thm(
   `EL_CONS_SUB1`,
   "! n (h:*) l . (~(n = 0)) ==>  ((EL n (CONS h l) = (EL (n-1) l)))",
  INDUCT_TAC THEN
  (REWRITE_TAC[EL;TL;SUC_SUB1]));;

%<-------------------------------------------------------------------------->%

let EL_APPEND_EL = prove_thm  ( 
  `EL_APPEND_EL`, 
  "! l (y:*) k. (k < (LENGTH l)) ==> (EL k (APPEND l [y]) = EL k l)",
  LIST_INDUCT_TAC THEN 
  REWRITE_TAC [LENGTH;NOT_LESS_0;APPEND] THEN
%PC 13/8/92 Remove dependency on auxiliary library%
%  (2 TIMES GEN_TAC) THEN%
  (GEN_TAC THEN GEN_TAC) THEN
  INDUCT_TAC THEN
  REWRITE_TAC [EL;HD;TL] THEN
  DISCH_THEN \thm . (ASSUME_TAC (REWRITE_RULE [LESS_MONO_EQ] thm)) THEN
  RES_TAC THEN
  FIRST_ASSUM MATCH_ACCEPT_TAC
);;
%----------------------------------------------------------------------------%
let EL_0_REVERSE = prove_thm (
  `EL_0_REVERSE`,
  "! l:(*)list . ~(NULL l) ==>
               (EL 0 (REVERSE l) = EL (PRE (LENGTH l)) l)",
  LIST_INDUCT_TAC THEN
  REWRITE_TAC [REVERSE;LENGTH;PRE;NULL] THEN
  ASM_CASES_TAC "(l:(*)list) = []" THEN
  FIRST_ASSUM \thm . (REWRITE_TAC [thm;REVERSE;APPEND;LENGTH] ? NO_TAC) THEN
  POP_ASSUM (\th. ASSUME_TAC (REWRITE_RULE[L_EQ_NIL]th)) THEN
  IMP_RES_TAC (CONV_RULE (CONTRAPOS_CONV  THENC
                            (RAND_CONV 
                              (ONCE_DEPTH_CONV SYM_CONV)))
                   (fst (EQ_IMP_RULE (SPEC_ALL LENGTH_NULL)))) THEN
  DISJ_CASES_TAC (SPEC "LENGTH (l:(*)list)" LESS_0_CASES) THEN
  RES_TAC THEN
  IMP_RES_TAC EL_CONS THEN
  FIRST_ASSUM \thm . REWRITE_TAC [thm] THEN
  FIRST_ASSUM \thm . (REWRITE_TAC [SYM thm;EL] ? NO_TAC) THEN
  IMP_RES_TAC (CONV_RULE CONTRAPOS_CONV 
                  (fst (EQ_IMP_RULE (SPEC_ALL REVERSE_NULL)))) THEN
  IMP_RES_TAC HD_APPEND_NULL THEN
  ASM_REWRITE_TAC []
);;
%<-------------------------------------------------------------------------->%
let LENGTH_REVERSE = 
     (CONJUNCT2 (CONJUNCT2 (CONJUNCT2 (CONJUNCT2 LENGTH_CLAUSES))));;

let MATCH_EQ_MP eqth = 
     let match = PART_MATCH (fst o dest_eq) eqth ? failwith `MATCH_MP` 
     in
     \th. EQ_MP (match (concl th)) th;;

let EL_REVERSE = prove_thm (
  `EL_REVERSE`,
  "!(l:(*)list) k . (k < (PRE (LENGTH l))) ==> 
                  (EL k (REVERSE l) = EL ((PRE (LENGTH l)) - k) l)",
  LIST_INDUCT_TAC THEN
  REPEAT GEN_TAC THEN
  REWRITE_TAC [LENGTH;PRE;NOT_LESS_0;REVERSE] THEN
  DISCH_THEN \thm . (ASSUME_TAC thm THEN
                     REWRITE_TAC
                          [MATCH_MP EL_APPEND_EL 
                             (ONCE_REWRITE_RULE [GSYM LENGTH_REVERSE] thm)])
  THEN
  DISJ_CASES_TAC (CONV_RULE (ONCE_DEPTH_CONV SYM_CONV)
                                 (SPEC "k:num" LESS_0_CASES)) 
  THENL
 [
  IMP_RES_TAC M_LESS_0_LESS THEN
  IMP_RES_TAC EL_CONS THEN
  ASM_REWRITE_TAC [SUB_0] THEN
  IMP_RES_TAC LENGTH_NOT_NULL THEN
  IMP_RES_TAC EL_0_REVERSE 
 ;
  IMP_RES_TAC SUB_LESS_0 THEN % name change from LESS_SUB_IMP - pc %
  IMP_RES_TAC EL_CONS THEN
  ASM_REWRITE_TAC [PRE_SUB] THEN
  IMP_RES_TAC LESS_TRANS THEN
  UNDISCH_TAC "k < LENGTH (l:(*)list)" THEN
  DISCH_THEN (\thm . STRIP_ASSUME_TAC (
       REWRITE_RULE [LESS_OR_EQ] (MATCH_MP LESS_OR thm))) THEN
  IMP_RES_TAC SUC_LESS_PRE THEN
  RES_TAC THEN
  UNDISCH_TAC "0 < LENGTH (l:(*)list)" THEN
  DISCH_THEN \thm . 
        FIRST_ASSUM \thm' . (REWRITE_TAC [SUB_EQUAL_0; 
% PC 25/8/92 BUGFIX                                             %
%                      SUBST_MATCH                              %
%                              (SYM (MATCH_MP PRE_SUC_EQ thm))  %
                     ONCE_REWRITE_RULE[
                              GSYM (MATCH_MP PRE_SUC_EQ thm)]
                               thm' ] ? NO_TAC) THEN
        ACCEPT_TAC (
          SYM (REWRITE_RULE [REVERSE_CLAUSES;LENGTH_REVERSE]
                (MATCH_MP EL_0_REVERSE
                    (ONCE_REWRITE_RULE [GSYM REVERSE_NULL] 
                        (MATCH_EQ_MP LENGTH_NOT_NULL thm)))))
 ]
);;

%<-------------------------------------------------------------------------->%
let EL_SNOC = prove_thm  ( 
  `EL_SNOC`, 
  "! l (y:*) k. (k < (LENGTH l)) ==> (EL k (SNOC y l) = EL k l)",
(REWRITE_TAC[SNOC_APPEND_CONS;EL_APPEND_EL]));;

%<-------------------------------------------------------------------------->%

let LAST_EL_LENGTH = prove_thm (
  `LAST_EL_LENGTH`,
  "!l:(*)list . ~(NULL l) ==> (LAST l = EL (PRE (LENGTH l)) l)",
  GEN_TAC THEN
  DISCH_THEN 
       \thm . SUBST_TAC [SYM (MATCH_MP APPEND_BUTLAST_LAST thm)] THEN
  REWRITE_TAC [LAST1;LENGTH_APPEND;LENGTH;ADD_CLAUSES;PRE;HD;
               MATCH_MP EL_LENGTH_APPEND
                         (SPECL ["LAST l :*";"[]:(*)list"] (CONJUNCT2 NULL))]
);;
%<-------------------------------------------------------------------------->%


%By RJB: Moved from the theory map by PC May 1993 %
%----------------------------------------------------------------------------%
% EL_MAP = |- !f l n. n < (LENGTH l) ==> (EL n(MAP f l) = f(EL n l))         %
%----------------------------------------------------------------------------%

let EL_MAP =
 prove_thm
  (`EL_MAP`,
   "!(f:*->**) l n. (n < LENGTH l) ==> (EL n (MAP f l) = f (EL n l))",
   GEN_TAC THEN
   LIST_INDUCT_TAC THENL
   [REWRITE_TAC [LENGTH;NOT_LESS_0];
    REWRITE_TAC [LENGTH;MAP] THEN
    GEN_TAC THEN
    INDUCT_TAC THENL
    [REWRITE_TAC [EL;HD];
     REWRITE_TAC [LESS_MONO_EQ;EL;TL] THEN
     STRIP_TAC THEN
     RES_TAC]]);;





%----------------------------------------------------------------------------%
% EL1 : num -> (*)list -> *                                                  %
%                                                                            %
% EL1 i [x1;...;xn] = xi or some `undefined' value if i < 1 or i > n.        %
%----------------------------------------------------------------------------%

let EL1 =
 new_prim_rec_definition
  (`EL1`,
   "EL1 (SUC n) (l:(*)list) = EL n l");;




%----------------------------------------------------------------------------%
% EL1_SUC_CONS = |- !n h l. 0 < n ==> (EL1(SUC n)(CONS h l) = EL1 n l)       %
%----------------------------------------------------------------------------%



let EL1_SUC_CONS =
 prove_thm
  (`EL1_SUC_CONS`,
   "!n (h:*) l. (0 < n) ==> (EL1 (SUC n) (CONS h l) = EL1 n l)",
   INDUCT_TAC THENL
   [REWRITE_TAC [NOT_LESS_0];
    REWRITE_TAC [EL1;EL;TL]]);;



%----------------------------------------------------------------------------%
% EL1_HD = |- !l. ~NULL l ==> (EL1 1 l = HD l)                               %
%----------------------------------------------------------------------------%

let EL1_HD =
 prove_thm
  (`EL1_HD`,
   "!(l:(*)list). (~(NULL l)) ==> (EL1 1 l = (HD l))",
   LIST_INDUCT_TAC THENL
   [REWRITE_TAC [NULL];
    REWRITE_TAC [num_CONV "1";EL1;EL;HD]]);;

%----------------------------------------------------------------------------%
% MAP_EL1_SUC_CONS =                                                         %
% |- !l l' h'.                                                               %
%     EVERY(\n. 0 < n)l ==>                                                  %
%     (MAP(\n. EL1(SUC n)(CONS h' l'))l = MAP(\n. EL1 n l')l)                %
%----------------------------------------------------------------------------%

let MAP_EL1_SUC_CONS =
 prove_thm
  (`MAP_EL1_SUC_CONS`,
   "!l l' (h':*).
     (EVERY (\n. 0 < n) l) ==>
     ((MAP (\n. EL1 (SUC n) (CONS h' l')) l) = (MAP (\n. EL1 n l') l))",
   LIST_INDUCT_TAC THEN
   REWRITE_TAC [MAP] THEN
   REWRITE_TAC [EVERY_DEF] THEN
   REPEAT STRIP_TAC THEN
   RES_TAC THEN
   ASM_REWRITE_TAC [] THEN
   BETA_TAC THEN
   ASSUM_LIST
    (\thl. EVERY (mapfilter (ASSUME_TAC o
                             (CONV_RULE BETA_CONV)) thl)) THEN
   IMP_RES_THEN (\th. REWRITE_TAC [th]) EL1_SUC_CONS);;


%----------------------------------------------------------------------------%
% EL_REPLICATE = |- !x n m. m < n ==> (EL m(REPLICATE n x) = x)              %
%----------------------------------------------------------------------------%

let EL_REPLICATE =
 prove_thm
  (`EL_REPLICATE`,
   "!(x:*) n m. (m < n) ==> (EL m (REPLICATE n x) = x)",
   GEN_TAC THEN
   INDUCT_TAC THENL
   [REWRITE_TAC [NOT_LESS_0];
    REWRITE_TAC [REPLICATE] THEN
    INDUCT_TAC THENL
    [REWRITE_TAC [EL;HD];
     REWRITE_TAC [EL;TL] THEN
     REWRITE_TAC [LESS_MONO_EQ] THEN
     STRIP_TAC THEN
     RES_THEN ACCEPT_TAC]]);;

%----------------------------------------------------------------------------%
% Following theorem added by Wai Wong on 2/4/1993			     %
%----------------------------------------------------------------------------%

let EL_BUTLAST = prove_thm(`EL_BUTLAST`,
    "!l:* list. !x. ~(NULL l) ==>
     (SUC x) < (LENGTH l) ==>  (EL x (BUTLAST l) = EL x l)",
    REPEAT GEN_TAC THEN DISCH_TAC
    THEN IMP_RES_THEN (\t.SUBST_OCCS_TAC [[3],(SYM t)]) APPEND_BUTLAST_LAST
    THEN DISCH_TAC THEN IMP_RES_THEN MP_TAC SUC_LESS_PRE
    THEN IMP_RES_THEN (\t.SUBST1_TAC (SYM t)) LENGTH_BUTLAST
    THEN DISCH_TAC THEN IMP_RES_TAC EL_APPEND_1
    THEN ASM_REWRITE_TAC[]);;

let MAP_EL = prove_thm(`MAP_EL`,
    "!(f:*->**) l n. n < (LENGTH l) ==> (MAP f [EL n l] = [f (EL n l)])",
    GEN_TAC THEN LIST_INDUCT_TAC
    THEN REWRITE_TAC[LENGTH;EL;MAP;LESS_THM;NOT_LESS_0]);;

let EL_MAP2 = prove_thm(`EL_MAP2`,
    "!(f:*->**->***) l l' n. (LENGTH l = LENGTH l') ==>
      (n < (LENGTH l)) \/ (n < (LENGTH l')) ==>
     (EL n (MAP2 f l l') = f (EL n l) (EL n l'))",
    GEN_TAC THEN LIST_INDUCT_TAC THENL[
      PURE_REWRITE_TAC[LENGTH] THEN REPEAT GEN_TAC
      THEN DISCH_THEN (\t. SUBST1_TAC (SYM t)) THEN REWRITE_TAC[NOT_LESS_0];
      GEN_TAC THEN LIST_INDUCT_TAC THENL[
        REWRITE_TAC[LENGTH;NOT_SUC];
        REWRITE_TAC[LENGTH;INV_SUC_EQ] THEN GEN_TAC THEN INDUCT_TAC THENL[
          REWRITE_TAC[EL;MAP2;HD];
          REWRITE_TAC[EL;MAP2;TL;LESS_MONO_EQ]
    	  THEN FIRST_ASSUM MATCH_ACCEPT_TAC]]]);;

let MAP2_EL = prove_thm(`MAP2_EL`,
    "!(f:*->**->***) l l' n. (LENGTH l = LENGTH l') ==>
      (n < (LENGTH l) \/ (n < (LENGTH l'))) ==>
     (MAP2 f [EL n l] [EL n l'] = [f (EL n l) (EL n l')])",
    GEN_TAC THEN LIST_INDUCT_TAC THENL[
      PURE_REWRITE_TAC[LENGTH] THEN REPEAT GEN_TAC
      THEN DISCH_THEN (\t. SUBST1_TAC (SYM t)) THEN REWRITE_TAC[NOT_LESS_0];
      GEN_TAC THEN LIST_INDUCT_TAC THENL[
        REWRITE_TAC[LENGTH;NOT_SUC];
        REWRITE_TAC[LENGTH;INV_SUC_EQ] THEN GEN_TAC THEN INDUCT_TAC THENL[
          REWRITE_TAC[EL;MAP2;HD];
          REWRITE_TAC[EL;MAP2;TL;LESS_MONO_EQ]
    	  THEN DISCH_TAC THEN RES_TAC]]]);;

close_theory ();;

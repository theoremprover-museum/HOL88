
%****************************************************************************%
% FILE          : unappend.ml                                                %
% DESCRIPTION   : Unappend an initial sublist                                %
%                                                                            %
% READS LIBRARY : more_arithmetic                                            %
%                                                                            %
% AUTHOR        : P. Curzon                                                  %
% DATE          : April 1991                                                 %
%                                                                            %
%****************************************************************************%
%                                                                            %
%  DEPENDANCIES :                                                            %
%                                                                            %
%         library more_arithmetic  for arithmetic theorems                   %
%         general_lists            for general list theorems                 %
%         member                   for LLESS LLEQ  theorems                  %
%                                                                            %
%****************************************************************************%
system `rm -f unappend.th`;;

new_theory `unappend`;;


load_library `more_arithmetic`;;
%PC 13/8/92 more_arithmetic is no longer dependent on auxiliary. snoc2 is %
load_library `auxiliary`;;

new_parent `member`;;

autoload_defs_and_thms `general_lists`;; 
autoload_defs_and_thms `member`;;
autoload_defs_and_thms `append`;;
autoload_defs_and_thms `last_subseq`;;
autoload_defs_and_thms `subseq`;;
autoload_defs_and_thms `snoc`;;

let SNOC_INDUCT_TAC = INDUCT_THEN SNOC_INDUCT ASSUME_TAC;;



%----------------------------------------------------------------------------%
% DEFINITIONS                                                                %
%----------------------------------------------------------------------------%

let EXISTS_UNAPPEND_LEFT = prove_thm (`EXISTS_UNAPPEND_LEFT`,
  "?f: (* list)->(* list)->(* list). (!l1 l2. ((f l1 (APPEND l1 l2)) = l2))",

 (EXISTS_TAC "\(l1:* list).\(l2:* list). (NTL (LENGTH l1) l2)") THEN
 BETA_TAC THEN
 (ACCEPT_TAC NTL_LENGTH_APPEND));;



%----------------------------------------------------------------------------%
% "!l1 l2. UNAPPEND_LEFT l1 (APPEND l1 l2) = l2"                            %
%----------------------------------------------------------------------------%

let UNAPPEND_LEFT = new_specification `UNAPPEND_LEFT` [`constant`, `UNAPPEND_LEFT`]
     EXISTS_UNAPPEND_LEFT;;

%----------------------------------------------------------------------------%
% THEOREMS                                                                   %
%----------------------------------------------------------------------------%

%----------------------------------------------------------------------------%
%   |- !l. UNAPPEND_LEFT[]l = l                                             %
%----------------------------------------------------------------------------%

let UNAPPEND_LEFT_NIL = save_thm (`UNAPPEND_LEFT_NIL`,
   GEN_ALL (REWRITE_RULE[APPEND](SPECL ["[]:* list";"l:* list"] UNAPPEND_LEFT)));;

let UNAPPEND_LEFT_CONS = prove_thm (`UNAPPEND_LEFT_CONS`,
"!h l1 (l2: * list). l1 LLESS_LEFT l2 ==> 
                       (UNAPPEND_LEFT(CONS h l1) (CONS h l2) =  UNAPPEND_LEFT l1 l2)",

 (REPEAT STRIP_TAC) THEN
 (IMP_RES_TAC LLESS_LEFT_EXISTS_APPEND) THEN
 (ASM_REWRITE_TAC[CONJUNCT2(GSYM APPEND);UNAPPEND_LEFT]));;


%----------------------------------------------------------------------------%
%   |- !l. UNAPPEND_LEFT l l = []                                           %
%----------------------------------------------------------------------------%


let UNAPPEND_LEFT_EQ_NIL = save_thm ( `UNAPPEND_LEFT_EQ_NIL`,
      GEN_ALL (REWRITE_RULE[APPEND_NIL]
      (SPECL ["l:* list";"[]:* list"] UNAPPEND_LEFT)));;


%**************************************************************************%

let LLEQ_LEFT_UNAPPEND_LEFT_CONS = prove_thm (`LLEQ_LEFT_UNAPPEND_LEFT_CONS`,
"!h l1 (l2: * list). l1 LLEQ_LEFT l2 ==> 
                       (UNAPPEND_LEFT(CONS h l1) (CONS h l2) =  UNAPPEND_LEFT l1 l2)",

 (REWRITE_TAC [LLEQ_LEFT]) THEN
 (REPEAT STRIP_TAC) THENL
[
 (IMP_RES_TAC UNAPPEND_LEFT_CONS) THEN
 ASM_REWRITE_TAC[];

 (ASM_REWRITE_TAC[UNAPPEND_LEFT_EQ_NIL])]);;

%**************************************************************************%
let NULL_UNAPPEND_LEFT = save_thm ( `NULL_UNAPPEND_LEFT`,
 REWRITE_RULE[L_EQ_NIL] UNAPPEND_LEFT_EQ_NIL);;

%**************************************************************************%
let LLESS_LEFT_APPEND_UNAPPEND_LEFT = prove_thm ( `LLESS_LEFT_APPEND_UNAPPEND_LEFT`,
"! (l1:* list) l2.
  (l1 LLESS_LEFT l2) ==>
     (l2 = (APPEND l1 (UNAPPEND_LEFT l1 l2)))",
 (REPEAT STRIP_TAC) THEN
 (IMP_RES_TAC LLESS_LEFT_EXISTS_APPEND) THEN
 (ASM_REWRITE_TAC[UNAPPEND_LEFT]));;

%**************************************************************************%
let LLEQ_LEFT_APPEND_UNAPPEND_LEFT = prove_thm ( `LLEQ_LEFT_APPEND_UNAPPEND_LEFT`,
"! (l1:* list) l2.
  (l1 LLEQ_LEFT l2) ==>
     (l2 = (APPEND l1 (UNAPPEND_LEFT l1 l2)))",
(REWRITE_TAC [LLEQ_LEFT])
THEN (REPEAT STRIP_TAC)
THENL
[ (IMP_RES_TAC LLESS_LEFT_APPEND_UNAPPEND_LEFT);
  (ASM_REWRITE_TAC [UNAPPEND_LEFT_EQ_NIL;APPEND_NIL]) ]);;


%**************************************************************************%
let LLESS_LEFT_APPEND_UNAPPEND_LEFT_LLESS_LEFT =
  prove_thm ( `LLESS_LEFT_APPEND_UNAPPEND_LEFT_LLESS_LEFT`,
"!(l1:* list) l2 l.
   ~ (l LLESS_LEFT l1) /\
   (l LLESS_LEFT (APPEND l1 l2)) ==>
        ((UNAPPEND_LEFT l1 l) LLESS_LEFT l2)",
LIST_INDUCT_TAC
THENL
[ (REWRITE_TAC [UNAPPEND_LEFT_NIL;APPEND])
  THEN  (REPEAT STRIP_TAC);

  (REWRITE_TAC [APPEND])
  THEN (REPEAT STRIP_TAC) THEN
  let asm1 = ASSUME "~l LLESS_LEFT (CONS h l1: * list)" in
  let asm2 = ASSUME "l LLESS_LEFT (CONS h(APPEND l1 l2: * list))" in
  let ind_asm = ASSUME
      "!l2 l.
        ~l LLESS_LEFT l1 /\ l LLESS_LEFT (APPEND l1 l2: * list) ==>
        (UNAPPEND_LEFT l1 l) LLESS_LEFT l2" in
  let th1 = MATCH_MP NOT_LLESS_LEFT_CONS_NOT_NULL asm1 in
  let th2 = MATCH_MP LLESS_LEFT_CONS_HD (CONJ asm2 th1) in
  let th3 = MATCH_MP NOT_LLESS_LEFT_CONS_NOT_TL_LLESS_LEFT
                 (CONJ asm1 (CONJ th1 th2)) in
  let th4 = MATCH_MP LLESS_LEFT_CONS_TL_LLESS_LEFT (CONJ asm2 th1) in
  let th5 = MATCH_MP ind_asm (CONJ th3 th4) in
  let th6 = MATCH_MP  LLESS_LEFT_APPEND_LLEQ_LEFT (CONJ th3 th4) in
  let th7 = SPEC "HD l:*" (MATCH_MP  LLEQ_LEFT_UNAPPEND_LEFT_CONS th6) in
  let th8 = MATCH_MP CONS th1 in
  (REWRITE_TAC [REWRITE_RULE [th8;GSYM th2] th7;th5]) ]);;

%< ------------------------------------------------------------------- >%
let APPEND_UNAPPEND_LEFT_ID = prove_thm ( `APPEND_UNAPPEND_LEFT_ID`,
"!l:* list. l = APPEND l (UNAPPEND_LEFT l l)",
 (REWRITE_TAC [UNAPPEND_LEFT_EQ_NIL;APPEND_NIL]));;

%< ------------------------------------------------------------------- >%

%----------------------------------------------------------------------------%
% DEFINITIONS                                                                %
%----------------------------------------------------------------------------%

let EXISTS_UNAPPEND_RIGHT = prove_thm (`EXISTS_UNAPPEND_RIGHT`,
  "?f: (* list)->(* list)->(* list). (!l1 l2. ((f l2 (APPEND l1 l2)) = l1))",

 (EXISTS_TAC "\(l1:* list).\(l2:* list). (NBUTLAST (LENGTH l1) l2)") THEN
 BETA_TAC THEN
 (REWRITE_TAC[APPEND_NIL;NBUTLAST_LENGTH_APPEND]));;



%----------------------------------------------------------------------------%
% "!l1 l2. UNAPPEND_RIGHT l2 (APPEND l1 l2) = l1"                                 %
%----------------------------------------------------------------------------%

let UNAPPEND_RIGHT = new_specification `UNAPPEND_RIGHT` [`constant`, `UNAPPEND_RIGHT`]
     EXISTS_UNAPPEND_RIGHT;;

%----------------------------------------------------------------------------%
% THEOREMS                                                                   %
%----------------------------------------------------------------------------%

%----------------------------------------------------------------------------%
%   |- !l. UNAPPEND_RIGHT[]l = l                                              %
%----------------------------------------------------------------------------%

let UNAPPEND_RIGHT_NIL = save_thm (`UNAPPEND_RIGHT_NIL`,
   GEN_ALL (REWRITE_RULE[APPEND_NIL](SPECL ["l:* list";"[]:* list"] UNAPPEND_RIGHT)));;


let UNAPPEND_RIGHT_SNOC = prove_thm (`UNAPPEND_RIGHT_SNOC`,
"!h l1 (l2: * list). l1 LLESS_RIGHT l2 ==> 
                       (UNAPPEND_RIGHT(SNOC h l1) (SNOC h l2) =  UNAPPEND_RIGHT l1 l2)",

 (REPEAT STRIP_TAC) THEN
 (IMP_RES_TAC LLESS_RIGHT_EXISTS_APPEND) THEN
 (ASM_REWRITE_TAC[CONJUNCT2(CONJUNCT2(CONJUNCT2(GSYM APPEND_CLAUSES)));
                  UNAPPEND_RIGHT]));;


%----------------------------------------------------------------------------%
%   |- !l. UNAPPEND_RIGHT l l = []                                            %
%----------------------------------------------------------------------------%


let UNAPPEND_RIGHT_EQ_NIL = save_thm ( `UNAPPEND_RIGHT_EQ_NIL`,
      GEN_ALL (REWRITE_RULE[APPEND]
      (SPECL ["[]:* list";"l:* list"] UNAPPEND_RIGHT)));;


%**************************************************************************%

let LLEQ_RIGHT_UNAPPEND_RIGHT_SNOC = prove_thm (`LLEQ_RIGHT_UNAPPEND_RIGHT_SNOC`,
"!h l1 (l2: * list). l1 LLEQ_RIGHT l2 ==> 
                       (UNAPPEND_RIGHT(SNOC h l1) (SNOC h l2) =  UNAPPEND_RIGHT l1 l2)",

 (REWRITE_TAC [LLEQ_RIGHT]) THEN
 (REPEAT STRIP_TAC) THENL
[
 (IMP_RES_TAC UNAPPEND_RIGHT_SNOC) THEN
 ASM_REWRITE_TAC[];

 (ASM_REWRITE_TAC[UNAPPEND_RIGHT_EQ_NIL])]);;

%**************************************************************************%
let NULL_UNAPPEND_RIGHT = save_thm ( `NULL_UNAPPEND_RIGHT`,
 REWRITE_RULE[L_EQ_NIL] UNAPPEND_RIGHT_EQ_NIL);;

%**************************************************************************%

let LLESS_RIGHT_APPEND_UNAPPEND_RIGHT = prove_thm ( `LLESS_RIGHT_APPEND_UNAPPEND_RIGHT`,
"! (l1:* list) l2.
  (l1 LLESS_RIGHT l2) ==>
     (l2 = (APPEND (UNAPPEND_RIGHT l1 l2) l1))",
 (REPEAT STRIP_TAC) THEN
 (IMP_RES_TAC LLESS_RIGHT_EXISTS_APPEND) THEN
 (ASM_REWRITE_TAC[UNAPPEND_RIGHT]));;

%**************************************************************************%
let LLEQ_RIGHT_APPEND_UNAPPEND_RIGHT = prove_thm ( `LLEQ_RIGHT_APPEND_UNAPPEND_RIGHT`,
"! (l1:* list) l2.
  (l1 LLEQ_RIGHT l2) ==>
     (l2 = (APPEND (UNAPPEND_RIGHT l1 l2) l1))",
(REWRITE_TAC [LLEQ_RIGHT])
THEN (REPEAT STRIP_TAC)
THENL
[ (IMP_RES_TAC LLESS_RIGHT_APPEND_UNAPPEND_RIGHT);
  (ASM_REWRITE_TAC [UNAPPEND_RIGHT_EQ_NIL;APPEND_NIL]) ]);;


%**************************************************************************%
let LLESS_RIGHT_APPEND_UNAPPEND_RIGHT_LLESS_RIGHT =
  prove_thm ( `LLESS_RIGHT_APPEND_UNAPPEND_RIGHT_LLESS_RIGHT`,
"!(l1:* list) l2 l.
   ~ (l LLESS_RIGHT l2) /\
   (l LLESS_RIGHT (APPEND l1 l2)) ==>
        ((UNAPPEND_RIGHT l2 l) LLESS_RIGHT l1)",
GEN_TAC THEN SNOC_INDUCT_TAC
THENL
[ (REWRITE_TAC [UNAPPEND_RIGHT_NIL;APPEND_NIL])
  THEN  (REPEAT STRIP_TAC) THEN RES_TAC;

  (REWRITE_TAC [APPEND_CLAUSES]) THEN
  (REPEAT STRIP_TAC) THEN
  let asm1 = ASSUME "~l LLESS_RIGHT (SNOC h l2: * list)" in
  let asm2 = ASSUME "l LLESS_RIGHT (SNOC h(APPEND l1 l2: * list))" in
  let ind_asm = ASSUME
      "!l.
        ~l LLESS_RIGHT l2 /\ l LLESS_RIGHT (APPEND l1 l2: * list) ==>
        (UNAPPEND_RIGHT l2 l) LLESS_RIGHT l1" in
  let th1 = MATCH_MP NOT_LLESS_RIGHT_SNOC_NOT_NULL asm1 in
  let th2 = MATCH_MP LLESS_RIGHT_SNOC_LAST (CONJ asm2 th1) in
  let th3 = MATCH_MP NOT_LLESS_RIGHT_SNOC_NOT_BUTLAST_LLESS_RIGHT
                 (CONJ asm1 (CONJ th1 th2)) in
  let th4 = MATCH_MP  LLESS_RIGHT_SNOC_BUTLAST_LLESS_RIGHT (CONJ asm2 th1) in
  let th5 = MATCH_MP ind_asm (CONJ th3 th4) in
  let th6 = MATCH_MP  LLESS_RIGHT_APPEND_LLEQ_RIGHT (CONJ th3 th4) in
  let th7 = SPEC "LAST l:*" (MATCH_MP LLEQ_RIGHT_UNAPPEND_RIGHT_SNOC th6) in
  let th8 = MATCH_MP SNOC th1 in
  (REWRITE_TAC [REWRITE_RULE [th8;GSYM th2] th7;th5]) ]);;


%< ------------------------------------------------------------------- >%
let APPEND_UNAPPEND_RIGHT_ID = prove_thm ( `APPEND_UNAPPEND_RIGHT_ID`,
"!l:* list. l = APPEND l (UNAPPEND_RIGHT l l)",
 (REWRITE_TAC [UNAPPEND_RIGHT_EQ_NIL;APPEND_NIL]));;

%< ------------------------------------------------------------------- >%


let UNAPPEND_LEFT_UNAPPEND_RIGHT = prove_thm (`UNAPPEND_LEFT_UNAPPEND_RIGHT`,
"!l1 (l2:* list).
        l2 LLESS_RIGHT l1 ==>
              (UNAPPEND_LEFT (UNAPPEND_RIGHT l2 l1) l1 = l2)",

 (REPEAT STRIP_TAC) THEN
 (IMP_RES_TAC LLESS_RIGHT_EXISTS_APPEND) THEN
 (ASM_REWRITE_TAC[UNAPPEND_RIGHT;UNAPPEND_LEFT]));;



let UNAPPEND_RIGHT_UNAPPEND_LEFT = prove_thm (`UNAPPEND_RIGHT_UNAPPEND_LEFT`,
"!l1 (l2:* list).
        l2 LLESS_LEFT l1 ==>
              (UNAPPEND_RIGHT (UNAPPEND_LEFT l2 l1) l1 = l2)",

 (REPEAT STRIP_TAC) THEN
 (IMP_RES_TAC LLESS_LEFT_EXISTS_APPEND) THEN
 (ASM_REWRITE_TAC[UNAPPEND_RIGHT;UNAPPEND_LEFT]));;



close_theory();;

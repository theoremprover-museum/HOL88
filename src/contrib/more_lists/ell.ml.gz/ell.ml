%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                            %
%   FILE:         ell.ml                                                     %
%   EDITOR:       Paul Curzon                                                %
%   ORGANIZATION: U Cambridge CL                                             %
%   DATE:         April 1993                                                 %
%   DESCRIPTION:  Indexing from the end of a list                            %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%*********************************  HISTORY  ********************************%
%									     %
%   This file contains list theorems and definitions from the following      %
%   sources:  								     %
%      Wai Wong                                                              %
%                                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%****************************************************************************%
%                                                                            %
%  DEPENDANCIES :                                                            %
%                                                                            %
%                                                                            %
%         library more_arithmetic  for arithmetic theorems                   %
%         snoc                     for snoc theorems                         %
%         el                       for EL theorems                           %
%         last-subseq              for last subsequence theorems             %
%         list_tactics             for general list theorems                 %
%                                                                            %
%****************************************************************************%
system `rm -f ell.th`;;

new_theory `ell`;;

load_library `more_arithmetic`;;
load_library `auxiliary`;;

new_parent `el`;;
new_parent `map`;;


loadf `list_tactics`;;

autoload_defs_and_thms `snoc`;;
autoload_defs_and_thms `el`;;
autoload_defs_and_thms `map`;;


% --------------------------------------------------------------------- %
% Definition of a function 						%
% ELL k l index list elements from the end of the list starting with 0  %
% --------------------------------------------------------------------- %

let ELL = new_prim_rec_definition(`ELL`,
    "(ELL 0 (l:* list) = LAST l) /\
     (ELL (SUC n) l = ELL n (BUTLAST l))");;

let ELL_LAST = prove_thm(`ELL_LAST`,
    "!l:* list. ~(NULL l) ==> (ELL 0 l = LAST l)",
    SNOC_INDUCT_TAC THENL[
      REWRITE_TAC[NULL];
      REPEAT STRIP_TAC THEN REWRITE_TAC[ELL]]);;

let ELL_LENGTH_APPEND = prove_thm(`ELL_LENGTH_APPEND`,
    "!l1:* list. !l2. ~(NULL l1) ==>
     (ELL (LENGTH l2)(APPEND l1 l2) = LAST l1)",
    GEN_TAC THEN SNOC_INDUCT_TAC THENL[
      REWRITE_TAC[ELL;LENGTH;APPEND_NIL];
      REPEAT STRIP_TAC
      THEN REWRITE_TAC[ELL;LENGTH_CLAUSES;APPEND_CLAUSES;BUTLAST]
      THEN RES_TAC]);;

let ELL_SNOC0 = prove_thm(`ELL_SNOC0`,
    "!l:* list. !x. (ELL 0 (SNOC x l) = x)",
     REPEAT GEN_TAC THEN REWRITE_TAC[ELL;LAST]);;

let ELL_SNOC = prove_thm(`ELL_SNOC`,
    "!l:* list. !x k. 0 < k ==> (ELL k (SNOC x l) = ELL (PRE k) l)",
    GEN_TAC THEN GEN_TAC THEN INDUCT_TAC THENL[
      REWRITE_TAC[NOT_LESS_0];
      REWRITE_TAC[ELL;BUTLAST;PRE;LESS_0]]);;

% |- !l:* list. !x k. (ELL (SUC k) (SNOC x l) = ELL k l) %
let ELL_SUC_SNOC = save_thm(`ELL_SUC_SNOC`,
    GEN_ALL(PURE_ONCE_REWRITE_RULE[PRE]
    (MP (SPECL["l:* list"; "x:*"; "SUC k"] ELL_SNOC) (SPEC "k:num" LESS_0))));;

let ELL_CONS = prove_thm(`ELL_CONS`,
    "!l:* list. !x k. k < (LENGTH l) ==> (ELL k (CONS x l) = ELL k l)",
    SNOC_INDUCT_TAC THENL[
      REWRITE_TAC[NULL;NOT_LESS_0;LENGTH];
      PURE_REWRITE_TAC[LENGTH_CLAUSES] THEN GEN_TAC THEN GEN_TAC
      THEN INDUCT_TAC THENL[
    	DISCH_TAC THEN REWRITE_TAC[ELL;LAST;(GSYM(CONJUNCT2 SNOC_DEF))];
    	PURE_REWRITE_TAC[LESS_MONO_EQ;ELL;BUTLAST;(GSYM(CONJUNCT2 SNOC_DEF))]
    	THEN FIRST_ASSUM MATCH_ACCEPT_TAC]]);;

let HD_ELL_LENGTH_SNOC = prove_thm(`HD_ELL_LENGTH_SNOC`, 
    "!l:* list. !x. (ELL (LENGTH l) (SNOC x l) = (NULL l => x | HD l))",
    SNOC_INDUCT_TAC THENL[
      REWRITE_TAC[ELL;LENGTH;NULL;LAST];
      REWRITE_TAC[ELL;LENGTH_CLAUSES;SNOC_NOT_NULL;BUTLAST;HD_SNOC]
      THEN FIRST_ASSUM MATCH_ACCEPT_TAC]);;

let HD_ELL_LENGTH_CONS = prove_thm(`HD_ELL_LENGTH_CONS`, 
    "!l:* list. !x. (ELL (LENGTH l) (CONS x l) = x)",
    SNOC_INDUCT_TAC THENL[
      REWRITE_TAC[ELL;LENGTH;LAST_EL];
      REWRITE_TAC[ELL;LENGTH_CLAUSES;BUTLAST;(GSYM(CONJUNCT2 SNOC_DEF))]
      THEN POP_ASSUM ACCEPT_TAC]);;

let ELL_APPEND_1 = prove_thm(`ELL_APPEND_1`,
    "!l1:* list. !l2 k. k < LENGTH l2 ==> (ELL k (APPEND l1 l2) = ELL k l2)",
    GEN_TAC THEN SNOC_INDUCT_TAC THENL[
      REWRITE_TAC[LENGTH;NOT_LESS_0];
      PURE_REWRITE_TAC[LENGTH_CLAUSES] THEN GEN_TAC THEN INDUCT_TAC THENL[
    	DISCH_TAC THEN REWRITE_TAC[APPEND_CLAUSES;ELL;LAST];
    	PURE_REWRITE_TAC[APPEND_CLAUSES;ELL;BUTLAST;LESS_MONO_EQ]
        THEN FIRST_ASSUM MATCH_ACCEPT_TAC]]);;

let ELL_APPEND_2 = prove_thm(`ELL_APPEND_2`,
    "!l1:* list. !l2 k. LENGTH l2 <= k ==>
     (ELL k (APPEND l1 l2) = ELL (k - LENGTH l2) l1)",
    GEN_TAC THEN SNOC_INDUCT_TAC THENL[
      REWRITE_TAC[LENGTH;SUB_0;APPEND_NIL];
      PURE_REWRITE_TAC[LENGTH_CLAUSES;APPEND_CLAUSES]
      THEN GEN_TAC THEN INDUCT_TAC THENL[
        REWRITE_TAC[LESS_OR_EQ;NOT_LESS_0;NOT_SUC];
    	PURE_REWRITE_TAC[LESS_EQ_MONO;ELL;BUTLAST;SUB_MONO_EQ]
        THEN FIRST_ASSUM MATCH_ACCEPT_TAC]]);;

let HD_ELL_PRE_LENGTH = prove_thm(`HD_ELL_PRE_LENGTH`,
    "!l:* list. ~(NULL l) ==> (ELL (PRE(LENGTH l)) l  = HD l)",
    LIST_INDUCT_TAC THENL[
      REWRITE_TAC[NULL];
      REWRITE_TAC[LENGTH;PRE]
      THEN REPEAT STRIP_TAC THEN REWRITE_TAC[HD_ELL_LENGTH_CONS;HD]]);;

let LESS_PRE_SUB_LESS = PROVE(
    "!n m. (m < n) ==> (PRE(n - m) < n)",
    REPEAT INDUCT_TAC THENL[
    	REWRITE_TAC[NOT_LESS_0];
    	REWRITE_TAC[NOT_LESS_0];
    	REWRITE_TAC[SUB_0;PRE_K_K];
    	REWRITE_TAC[LESS_MONO_EQ;SUB_MONO_EQ;LESS_THM]
    	THEN DISCH_TAC THEN DISJ2_TAC THEN RES_TAC]);;

let EL_ELL = prove_thm(`EL_ELL`,
    "!l:* list. !k. k < LENGTH l ==> (EL k l = ELL (PRE((LENGTH l) - k)) l)",
    LIST_INDUCT_TAC THENL[
      REWRITE_TAC[LENGTH;NOT_LESS_0];
      REWRITE_TAC[LENGTH] THEN GEN_TAC THEN INDUCT_TAC THENL[
        REWRITE_TAC[PRE;EL;HD_ELL_LENGTH_CONS;NOT_LESS_0;HD;SUB_0];
        REWRITE_TAC[EL;TL;LESS_MONO_EQ;SUB_MONO_EQ]
    	THEN DISCH_TAC THEN MAP_EVERY IMP_RES_TAC [LESS_PRE_SUB_LESS;ELL_CONS]
    	THEN RES_TAC THEN ASM_REWRITE_TAC[]]]);;

let ELL_EL = prove_thm(`ELL_EL`,
    "!l:* list. !k. k < LENGTH l ==> (ELL k l = EL (PRE((LENGTH l) - k)) l)",
    let lem1 =  (MP (SPEC "SNOC (h:*) l" LAST_EL_LENGTH)
       (SPECL ["h:*";"l:* list"] SNOC_NOT_NULL)) in
    SNOC_INDUCT_TAC THENL[
      REWRITE_TAC[LENGTH;NOT_LESS_0];
      GEN_TAC THEN INDUCT_TAC THENL[
        REWRITE_TAC[SUB_0;ELL] THEN DISCH_TAC THEN ACCEPT_TAC lem1;
        REWRITE_TAC[ELL;LENGTH_CLAUSES;LESS_MONO_EQ;SUB_MONO_EQ;BUTLAST]
    	THEN DISCH_TAC THEN MAP_EVERY IMP_RES_TAC [LESS_PRE_SUB_LESS;EL_SNOC]
    	THEN RES_TAC THEN ASM_REWRITE_TAC[]]]);;

let ELL_MAP = prove_thm(`ELL_MAP`,
    "!(f:*->**) l n. n < (LENGTH l) ==> (ELL n (MAP f l) = f (ELL n l))",
    GEN_TAC THEN SNOC_INDUCT_TAC THENL[
      REWRITE_TAC[LENGTH;NOT_LESS_0];
      GEN_TAC THEN INDUCT_TAC THENL[
        REWRITE_TAC[ELL;MAP_SNOC;LAST];
        REWRITE_TAC[LENGTH_CLAUSES;ELL;MAP_SNOC;BUTLAST;LESS_MONO_EQ] 
    	THEN FIRST_ASSUM MATCH_ACCEPT_TAC]]);;

let MAP_ELL = prove_thm(`MAP_ELL`,
    "!(f:*->**) l n. n < (LENGTH l) ==> (MAP f [ELL n l] = [f (ELL n l)])",
    GEN_TAC THEN SNOC_INDUCT_TAC THENL[
      REWRITE_TAC[LENGTH;NOT_LESS_0];
      GEN_TAC THEN INDUCT_TAC THENL[
        REWRITE_TAC[ELL;MAP;LAST];
        REWRITE_TAC[LENGTH_CLAUSES;ELL;MAP_SNOC;BUTLAST;LESS_MONO_EQ] 
    	THEN FIRST_ASSUM MATCH_ACCEPT_TAC]]);;

let ELL_MAP2 = prove_thm(`ELL_MAP2`,
    "!(f:*->**->***) l l' n. (LENGTH l = LENGTH l') ==>
      (n < (LENGTH l)) \/ (n < (LENGTH l')) ==>
     (ELL n (MAP2 f l l') = f (ELL n l) (ELL n l'))",
    GEN_TAC THEN SNOC_INDUCT_TAC THENL[
      PURE_REWRITE_TAC[LENGTH] THEN REPEAT GEN_TAC
      THEN DISCH_THEN (\t. SUBST1_TAC (SYM t)) THEN REWRITE_TAC[NOT_LESS_0];
      GEN_TAC THEN SNOC_INDUCT_TAC THENL[
        REWRITE_TAC[LENGTH_CLAUSES;NOT_SUC];
        REWRITE_TAC[LENGTH_CLAUSES;INV_SUC_EQ] THEN GEN_TAC
    	THEN INDUCT_TAC THEN DISCH_TAC THEN IMP_RES_TAC MAP2_SNOC THENL[
    	  ASM_REWRITE_TAC[ELL_SNOC0];
          PURE_REWRITE_TAC[ELL;LESS_MONO_EQ]
          THEN STRIP_TAC THEN RES_TAC THEN ASM_REWRITE_TAC[BUTLAST]]]]);;

let MAP2_ELL = prove_thm(`MAP2_ELL`,
    "!(f:*->**->***) l l' n. (LENGTH l = LENGTH l') ==>
      (n < (LENGTH l) \/ (n < (LENGTH l'))) ==>
     (MAP2 f [ELL n l] [ELL n l'] = [f (ELL n l) (ELL n l')])",
    GEN_TAC THEN SNOC_INDUCT_TAC THENL[
      PURE_REWRITE_TAC[LENGTH] THEN REPEAT GEN_TAC
      THEN DISCH_THEN (\t. SUBST1_TAC (SYM t)) THEN REWRITE_TAC[NOT_LESS_0];
      GEN_TAC THEN SNOC_INDUCT_TAC THENL[
        REWRITE_TAC[LENGTH_CLAUSES;NOT_SUC];
        REWRITE_TAC[LENGTH_CLAUSES;INV_SUC_EQ] THEN GEN_TAC
    	THEN INDUCT_TAC THENL[
          REWRITE_TAC[ELL_SNOC0;MAP2];
          REWRITE_TAC[ELL;BUTLAST;LESS_MONO_EQ]
    	  THEN FIRST_ASSUM MATCH_ACCEPT_TAC]]]);;

close_theory();;

